/*   1:    */ package com.pwn9.PwnFilter;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.MapMaker;
/*   4:    */ import com.pwn9.PwnFilter.api.ClientManager;
/*   5:    */ import com.pwn9.PwnFilter.api.FilterClient;
/*   6:    */ import com.pwn9.PwnFilter.command.pfcls;
/*   7:    */ import com.pwn9.PwnFilter.command.pfdumpcache;
/*   8:    */ import com.pwn9.PwnFilter.command.pfmute;
/*   9:    */ import com.pwn9.PwnFilter.command.pfreload;
/*  10:    */ import com.pwn9.PwnFilter.listener.PlayerCacheListener;
/*  11:    */ import com.pwn9.PwnFilter.listener.PwnFilterBookListener;
/*  12:    */ import com.pwn9.PwnFilter.listener.PwnFilterCommandListener;
/*  13:    */ import com.pwn9.PwnFilter.listener.PwnFilterEntityListener;
/*  14:    */ import com.pwn9.PwnFilter.listener.PwnFilterInvListener;
/*  15:    */ import com.pwn9.PwnFilter.listener.PwnFilterPlayerListener;
/*  16:    */ import com.pwn9.PwnFilter.listener.PwnFilterServerCommandListener;
/*  17:    */ import com.pwn9.PwnFilter.listener.PwnFilterSignListener;
/*  18:    */ import com.pwn9.PwnFilter.mcstats.Metrics;
/*  19:    */ import com.pwn9.PwnFilter.mcstats.Metrics.Graph;
/*  20:    */ import com.pwn9.PwnFilter.mcstats.Metrics.Plotter;
/*  21:    */ import com.pwn9.PwnFilter.rules.RuleChain;
/*  22:    */ import com.pwn9.PwnFilter.rules.RuleManager;
/*  23:    */ import com.pwn9.PwnFilter.util.FileUtil;
/*  24:    */ import com.pwn9.PwnFilter.util.LogManager;
/*  25:    */ import com.pwn9.PwnFilter.util.PointManager;
/*  26:    */ import com.pwn9.PwnFilter.util.Tracker;
/*  27:    */ import java.io.BufferedReader;
/*  28:    */ import java.io.File;
/*  29:    */ import java.io.FileInputStream;
/*  30:    */ import java.io.FileNotFoundException;
/*  31:    */ import java.io.IOException;
/*  32:    */ import java.io.InputStreamReader;
/*  33:    */ import java.util.ArrayList;
/*  34:    */ import java.util.concurrent.ConcurrentMap;
/*  35:    */ import java.util.logging.Logger;
/*  36:    */ import net.milkbowl.vault.economy.Economy;
/*  37:    */ import org.bukkit.Server;
/*  38:    */ import org.bukkit.command.PluginCommand;
/*  39:    */ import org.bukkit.configuration.file.FileConfiguration;
/*  40:    */ import org.bukkit.entity.Player;
/*  41:    */ import org.bukkit.event.HandlerList;
/*  42:    */ import org.bukkit.plugin.PluginDescriptionFile;
/*  43:    */ import org.bukkit.plugin.PluginManager;
/*  44:    */ import org.bukkit.plugin.RegisteredServiceProvider;
/*  45:    */ import org.bukkit.plugin.ServicesManager;
/*  46:    */ import org.bukkit.plugin.java.JavaPlugin;
/*  47:    */ 
/*  48:    */ public class PwnFilter
/*  49:    */   extends JavaPlugin
/*  50:    */ {
/*  51:    */   private static PwnFilter _instance;
/*  52:    */   private Metrics metrics;
/*  53:    */   public static Tracker matchTracker;
/*  54:    */   private Metrics.Graph eventGraph;
/*  55: 58 */   public static ConcurrentMap<Player, String> killedPlayers = new MapMaker().concurrencyLevel(2).weakKeys().makeMap();
/*  56: 61 */   public static boolean decolor = false;
/*  57: 62 */   public static boolean pwnMute = false;
/*  58: 64 */   public static ConcurrentMap<Player, String> lastMessage = new MapMaker().concurrencyLevel(2).weakKeys().makeMap();
/*  59: 65 */   public static Economy economy = null;
/*  60:    */   private File textDir;
/*  61:    */   
/*  62:    */   public PwnFilter()
/*  63:    */   {
/*  64: 70 */     _instance = this;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static PwnFilter getInstance()
/*  68:    */   {
/*  69: 74 */     return _instance;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void onLoad()
/*  73:    */   {
/*  74: 81 */     LogManager.getInstance(getLogger(), getDataFolder());
/*  75:    */     
/*  76:    */ 
/*  77: 84 */     RuleManager.init(this);
/*  78:    */     
/*  79:    */ 
/*  80: 87 */     RuleManager.getInstance().migrateRules(getDataFolder());
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void onEnable()
/*  84:    */   {
/*  85: 95 */     saveDefaultConfig();
/*  86:    */     
/*  87:    */ 
/*  88: 98 */     configurePlugin();
/*  89:    */     
/*  90:    */ 
/*  91:101 */     setupEconomy();
/*  92:    */     
/*  93:    */ 
/*  94:104 */     DataCache.init(this);
/*  95:    */     
/*  96:106 */     DataCache.getInstance().addPermissions(getDescription().getPermissions());
/*  97:    */     
/*  98:    */ 
/*  99:109 */     PointManager.setup(this);
/* 100:    */     
/* 101:    */ 
/* 102:112 */     activateMetrics();
/* 103:    */     
/* 104:    */ 
/* 105:115 */     ClientManager clientManager = ClientManager.getInstance();
/* 106:116 */     clientManager.registerClient(new PwnFilterCommandListener(this), this);
/* 107:117 */     clientManager.registerClient(new PwnFilterInvListener(this), this);
/* 108:118 */     clientManager.registerClient(new PwnFilterPlayerListener(this), this);
/* 109:119 */     clientManager.registerClient(new PwnFilterServerCommandListener(this), this);
/* 110:120 */     clientManager.registerClient(new PwnFilterSignListener(this), this);
/* 111:121 */     clientManager.registerClient(new PwnFilterBookListener(this), this);
/* 112:    */     
/* 113:    */ 
/* 114:    */ 
/* 115:125 */     getServer().getPluginManager().registerEvents(new PwnFilterEntityListener(), this);
/* 116:    */     
/* 117:127 */     getServer().getPluginManager().registerEvents(new PlayerCacheListener(), this);
/* 118:    */     
/* 119:    */ 
/* 120:130 */     DataCache.getInstance().start();
/* 121:    */     
/* 122:    */ 
/* 123:133 */     clientManager.enableClients();
/* 124:    */     
/* 125:    */ 
/* 126:136 */     getCommand("pfreload").setExecutor(new pfreload(this));
/* 127:137 */     getCommand("pfcls").setExecutor(new pfcls(this));
/* 128:138 */     getCommand("pfmute").setExecutor(new pfmute(this));
/* 129:139 */     getCommand("pfdumpcache").setExecutor(new pfdumpcache());
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void onDisable()
/* 133:    */   {
/* 134:145 */     ClientManager.getInstance().unregisterClients();
/* 135:    */     
/* 136:147 */     HandlerList.unregisterAll(this);
/* 137:    */     
/* 138:    */ 
/* 139:150 */     DataCache.getInstance().stop();
/* 140:    */     
/* 141:152 */     LogManager.getInstance().stop();
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void activateMetrics()
/* 145:    */   {
/* 146:    */     try
/* 147:    */     {
/* 148:159 */       if (this.metrics == null)
/* 149:    */       {
/* 150:160 */         this.metrics = new Metrics(this);
/* 151:    */         
/* 152:162 */         this.eventGraph = this.metrics.createGraph("Rules by Event");
/* 153:163 */         updateMetrics();
/* 154:    */         
/* 155:165 */         Metrics.Graph matchGraph = this.metrics.createGraph("Matches");
/* 156:166 */         matchTracker = new Tracker("Matches");
/* 157:    */         
/* 158:168 */         matchGraph.addPlotter(matchTracker);
/* 159:    */       }
/* 160:170 */       this.metrics.start();
/* 161:    */     }
/* 162:    */     catch (IOException e)
/* 163:    */     {
/* 164:174 */       LogManager.logger.fine(e.getMessage());
/* 165:    */     }
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void updateMetrics()
/* 169:    */   {
/* 170:181 */     ArrayList<String> activeListenerNames = new ArrayList();
/* 171:182 */     for (FilterClient f : ClientManager.getInstance().getActiveClients()) {
/* 172:183 */       activeListenerNames.add(f.getShortName());
/* 173:    */     }
/* 174:187 */     for (Metrics.Plotter p : this.eventGraph.getPlotters()) {
/* 175:188 */       if (!activeListenerNames.contains(p.getColumnName())) {
/* 176:189 */         this.eventGraph.removePlotter(p);
/* 177:    */       }
/* 178:    */     }
/* 179:194 */     for (final FilterClient f : ClientManager.getInstance().getActiveClients())
/* 180:    */     {
/* 181:195 */       String eventName = f.getShortName();
/* 182:196 */       this.eventGraph.addPlotter(new Metrics.Plotter(eventName)
/* 183:    */       {
/* 184:    */         public int getValue()
/* 185:    */         {
/* 186:199 */           RuleChain r = f.getRuleChain();
/* 187:200 */           if (r != null) {
/* 188:201 */             return r.ruleCount();
/* 189:    */           }
/* 190:203 */           return 0;
/* 191:    */         }
/* 192:    */       });
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void configurePlugin()
/* 197:    */   {
/* 198:212 */     if (getConfig().getBoolean("logfile")) {
/* 199:213 */       LogManager.getInstance().start();
/* 200:    */     } else {
/* 201:215 */       LogManager.getInstance().stop();
/* 202:    */     }
/* 203:218 */     RuleManager.getInstance().setRuleDir(getConfig().getString("ruledirectory"));
/* 204:    */     
/* 205:    */ 
/* 206:221 */     String textDirectory = getConfig().getString("textdir", "textfiles");
/* 207:222 */     if (textDirectory.startsWith("/")) {
/* 208:223 */       this.textDir = new File(textDirectory);
/* 209:    */     } else {
/* 210:225 */       this.textDir = new File(getDataFolder(), textDirectory);
/* 211:    */     }
/* 212:    */     try
/* 213:    */     {
/* 214:228 */       if ((!this.textDir.exists()) && 
/* 215:229 */         (this.textDir.mkdirs())) {
/* 216:230 */         LogManager.logger.info("Created directory for textfiles: " + this.textDir.getAbsolutePath());
/* 217:    */       }
/* 218:    */     }
/* 219:    */     catch (SecurityException ex)
/* 220:    */     {
/* 221:233 */       LogManager.logger.warning("Unable to access/create textfile directory: " + this.textDir.getAbsolutePath());
/* 222:    */     }
/* 223:236 */     LogManager.setRuleLogLevel(getConfig().getString("loglevel", "info"));
/* 224:237 */     LogManager.setDebugMode(getConfig().getString("debug"));
/* 225:    */     
/* 226:239 */     decolor = getConfig().getBoolean("decolor");
/* 227:    */   }
/* 228:    */   
/* 229:    */   public File getTextDir()
/* 230:    */   {
/* 231:246 */     return this.textDir;
/* 232:    */   }
/* 233:    */   
/* 234:    */   private void setupEconomy()
/* 235:    */   {
/* 236:251 */     if (getServer().getPluginManager().getPlugin("Vault") != null)
/* 237:    */     {
/* 238:252 */       RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
/* 239:253 */       if (rsp != null)
/* 240:    */       {
/* 241:254 */         economy = (Economy)rsp.getProvider();
/* 242:255 */         LogManager.logger.info("Vault found. Enabling actions requiring Vault");
/* 243:256 */         return;
/* 244:    */       }
/* 245:    */     }
/* 246:259 */     LogManager.logger.info("Vault dependency not found.  Disabling actions requiring Vault");
/* 247:    */   }
/* 248:    */   
/* 249:    */   public BufferedReader getBufferedReader(String filename)
/* 250:    */     throws FileNotFoundException
/* 251:    */   {
/* 252:265 */     if (this.textDir == null) {
/* 253:265 */       throw new FileNotFoundException("Could not open Textfile Directory.");
/* 254:    */     }
/* 255:267 */     File textfile = FileUtil.getFile(getTextDir(), filename, false);
/* 256:268 */     if (textfile == null) {
/* 257:268 */       throw new FileNotFoundException("Unable to open file: " + filename);
/* 258:    */     }
/* 259:270 */     FileInputStream fs = new FileInputStream(textfile);
/* 260:271 */     return new BufferedReader(new InputStreamReader(fs));
/* 261:    */   }
/* 262:    */   
/* 263:    */   public static void addKilledPlayer(Player p, String message)
/* 264:    */   {
/* 265:276 */     killedPlayers.put(p, message);
/* 266:    */   }
/* 267:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.PwnFilter
 * JD-Core Version:    0.7.0.1
 */