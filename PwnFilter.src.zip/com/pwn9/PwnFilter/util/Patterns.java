/*  1:   */ package com.pwn9.PwnFilter.util;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.rules.Rule;
/*  5:   */ import java.text.DecimalFormat;
/*  6:   */ import java.util.logging.Logger;
/*  7:   */ import java.util.regex.Matcher;
/*  8:   */ import java.util.regex.Pattern;
/*  9:   */ import java.util.regex.PatternSyntaxException;
/* 10:   */ 
/* 11:   */ public class Patterns
/* 12:   */ {
/* 13:27 */   static final DecimalFormat df = new DecimalFormat("0.00##");
/* 14:   */   
/* 15:   */   public static Pattern compilePattern(String re)
/* 16:   */   {
/* 17:30 */     Pattern pattern = null;
/* 18:   */     try
/* 19:   */     {
/* 20:32 */       pattern = Pattern.compile(re, 2);
/* 21:33 */       LogManager.getInstance().debugMedium("Successfully compiled regex: " + re);
/* 22:34 */       return pattern;
/* 23:   */     }
/* 24:   */     catch (PatternSyntaxException e)
/* 25:   */     {
/* 26:37 */       LogManager.logger.warning("Failed to compile regex: " + re);
/* 27:38 */       LogManager.logger.warning(e.getMessage());
/* 28:   */     }
/* 29:   */     catch (Exception e)
/* 30:   */     {
/* 31:41 */       LogManager.logger.severe("Unexpected error while compiling expression '" + re + "'");
/* 32:42 */       e.printStackTrace();
/* 33:   */     }
/* 34:44 */     return pattern;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static String replaceVars(String line, FilterState state)
/* 38:   */   {
/* 39:48 */     Pattern p = Pattern.compile("(&player|&string|&rawstring|&event|&ruleid|&ruledescr)");
/* 40:49 */     Matcher m = p.matcher(line);
/* 41:52 */     if (m.matches())
/* 42:   */     {
/* 43:53 */       String group = m.group(1);
/* 44:54 */       String replace = "%" + group.substring(1) + "%";
/* 45:55 */       LogManager.logger.warning("The use of " + m.group(1) + " is deprecated.  Please update your configuration to use " + replace + ".");
/* 46:56 */       line = line.replaceAll("&world", wrapReplacement(state.playerWorldName)).replaceAll("&player", wrapReplacement(state.playerName)).replaceAll("&string", wrapReplacement(state.getModifiedMessage().getColoredString())).replaceAll("&rawstring", wrapReplacement(state.getOriginalMessage().getColoredString())).replaceAll("&event", wrapReplacement(state.getListenerName())).replaceAll("&ruleid", state.rule != null ? wrapReplacement(state.rule.getId()) : "-").replaceAll("&ruledescr", state.rule != null ? wrapReplacement(state.rule.getDescription()) : "''");
/* 47:   */     }
/* 48:64 */     line = line.replaceAll("%world%", wrapReplacement(state.playerWorldName)).replaceAll("%player%", wrapReplacement(state.playerName)).replaceAll("%string%", wrapReplacement(state.getModifiedMessage().getColoredString())).replaceAll("%rawstring%", wrapReplacement(state.getOriginalMessage().getColoredString())).replaceAll("%event%", wrapReplacement(state.getListenerName())).replaceAll("%points%", PointManager.isEnabled() ? df.format(PointManager.getInstance().getPlayerPoints(state.playerName)) : "-").replaceAll("%ruleid%", state.rule != null ? wrapReplacement(state.rule.getId()) : "-").replaceAll("%ruledescr%", state.rule != null ? wrapReplacement(state.rule.getDescription()) : "''");
/* 49:   */     
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:72 */     return line;
/* 57:   */   }
/* 58:   */   
/* 59:   */   private static String wrapReplacement(String s)
/* 60:   */   {
/* 61:76 */     return s != null ? Matcher.quoteReplacement(s) : "-";
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.util.Patterns
 * JD-Core Version:    0.7.0.1
 */