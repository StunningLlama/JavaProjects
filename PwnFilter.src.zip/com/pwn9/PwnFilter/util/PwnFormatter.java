/*  1:   */ package com.pwn9.PwnFilter.util;
/*  2:   */ 
/*  3:   */ import java.text.Format;
/*  4:   */ import java.text.SimpleDateFormat;
/*  5:   */ import java.util.Date;
/*  6:   */ import java.util.logging.LogRecord;
/*  7:   */ import java.util.logging.SimpleFormatter;
/*  8:   */ 
/*  9:   */ public class PwnFormatter
/* 10:   */   extends SimpleFormatter
/* 11:   */ {
/* 12:   */   public synchronized String format(LogRecord record)
/* 13:   */   {
/* 14:26 */     Date date = new Date(record.getMillis());
/* 15:27 */     Format formatter = new SimpleDateFormat("[yyyy/MM/dd HH:mm:ss]");
/* 16:28 */     String dateStr = formatter.format(date);
/* 17:29 */     return dateStr + " " + record.getMessage() + "\n";
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.util.PwnFormatter
 * JD-Core Version:    0.7.0.1
 */