/*  1:   */ package com.pwn9.PwnFilter.util;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  4:   */ import org.bukkit.ChatColor;
/*  5:   */ import org.bukkit.configuration.file.FileConfiguration;
/*  6:   */ 
/*  7:   */ public class DefaultMessages
/*  8:   */ {
/*  9:   */   public static String prepareMessage(String message, String configVarName)
/* 10:   */   {
/* 11:   */     String result;
/* 12:   */     String result;
/* 13:33 */     if ((message == null) || (message.isEmpty()))
/* 14:   */     {
/* 15:34 */       String defmsg = PwnFilter.getInstance().getConfig().getString(configVarName);
/* 16:35 */       result = defmsg != null ? defmsg : "";
/* 17:   */     }
/* 18:   */     else
/* 19:   */     {
/* 20:37 */       result = message;
/* 21:   */     }
/* 22:39 */     return ChatColor.translateAlternateColorCodes('&', result);
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.util.DefaultMessages
 * JD-Core Version:    0.7.0.1
 */