/*  1:   */ package com.pwn9.PwnFilter.util;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  4:   */ import java.io.BufferedInputStream;
/*  5:   */ import java.io.File;
/*  6:   */ import java.io.FileOutputStream;
/*  7:   */ import java.io.IOException;
/*  8:   */ import java.io.InputStream;
/*  9:   */ import java.util.logging.Logger;
/* 10:   */ import org.bukkit.plugin.Plugin;
/* 11:   */ 
/* 12:   */ public class FileUtil
/* 13:   */ {
/* 14:   */   public static File getFile(File dir, String fileName, boolean createFile)
/* 15:   */   {
/* 16:   */     try
/* 17:   */     {
/* 18:30 */       File ruleFile = new File(dir, fileName);
/* 19:31 */       if (ruleFile.exists()) {
/* 20:32 */         return ruleFile;
/* 21:   */       }
/* 22:34 */       if (createFile)
/* 23:   */       {
/* 24:35 */         if ((!ruleFile.getParentFile().exists()) && (!ruleFile.getParentFile().mkdirs()))
/* 25:   */         {
/* 26:36 */           LogManager.logger.warning("Unable to create directory for:" + fileName);
/* 27:37 */           return null;
/* 28:   */         }
/* 29:39 */         if (copyTemplate(ruleFile, fileName)) {
/* 30:40 */           return ruleFile;
/* 31:   */         }
/* 32:42 */         LogManager.logger.warning("Unable to find or create file:" + fileName);
/* 33:43 */         return null;
/* 34:   */       }
/* 35:   */     }
/* 36:   */     catch (IOException ex)
/* 37:   */     {
/* 38:49 */       LogManager.logger.warning("Unable to find or create file:" + fileName);
/* 39:50 */       LogManager.getInstance().debugLow(ex.getMessage());
/* 40:   */     }
/* 41:   */     catch (SecurityException ex)
/* 42:   */     {
/* 43:52 */       LogManager.logger.warning("Insufficient Privileges to create file: " + fileName);
/* 44:53 */       LogManager.getInstance().debugLow(ex.getMessage());
/* 45:   */     }
/* 46:55 */     return null;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public static boolean copyTemplate(File destFile, String configName)
/* 50:   */     throws IOException, SecurityException
/* 51:   */   {
/* 52:67 */     Plugin plugin = PwnFilter.getInstance();
/* 53:   */     
/* 54:   */ 
/* 55:   */ 
/* 56:71 */     InputStream templateFile = plugin.getResource(configName);
/* 57:72 */     if (templateFile == null) {
/* 58:74 */       return (destFile.mkdirs()) && (destFile.createNewFile());
/* 59:   */     }
/* 60:76 */     if (destFile.createNewFile())
/* 61:   */     {
/* 62:77 */       BufferedInputStream fin = new BufferedInputStream(templateFile);
/* 63:78 */       FileOutputStream fout = new FileOutputStream(destFile);
/* 64:79 */       byte[] data = new byte[1024];
/* 65:   */       int c;
/* 66:81 */       while ((c = fin.read(data, 0, 1024)) != -1) {
/* 67:82 */         fout.write(data, 0, c);
/* 68:   */       }
/* 69:83 */       fin.close();
/* 70:84 */       fout.close();
/* 71:85 */       LogManager.logger.info("Created file from template: " + configName);
/* 72:86 */       return true;
/* 73:   */     }
/* 74:88 */     LogManager.logger.warning("Failed to create file from template: " + configName);
/* 75:89 */     return false;
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.util.FileUtil
 * JD-Core Version:    0.7.0.1
 */