/*  1:   */ package com.pwn9.PwnFilter.util;
/*  2:   */ 
/*  3:   */ public class LimitedRegexCharSequence
/*  4:   */   implements CharSequence
/*  5:   */ {
/*  6:   */   private final CharSequence inner;
/*  7:   */   private final int timeoutMillis;
/*  8:   */   private final long timeoutTime;
/*  9:   */   private long accessCount;
/* 10:   */   
/* 11:   */   public LimitedRegexCharSequence(CharSequence inner, int timeoutMillis)
/* 12:   */   {
/* 13:41 */     this.inner = inner;
/* 14:42 */     this.timeoutMillis = timeoutMillis;
/* 15:43 */     this.timeoutTime = (System.currentTimeMillis() + timeoutMillis);
/* 16:44 */     this.accessCount = 0L;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public char charAt(int index)
/* 20:   */   {
/* 21:48 */     this.accessCount += 1L;
/* 22:49 */     if (System.currentTimeMillis() > this.timeoutTime) {
/* 23:50 */       throw new RuntimeException("Timeout occurred after " + this.timeoutMillis + "ms");
/* 24:   */     }
/* 25:52 */     return this.inner.charAt(index);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public int length()
/* 29:   */   {
/* 30:56 */     return this.inner.length();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public CharSequence subSequence(int start, int end)
/* 34:   */   {
/* 35:60 */     return new LimitedRegexCharSequence(this.inner.subSequence(start, end), this.timeoutMillis);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public long getAccessCount()
/* 39:   */   {
/* 40:64 */     return this.accessCount;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String toString()
/* 44:   */   {
/* 45:69 */     return this.inner.toString();
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.util.LimitedRegexCharSequence
 * JD-Core Version:    0.7.0.1
 */