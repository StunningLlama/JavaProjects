/*  1:   */ package com.pwn9.PwnFilter.util;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.mcstats.Metrics.Plotter;
/*  4:   */ 
/*  5:   */ public class Tracker
/*  6:   */   extends Metrics.Plotter
/*  7:   */ {
/*  8:   */   private final String name;
/*  9:   */   private int value;
/* 10:   */   private int last;
/* 11:   */   
/* 12:   */   public Tracker(String name)
/* 13:   */   {
/* 14:25 */     this.name = name;
/* 15:26 */     this.value = 0;
/* 16:27 */     this.last = 0;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getColumnName()
/* 20:   */   {
/* 21:32 */     return this.name;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public int getValue()
/* 25:   */   {
/* 26:37 */     this.last = this.value;
/* 27:38 */     return this.value;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void increment()
/* 31:   */   {
/* 32:42 */     this.value += 1;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void reset()
/* 36:   */   {
/* 37:47 */     this.value -= this.last;
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.util.Tracker
 * JD-Core Version:    0.7.0.1
 */