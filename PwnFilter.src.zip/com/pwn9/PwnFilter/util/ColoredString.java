/*   1:    */ package com.pwn9.PwnFilter.util;
/*   2:    */ 
/*   3:    */ import java.util.Arrays;
/*   4:    */ import java.util.regex.Matcher;
/*   5:    */ import java.util.regex.Pattern;
/*   6:    */ 
/*   7:    */ public final class ColoredString
/*   8:    */   implements CharSequence
/*   9:    */ {
/*  10:    */   private final String[] codes;
/*  11:    */   private final char[] plain;
/*  12:    */   private final char formatPrefix;
/*  13:    */   
/*  14:    */   public ColoredString(String s)
/*  15:    */   {
/*  16: 43 */     this(s, '&');
/*  17:    */   }
/*  18:    */   
/*  19:    */   public ColoredString(String s, char prefix)
/*  20:    */   {
/*  21: 47 */     this.formatPrefix = prefix;
/*  22: 48 */     char[] raw = s.toCharArray();
/*  23: 49 */     char[] tmpPlain = new char[raw.length];
/*  24: 50 */     String[] tmpCodes = new String[raw.length + 1];
/*  25:    */     
/*  26: 52 */     int textpos = 0;
/*  27: 54 */     for (int i = 0; i < raw.length; i++) {
/*  28: 55 */       if ((i != raw.length - 1) && (raw[i] == this.formatPrefix) && ("0123456789AaBbCcDdEeFfKkLlMmNnOoRr".indexOf(raw[(i + 1)]) > -1))
/*  29:    */       {
/*  30: 56 */         if (tmpCodes[textpos] == null)
/*  31:    */         {
/*  32: 57 */           tmpCodes[textpos] = new String(raw, i, 2);
/*  33:    */         }
/*  34:    */         else
/*  35:    */         {
/*  36: 59 */           int tmp115_113 = textpos; String[] tmp115_111 = tmpCodes;tmp115_111[tmp115_113] = (tmp115_111[tmp115_113] + new String(raw, i, 2));
/*  37:    */         }
/*  38: 61 */         i++;
/*  39:    */       }
/*  40:    */       else
/*  41:    */       {
/*  42: 63 */         tmpPlain[textpos] = raw[i];
/*  43: 64 */         textpos++;
/*  44:    */       }
/*  45:    */     }
/*  46: 67 */     this.plain = Arrays.copyOf(tmpPlain, textpos);
/*  47:    */     
/*  48:    */ 
/*  49: 70 */     this.codes = ((String[])Arrays.copyOf(tmpCodes, textpos + 1));
/*  50:    */   }
/*  51:    */   
/*  52:    */   public ColoredString(ColoredString c)
/*  53:    */   {
/*  54: 75 */     this.codes = c.codes;
/*  55: 76 */     this.plain = c.plain;
/*  56: 77 */     this.formatPrefix = c.formatPrefix;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public ColoredString(char[] plain, String[] codes, char prefix)
/*  60:    */   {
/*  61: 81 */     this.plain = plain;
/*  62: 82 */     this.codes = ((String[])Arrays.copyOf(codes, plain.length + 1));
/*  63: 83 */     this.formatPrefix = prefix;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public int length()
/*  67:    */   {
/*  68: 88 */     return this.plain.length;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public char charAt(int i)
/*  72:    */   {
/*  73: 91 */     return this.plain[i];
/*  74:    */   }
/*  75:    */   
/*  76:    */   public CharSequence subSequence(int i, int j)
/*  77:    */   {
/*  78: 95 */     return new String(Arrays.copyOfRange(this.plain, i, j));
/*  79:    */   }
/*  80:    */   
/*  81:    */   public String toString()
/*  82:    */   {
/*  83:100 */     return getColoredString();
/*  84:    */   }
/*  85:    */   
/*  86:    */   public ColoredString decolor()
/*  87:    */   {
/*  88:106 */     return new ColoredString(new String(this.plain));
/*  89:    */   }
/*  90:    */   
/*  91:    */   public String getColoredString()
/*  92:    */   {
/*  93:111 */     StringBuilder sb = new StringBuilder();
/*  94:113 */     for (int i = 0; i < this.plain.length; i++)
/*  95:    */     {
/*  96:114 */       if (this.codes[i] != null) {
/*  97:114 */         sb.append(this.codes[i]);
/*  98:    */       }
/*  99:115 */       sb.append(this.plain[i]);
/* 100:    */     }
/* 101:119 */     if (this.codes[(this.codes.length - 1)] != null) {
/* 102:120 */       sb.append(this.codes[(this.codes.length - 1)]);
/* 103:    */     }
/* 104:121 */     return sb.toString();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public String getPlainString()
/* 108:    */   {
/* 109:126 */     return new String(this.plain);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public String[] getCodeArray()
/* 113:    */   {
/* 114:131 */     return this.codes;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public ColoredString replaceText(Pattern p, String rText)
/* 118:    */   {
/* 119:158 */     Matcher m = p.matcher(new String(this.plain));
/* 120:159 */     ColoredString replacement = new ColoredString(rText);
/* 121:    */     
/* 122:    */ 
/* 123:    */ 
/* 124:163 */     char[] lastMatchText = new char[0];
/* 125:164 */     String[] lastMatchCodes = new String[1];
/* 126:    */     
/* 127:166 */     int currentPosition = 0;
/* 128:168 */     while (m.find())
/* 129:    */     {
/* 130:169 */       int mStart = m.start();
/* 131:170 */       int mEnd = m.end();
/* 132:    */       
/* 133:172 */       int lastMatchTextLength = lastMatchText.length;
/* 134:173 */       int middleLen = mStart - currentPosition;
/* 135:    */       
/* 136:175 */       int newLength = lastMatchTextLength + middleLen + replacement.length();
/* 137:    */       
/* 138:177 */       char[] currentText = new char[newLength];
/* 139:178 */       String[] currentCodes = new String[newLength + 1];
/* 140:    */       
/* 141:    */ 
/* 142:181 */       System.arraycopy(lastMatchText, 0, currentText, 0, lastMatchTextLength);
/* 143:    */       
/* 144:    */ 
/* 145:184 */       System.arraycopy(this.plain, currentPosition, currentText, lastMatchTextLength, middleLen);
/* 146:    */       
/* 147:186 */       System.arraycopy(replacement.plain, 0, currentText, lastMatchTextLength + middleLen, replacement.length());
/* 148:    */       
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:194 */       System.arraycopy(lastMatchCodes, 0, currentCodes, 0, lastMatchTextLength + 1);
/* 156:    */       
/* 157:    */ 
/* 158:197 */       currentCodes[lastMatchTextLength] = mergeCodes(currentCodes[lastMatchTextLength], this.codes[currentPosition]);
/* 159:    */       
/* 160:    */ 
/* 161:200 */       System.arraycopy(this.codes, currentPosition + 1, currentCodes, lastMatchTextLength + 1, middleLen);
/* 162:    */       
/* 163:    */ 
/* 164:203 */       currentCodes[(lastMatchTextLength + middleLen)] = mergeCodes(currentCodes[(lastMatchTextLength + middleLen)], replacement.codes[0]);
/* 165:206 */       if (replacement.codes.length > 1) {
/* 166:207 */         System.arraycopy(replacement.codes, 1, currentCodes, lastMatchTextLength + 1 + middleLen, replacement.length());
/* 167:    */       }
/* 168:210 */       currentPosition = mEnd;
/* 169:    */       
/* 170:212 */       lastMatchText = currentText;
/* 171:213 */       lastMatchCodes = currentCodes;
/* 172:    */     }
/* 173:217 */     char[] tempText = new char[lastMatchText.length + this.plain.length - currentPosition];
/* 174:218 */     String[] tempCodes = new String[lastMatchText.length + this.plain.length - currentPosition + 1];
/* 175:    */     
/* 176:    */ 
/* 177:221 */     System.arraycopy(lastMatchText, 0, tempText, 0, lastMatchText.length);
/* 178:    */     
/* 179:223 */     System.arraycopy(lastMatchCodes, 0, tempCodes, 0, lastMatchText.length);
/* 180:    */     
/* 181:    */ 
/* 182:    */ 
/* 183:227 */     System.arraycopy(this.plain, currentPosition, tempText, lastMatchText.length, this.plain.length - currentPosition);
/* 184:    */     
/* 185:    */ 
/* 186:230 */     tempCodes[lastMatchText.length] = mergeCodes(lastMatchCodes[lastMatchText.length], this.codes[currentPosition]);
/* 187:    */     
/* 188:    */ 
/* 189:    */ 
/* 190:234 */     System.arraycopy(this.codes, currentPosition + 1, tempCodes, lastMatchText.length + 1, this.plain.length - currentPosition);
/* 191:    */     
/* 192:236 */     return new ColoredString(tempText, tempCodes, this.formatPrefix);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public ColoredString patternToLower(Pattern p)
/* 196:    */   {
/* 197:241 */     Matcher m = p.matcher(new String(this.plain));
/* 198:243 */     while (m.find()) {
/* 199:244 */       for (int i = m.start(); i < m.end(); i++) {
/* 200:245 */         this.plain[i] = Character.toLowerCase(this.plain[i]);
/* 201:    */       }
/* 202:    */     }
/* 203:248 */     return new ColoredString(this);
/* 204:    */   }
/* 205:    */   
/* 206:    */   public ColoredString patternToUpper(Pattern p)
/* 207:    */   {
/* 208:252 */     Matcher m = p.matcher(new String(this.plain));
/* 209:254 */     while (m.find()) {
/* 210:255 */       for (int i = m.start(); i < m.end(); i++) {
/* 211:256 */         this.plain[i] = Character.toUpperCase(this.plain[i]);
/* 212:    */       }
/* 213:    */     }
/* 214:259 */     return new ColoredString(this);
/* 215:    */   }
/* 216:    */   
/* 217:    */   private String mergeCodes(String a, String b)
/* 218:    */   {
/* 219:270 */     String result = a == null ? "" : a;
/* 220:271 */     if (b != null) {
/* 221:272 */       result = result + b;
/* 222:    */     }
/* 223:274 */     return result.isEmpty() ? null : result;
/* 224:    */   }
/* 225:    */   
/* 226:    */   public boolean equals(Object obj)
/* 227:    */   {
/* 228:280 */     if ((obj instanceof ColoredString)) {
/* 229:281 */       return ((ColoredString)obj).getColoredString().equals(getColoredString());
/* 230:    */     }
/* 231:283 */     return getColoredString().equals(obj);
/* 232:    */   }
/* 233:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.util.ColoredString
 * JD-Core Version:    0.7.0.1
 */