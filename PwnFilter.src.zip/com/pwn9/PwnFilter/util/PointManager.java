/*   1:    */ package com.pwn9.PwnFilter.util;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.FilterState;
/*   4:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   5:    */ import com.pwn9.PwnFilter.api.FilterClient;
/*   6:    */ import com.pwn9.PwnFilter.rules.RuleChain;
/*   7:    */ import com.pwn9.PwnFilter.rules.action.Action;
/*   8:    */ import com.pwn9.PwnFilter.rules.action.ActionFactory;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Map.Entry;
/*  13:    */ import java.util.NavigableMap;
/*  14:    */ import java.util.Set;
/*  15:    */ import java.util.TreeMap;
/*  16:    */ import java.util.concurrent.ConcurrentHashMap;
/*  17:    */ import java.util.logging.Logger;
/*  18:    */ import org.bukkit.Bukkit;
/*  19:    */ import org.bukkit.configuration.Configuration;
/*  20:    */ import org.bukkit.configuration.ConfigurationSection;
/*  21:    */ import org.bukkit.configuration.file.FileConfiguration;
/*  22:    */ import org.bukkit.entity.Player;
/*  23:    */ import org.bukkit.scheduler.BukkitRunnable;
/*  24:    */ import org.bukkit.scheduler.BukkitScheduler;
/*  25:    */ import org.bukkit.scheduler.BukkitTask;
/*  26:    */ 
/*  27:    */ public class PointManager
/*  28:    */   implements FilterClient
/*  29:    */ {
/*  30:    */   private static PointManager _instance;
/*  31:    */   private final PwnFilter plugin;
/*  32: 41 */   private Map<String, Double> playerPoints = new ConcurrentHashMap(8, 0.75F, 2);
/*  33: 42 */   private TreeMap<Double, Threshold> thresholds = new TreeMap();
/*  34:    */   private int leakInterval;
/*  35:    */   private Double leakPoints;
/*  36:    */   private BukkitTask leakTask;
/*  37:    */   
/*  38:    */   private PointManager(PwnFilter p)
/*  39:    */   {
/*  40: 49 */     this.plugin = p;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static PointManager setup(PwnFilter pwnFilter)
/*  44:    */   {
/*  45: 53 */     ConfigurationSection pointsSection = pwnFilter.getConfig().getConfigurationSection("points");
/*  46: 54 */     if (!pointsSection.getBoolean("enabled"))
/*  47:    */     {
/*  48: 55 */       if (_instance != null) {
/*  49: 55 */         _instance.stopLeaking();
/*  50:    */       }
/*  51: 56 */       _instance = null;
/*  52: 57 */       return null;
/*  53:    */     }
/*  54: 59 */     if (_instance == null) {
/*  55: 60 */       _instance = new PointManager(pwnFilter);
/*  56:    */     }
/*  57: 63 */     _instance.leakPoints = Double.valueOf(pointsSection.getDouble("leak.points", 1.0D));
/*  58: 64 */     _instance.leakInterval = pointsSection.getInt("leak.interval", 30);
/*  59:    */     
/*  60: 66 */     _instance.parseThresholds(pointsSection.getConfigurationSection("thresholds"));
/*  61:    */     
/*  62: 68 */     _instance.startLeaking();
/*  63:    */     
/*  64: 70 */     return _instance;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void reset()
/*  68:    */   {
/*  69: 74 */     stopLeaking();
/*  70: 77 */     for (String playerName : this.playerPoints.keySet()) {
/*  71: 78 */       setPlayerPoints(playerName, Double.valueOf(0.0D));
/*  72:    */     }
/*  73: 81 */     setup(this.plugin);
/*  74:    */   }
/*  75:    */   
/*  76:    */   private void startLeaking()
/*  77:    */   {
/*  78: 85 */     final PointManager pointManager = this;
/*  79: 87 */     if (this.leakTask == null) {
/*  80: 88 */       this.leakTask = Bukkit.getScheduler().runTaskTimerAsynchronously(this.plugin, new BukkitRunnable()
/*  81:    */       {
/*  82:    */         public void run()
/*  83:    */         {
/*  84: 93 */           for (String playerName : pointManager.getPlayersWithPoints()) {
/*  85: 94 */             pointManager.subPlayerPoints(playerName, PointManager.this.leakPoints);
/*  86:    */           }
/*  87:    */         }
/*  88: 94 */       }, 20L, 20 * this.leakInterval);
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   private void stopLeaking()
/*  93:    */   {
/*  94:103 */     if (this.leakTask != null)
/*  95:    */     {
/*  96:104 */       this.leakTask.cancel();
/*  97:105 */       this.leakTask = null;
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   private void parseThresholds(ConfigurationSection cs)
/* 102:    */   {
/* 103:111 */     Threshold defaultThreshold = new Threshold();
/* 104:112 */     defaultThreshold.name = "Default";
/* 105:113 */     defaultThreshold.points = Double.valueOf(0.0D);
/* 106:114 */     this.thresholds.put(Double.valueOf(0.0D), defaultThreshold);
/* 107:116 */     for (String threshold : cs.getKeys(false))
/* 108:    */     {
/* 109:117 */       Threshold newThreshold = new Threshold();
/* 110:118 */       newThreshold.name = cs.getString(threshold + ".name");
/* 111:119 */       newThreshold.points = Double.valueOf(cs.getDouble(threshold + ".points"));
/* 112:121 */       for (String action : cs.getStringList(threshold + ".actions.ascending"))
/* 113:    */       {
/* 114:122 */         Action actionObject = ActionFactory.getActionFromString(action);
/* 115:123 */         if (actionObject != null) {
/* 116:124 */           newThreshold.actionsAscending.add(actionObject);
/* 117:    */         } else {
/* 118:126 */           LogManager.logger.warning("Unable to parse action in threshold: " + threshold);
/* 119:    */         }
/* 120:    */       }
/* 121:129 */       for (String action : cs.getStringList(threshold + ".actions.descending"))
/* 122:    */       {
/* 123:130 */         Action actionObject = ActionFactory.getActionFromString(action);
/* 124:131 */         if (actionObject != null) {
/* 125:132 */           newThreshold.actionsDescending.add(actionObject);
/* 126:    */         } else {
/* 127:134 */           LogManager.logger.warning("Unable to parse action in threshold: " + threshold);
/* 128:    */         }
/* 129:    */       }
/* 130:137 */       this.thresholds.put(newThreshold.points, newThreshold);
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static PointManager getInstance()
/* 135:    */     throws IllegalStateException
/* 136:    */   {
/* 137:144 */     if (_instance == null) {
/* 138:145 */       throw new IllegalStateException("Point Manager Not initialized.");
/* 139:    */     }
/* 140:147 */     return _instance;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public Set<String> getPlayersWithPoints()
/* 144:    */   {
/* 145:151 */     return this.playerPoints.keySet();
/* 146:    */   }
/* 147:    */   
/* 148:    */   public Double getPlayerPoints(String p)
/* 149:    */   {
/* 150:155 */     return Double.valueOf(this.playerPoints.containsKey(p) ? ((Double)this.playerPoints.get(p)).doubleValue() : 0.0D);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public Double getPlayerPoints(Player p)
/* 154:    */   {
/* 155:159 */     return Double.valueOf(this.playerPoints.containsKey(p.getName()) ? ((Double)this.playerPoints.get(p.getName())).doubleValue() : 0.0D);
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void setPlayerPoints(String playerName, Double points)
/* 159:    */   {
/* 160:163 */     Double old = (Double)this.playerPoints.get(playerName);
/* 161:164 */     this.playerPoints.put(playerName, points);
/* 162:165 */     executeActions(old, points, playerName);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public void addPlayerPoints(String playerName, Double points)
/* 166:    */   {
/* 167:169 */     Double current = (Double)this.playerPoints.get(playerName);
/* 168:170 */     if (current == null) {
/* 169:170 */       current = Double.valueOf(0.0D);
/* 170:    */     }
/* 171:171 */     Double updated = Double.valueOf(current.doubleValue() + points.doubleValue());
/* 172:    */     
/* 173:173 */     this.playerPoints.put(playerName, updated);
/* 174:    */     
/* 175:175 */     executeActions(current, updated, playerName);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public static boolean isEnabled()
/* 179:    */   {
/* 180:180 */     return _instance != null;
/* 181:    */   }
/* 182:    */   
/* 183:    */   private void executeActions(Double fromValue, Double toValue, final String playerName)
/* 184:    */   {
/* 185:184 */     final Double oldKey = (Double)this.thresholds.floorKey(fromValue);
/* 186:185 */     final Double newKey = (Double)this.thresholds.floorKey(toValue);
/* 187:187 */     if (oldKey.equals(newKey)) {
/* 188:187 */       return;
/* 189:    */     }
/* 190:189 */     if (fromValue.doubleValue() < toValue.doubleValue()) {
/* 191:193 */       Bukkit.getScheduler().runTask(this.plugin, new BukkitRunnable()
/* 192:    */       {
/* 193:    */         public void run()
/* 194:    */         {
/* 195:196 */           for (Map.Entry<Double, PointManager.Threshold> entry : PointManager.this.thresholds.subMap(oldKey, false, newKey, true).entrySet()) {
/* 196:197 */             ((PointManager.Threshold)entry.getValue()).executeAscending(playerName);
/* 197:    */           }
/* 198:    */         }
/* 199:    */       });
/* 200:    */     } else {
/* 201:201 */       Bukkit.getScheduler().runTask(this.plugin, new BukkitRunnable()
/* 202:    */       {
/* 203:    */         public void run()
/* 204:    */         {
/* 205:204 */           for (Map.Entry<Double, PointManager.Threshold> entry : PointManager.this.thresholds.subMap(newKey, false, oldKey, true).descendingMap().entrySet()) {
/* 206:205 */             ((PointManager.Threshold)entry.getValue()).executeDescending(playerName);
/* 207:    */           }
/* 208:    */         }
/* 209:    */       });
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   public void subPlayerPoints(String playerName, Double points)
/* 214:    */   {
/* 215:214 */     Double current = (Double)this.playerPoints.get(playerName);
/* 216:215 */     if (current == null) {
/* 217:215 */       current = Double.valueOf(0.0D);
/* 218:    */     }
/* 219:216 */     Double updated = Double.valueOf(current.doubleValue() - points.doubleValue());
/* 220:217 */     if (updated.doubleValue() <= 0.0D)
/* 221:    */     {
/* 222:218 */       this.playerPoints.remove(playerName);
/* 223:219 */       updated = Double.valueOf(0.0D);
/* 224:    */     }
/* 225:221 */     this.playerPoints.put(playerName, updated);
/* 226:    */     
/* 227:223 */     executeActions(current, updated, playerName);
/* 228:    */   }
/* 229:    */   
/* 230:    */   class Threshold
/* 231:    */     implements Comparable<Threshold>
/* 232:    */   {
/* 233:    */     String name;
/* 234:    */     Double points;
/* 235:231 */     List<Action> actionsAscending = new ArrayList();
/* 236:232 */     List<Action> actionsDescending = new ArrayList();
/* 237:    */     
/* 238:    */     Threshold() {}
/* 239:    */     
/* 240:    */     public int compareTo(Threshold o)
/* 241:    */     {
/* 242:235 */       return Double.compare(this.points.doubleValue(), o.points.doubleValue());
/* 243:    */     }
/* 244:    */     
/* 245:    */     public void executeAscending(String playerName)
/* 246:    */     {
/* 247:239 */       FilterState state = new FilterState(PointManager.this.plugin, "", playerName, null, PointManager._instance);
/* 248:240 */       for (Action a : this.actionsAscending) {
/* 249:241 */         a.execute(state);
/* 250:    */       }
/* 251:    */     }
/* 252:    */     
/* 253:    */     public void executeDescending(String playerName)
/* 254:    */     {
/* 255:246 */       FilterState state = new FilterState(PointManager.this.plugin, "", playerName, null, PointManager._instance);
/* 256:247 */       for (Action a : this.actionsDescending) {
/* 257:248 */         a.execute(state);
/* 258:    */       }
/* 259:    */     }
/* 260:    */   }
/* 261:    */   
/* 262:    */   public String getShortName()
/* 263:    */   {
/* 264:261 */     return "POINTS";
/* 265:    */   }
/* 266:    */   
/* 267:    */   public RuleChain getRuleChain()
/* 268:    */   {
/* 269:266 */     return null;
/* 270:    */   }
/* 271:    */   
/* 272:    */   public boolean isActive()
/* 273:    */   {
/* 274:271 */     return false;
/* 275:    */   }
/* 276:    */   
/* 277:    */   public void activate(Configuration config) {}
/* 278:    */   
/* 279:    */   public void shutdown() {}
/* 280:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.util.PointManager
 * JD-Core Version:    0.7.0.1
 */