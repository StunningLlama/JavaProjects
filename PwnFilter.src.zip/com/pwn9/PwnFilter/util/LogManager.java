/*   1:    */ package com.pwn9.PwnFilter.util;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.util.logging.FileHandler;
/*   6:    */ import java.util.logging.Level;
/*   7:    */ import java.util.logging.Logger;
/*   8:    */ import java.util.logging.SimpleFormatter;
/*   9:    */ 
/*  10:    */ public class LogManager
/*  11:    */ {
/*  12:    */   public static Level ruleLogLevel;
/*  13: 29 */   public static DebugModes debugMode = DebugModes.off;
/*  14:    */   public static Logger logger;
/*  15:    */   private static File logFolder;
/*  16:    */   private FileHandler logfileHandler;
/*  17:    */   private static LogManager _instance;
/*  18:    */   
/*  19:    */   public static Level getRuleLogLevel()
/*  20:    */   {
/*  21: 41 */     return ruleLogLevel;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static void setDebugMode(String mode)
/*  25:    */   {
/*  26:    */     try
/*  27:    */     {
/*  28: 46 */       debugMode = DebugModes.valueOf(mode);
/*  29:    */     }
/*  30:    */     catch (IllegalArgumentException e)
/*  31:    */     {
/*  32: 48 */       debugMode = DebugModes.off;
/*  33:    */     }
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static void setRuleLogLevel(String level)
/*  37:    */   {
/*  38:    */     try
/*  39:    */     {
/*  40: 54 */       ruleLogLevel = Level.parse(level.toUpperCase());
/*  41:    */     }
/*  42:    */     catch (IllegalArgumentException e)
/*  43:    */     {
/*  44: 56 */       ruleLogLevel = Level.INFO;
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void debugLow(String message)
/*  49:    */   {
/*  50: 61 */     if (debugMode.compareTo(DebugModes.low) >= 0) {
/*  51: 62 */       logger.finer(message);
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void debugMedium(String message)
/*  56:    */   {
/*  57: 67 */     if (debugMode.compareTo(DebugModes.medium) >= 0) {
/*  58: 68 */       logger.finer(message);
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void debugHigh(String message)
/*  63:    */   {
/*  64: 73 */     if (debugMode.compareTo(DebugModes.high) >= 0) {
/*  65: 74 */       logger.finer(message);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static LogManager getInstance(Logger l, File f)
/*  70:    */   {
/*  71: 79 */     if (_instance == null)
/*  72:    */     {
/*  73: 80 */       _instance = new LogManager();
/*  74: 81 */       logger = l;
/*  75: 82 */       logFolder = f;
/*  76:    */     }
/*  77: 84 */     return _instance;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static LogManager getInstance()
/*  81:    */   {
/*  82: 88 */     if (_instance == null) {
/*  83: 89 */       throw new IllegalStateException("LogManager not yet initialized!");
/*  84:    */     }
/*  85: 91 */     return _instance;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void stop()
/*  89:    */   {
/*  90: 96 */     if (this.logfileHandler != null)
/*  91:    */     {
/*  92: 97 */       this.logfileHandler.close();
/*  93: 98 */       logger.removeHandler(this.logfileHandler);
/*  94: 99 */       this.logfileHandler = null;
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static enum DebugModes
/*  99:    */   {
/* 100:104 */     off,  low,  medium,  high;
/* 101:    */     
/* 102:    */     private DebugModes() {}
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void start()
/* 106:    */   {
/* 107:111 */     if (this.logfileHandler == null) {
/* 108:    */       try
/* 109:    */       {
/* 110:114 */         String fileName = new File(logFolder, "pwnfilter.log").toString();
/* 111:115 */         this.logfileHandler = new FileHandler(fileName, true);
/* 112:116 */         SimpleFormatter f = new PwnFormatter();
/* 113:117 */         this.logfileHandler.setFormatter(f);
/* 114:118 */         this.logfileHandler.setLevel(Level.FINEST);
/* 115:119 */         logger.addHandler(this.logfileHandler);
/* 116:120 */         logger.info("Now logging to " + fileName);
/* 117:    */       }
/* 118:    */       catch (IOException e)
/* 119:    */       {
/* 120:123 */         logger.warning("Unable to open logfile.");
/* 121:    */       }
/* 122:    */       catch (SecurityException e)
/* 123:    */       {
/* 124:125 */         logger.warning("Security Exception while trying to add file Handler");
/* 125:    */       }
/* 126:    */     }
/* 127:    */   }
/* 128:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.util.LogManager
 * JD-Core Version:    0.7.0.1
 */