/*   1:    */ package com.pwn9.PwnFilter.rules;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.util.LogManager;
/*   4:    */ import com.pwn9.PwnFilter.util.Patterns;
/*   5:    */ import java.io.BufferedReader;
/*   6:    */ import java.io.File;
/*   7:    */ import java.io.FileReader;
/*   8:    */ import java.util.HashMap;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.logging.Logger;
/*  11:    */ import java.util.regex.Matcher;
/*  12:    */ import java.util.regex.Pattern;
/*  13:    */ 
/*  14:    */ public class ShortCutManager
/*  15:    */ {
/*  16:    */   private static ShortCutManager _instance;
/*  17: 33 */   private static Map<String, Map<String, String>> shortcutFiles = new HashMap();
/*  18:    */   private static File shortcutDir;
/*  19:    */   
/*  20:    */   public static ShortCutManager getInstance()
/*  21:    */   {
/*  22: 39 */     if (_instance == null) {
/*  23: 40 */       _instance = new ShortCutManager();
/*  24:    */     }
/*  25: 42 */     return _instance;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public boolean setShortcutDir(File dir)
/*  29:    */   {
/*  30: 46 */     if (dir.exists())
/*  31:    */     {
/*  32: 47 */       shortcutDir = dir;
/*  33: 48 */       return true;
/*  34:    */     }
/*  35: 49 */     return false;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static String replace(Map<String, String> shortcuts, String lineData)
/*  39:    */   {
/*  40: 54 */     if (shortcuts == null) {
/*  41: 54 */       return lineData;
/*  42:    */     }
/*  43: 56 */     Pattern shortcutMatch = Patterns.compilePattern("<[a-zA-Z_]{0,3}>");
/*  44: 57 */     Matcher matcher = shortcutMatch.matcher(lineData);
/*  45: 58 */     StringBuffer newLineData = new StringBuffer();
/*  46: 59 */     while (matcher.find())
/*  47:    */     {
/*  48: 60 */       String thisMatch = matcher.group();
/*  49: 61 */       String var = thisMatch.substring(1, thisMatch.length() - 1);
/*  50: 62 */       String replacement = (String)shortcuts.get(var.toLowerCase());
/*  51: 63 */       if ((replacement == null) || (replacement.isEmpty()))
/*  52:    */       {
/*  53: 64 */         LogManager.logger.warning("Could not find shortcut: <" + var + ">" + "when parsing: '" + lineData + "'");
/*  54:    */         
/*  55: 66 */         matcher.appendReplacement(newLineData, "");
/*  56:    */       }
/*  57:    */       else
/*  58:    */       {
/*  59: 68 */         matcher.appendReplacement(newLineData, Matcher.quoteReplacement(replacement));
/*  60:    */       }
/*  61:    */     }
/*  62: 71 */     matcher.appendTail(newLineData);
/*  63: 72 */     if (!newLineData.toString().equals(lineData)) {
/*  64: 73 */       LogManager.getInstance().debugHigh("Original regex: " + lineData + "\n New regex: " + newLineData);
/*  65:    */     }
/*  66: 75 */     return newLineData.toString();
/*  67:    */   }
/*  68:    */   
/*  69:    */   public Map<String, String> getShortcutMap(String mapFileName)
/*  70:    */   {
/*  71: 80 */     Map<String, String> returnValue = (Map)shortcutFiles.get(mapFileName);
/*  72: 82 */     if (returnValue != null) {
/*  73: 83 */       return returnValue;
/*  74:    */     }
/*  75: 85 */     loadFile(mapFileName);
/*  76:    */     
/*  77: 87 */     return (Map)shortcutFiles.get(mapFileName);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void reloadFiles()
/*  81:    */   {
/*  82: 92 */     shortcutFiles.clear();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean loadFile(String fileName)
/*  86:    */   {
/*  87: 97 */     Map<String, String> varset = new HashMap();
/*  88:    */     
/*  89: 99 */     File shortcutFile = getFile(fileName);
/*  90:    */     try
/*  91:    */     {
/*  92:103 */       BufferedReader reader = new BufferedReader(new FileReader(shortcutFile));
/*  93:    */       
/*  94:    */ 
/*  95:106 */       int lineNo = 0;
/*  96:    */       String line;
/*  97:108 */       while ((line = reader.readLine()) != null)
/*  98:    */       {
/*  99:109 */         lineNo++;
/* 100:110 */         line = line.trim();
/* 101:    */         
/* 102:112 */         String[] parts = line.split(" ", 2);
/* 103:115 */         if ((parts.length < 2) || (parts[0].length() > 3)) {
/* 104:116 */           LogManager.logger.info("Syntax error in " + fileName + " line: " + lineNo);
/* 105:    */         } else {
/* 106:119 */           varset.put(parts[0].toLowerCase(), parts[1]);
/* 107:    */         }
/* 108:    */       }
/* 109:    */     }
/* 110:    */     catch (Exception e)
/* 111:    */     {
/* 112:124 */       return false;
/* 113:    */     }
/* 114:127 */     shortcutFiles.put(fileName, varset);
/* 115:128 */     return true;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public File getFile(String fileName)
/* 119:    */   {
/* 120:132 */     if (shortcutDir.exists())
/* 121:    */     {
/* 122:133 */       File shortcutFile = new File(shortcutDir, fileName);
/* 123:134 */       if (shortcutFile.exists()) {
/* 124:135 */         return shortcutFile;
/* 125:    */       }
/* 126:137 */       return null;
/* 127:    */     }
/* 128:140 */     LogManager.logger.warning("Unable to find shortcut definition file:" + fileName);
/* 129:141 */     return null;
/* 130:    */   }
/* 131:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.ShortCutManager
 * JD-Core Version:    0.7.0.1
 */