/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ public final class ActionFactory
/*  4:   */ {
/*  5:   */   public static Action getActionFromString(String s)
/*  6:   */   {
/*  7:23 */     String[] parts = s.split("\\s", 2);
/*  8:24 */     String actionName = parts[0];
/*  9:   */     
/* 10:26 */     String actionData = parts.length > 1 ? parts[1] : "";
/* 11:   */     
/* 12:28 */     return getAction(actionName, actionData);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public static Action getAction(String actionName, String actionData)
/* 16:   */   {
/* 17:   */     try
/* 18:   */     {
/* 19:36 */       String className = "com.pwn9.PwnFilter.rules.action.Action" + actionName;
/* 20:37 */       Action newAction = (Action)Class.forName(className).newInstance();
/* 21:38 */       newAction.init(actionData);
/* 22:39 */       return newAction;
/* 23:   */     }
/* 24:   */     catch (ClassNotFoundException ex)
/* 25:   */     {
/* 26:41 */       return null;
/* 27:   */     }
/* 28:   */     catch (InstantiationException ex)
/* 29:   */     {
/* 30:43 */       return null;
/* 31:   */     }
/* 32:   */     catch (IllegalAccessException ex) {}
/* 33:45 */     return null;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.ActionFactory
 * JD-Core Version:    0.7.0.1
 */