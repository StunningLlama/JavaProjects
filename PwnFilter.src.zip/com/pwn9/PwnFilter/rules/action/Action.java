package com.pwn9.PwnFilter.rules.action;

import com.pwn9.PwnFilter.FilterState;

public abstract interface Action
{
  public abstract void init(String paramString);
  
  public abstract boolean execute(FilterState paramFilterState);
}


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Action
 * JD-Core Version:    0.7.0.1
 */