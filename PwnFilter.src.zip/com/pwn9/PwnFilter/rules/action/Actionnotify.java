/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.DataCache;
/*  4:   */ import com.pwn9.PwnFilter.FilterState;
/*  5:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  6:   */ import org.bukkit.Bukkit;
/*  7:   */ import org.bukkit.ChatColor;
/*  8:   */ import org.bukkit.command.ConsoleCommandSender;
/*  9:   */ import org.bukkit.entity.Player;
/* 10:   */ import org.bukkit.scheduler.BukkitRunnable;
/* 11:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 12:   */ 
/* 13:   */ public class Actionnotify
/* 14:   */   implements Action
/* 15:   */ {
/* 16:   */   String permissionString;
/* 17:   */   String messageString;
/* 18:   */   
/* 19:   */   public void init(String s)
/* 20:   */   {
/* 21:33 */     String[] parts = s.split("\\s", 2);
/* 22:   */     
/* 23:35 */     this.permissionString = parts[0];
/* 24:37 */     if (this.permissionString.isEmpty()) {
/* 25:37 */       throw new IllegalArgumentException("'notify' action requires a permission or 'console'");
/* 26:   */     }
/* 27:39 */     if (parts.length > 1) {
/* 28:40 */       this.messageString = ChatColor.translateAlternateColorCodes('&', parts[1]);
/* 29:   */     } else {
/* 30:42 */       throw new IllegalArgumentException("'notify' action requires a message string");
/* 31:   */     }
/* 32:45 */     DataCache.getInstance().addPermission(this.permissionString);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public boolean execute(FilterState state)
/* 36:   */   {
/* 37:52 */     final String sendString = Patterns.replaceVars(this.messageString, state);
/* 38:54 */     if (this.permissionString.equalsIgnoreCase("console")) {
/* 39:55 */       Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 40:   */       {
/* 41:   */         public void run()
/* 42:   */         {
/* 43:58 */           Bukkit.getConsoleSender().sendMessage(sendString);
/* 44:   */         }
/* 45:   */       });
/* 46:   */     } else {
/* 47:63 */       Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 48:   */       {
/* 49:   */         public void run()
/* 50:   */         {
/* 51:66 */           for (Player p : DataCache.getInstance().getOnlinePlayers()) {
/* 52:67 */             if (DataCache.getInstance().hasPermission(p, Actionnotify.this.permissionString)) {
/* 53:68 */               p.sendMessage(sendString);
/* 54:   */             }
/* 55:   */           }
/* 56:   */         }
/* 57:   */       });
/* 58:   */     }
/* 59:75 */     return true;
/* 60:   */   }
/* 61:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionnotify
 * JD-Core Version:    0.7.0.1
 */