/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import org.bukkit.Bukkit;
/*  7:   */ import org.bukkit.entity.Player;
/*  8:   */ import org.bukkit.scheduler.BukkitRunnable;
/*  9:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 10:   */ 
/* 11:   */ public class Actioncmdchain
/* 12:   */   implements Action
/* 13:   */ {
/* 14:   */   String[] commands;
/* 15:   */   
/* 16:   */   public void init(String s)
/* 17:   */   {
/* 18:31 */     this.commands = s.split("\\|");
/* 19:32 */     if (this.commands[0].isEmpty()) {
/* 20:32 */       throw new IllegalArgumentException("No commands were provided to 'cmdchain'");
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean execute(final FilterState state)
/* 25:   */   {
/* 26:36 */     state.cancel = true;
/* 27:37 */     final ArrayList<String> parsedCommands = new ArrayList();
/* 28:39 */     for (String cmd : this.commands) {
/* 29:40 */       parsedCommands.add(Patterns.replaceVars(cmd, state));
/* 30:   */     }
/* 31:42 */     if (state.getPlayer() != null)
/* 32:   */     {
/* 33:43 */       for (String cmd : parsedCommands) {
/* 34:44 */         state.addLogMessage("Helped " + state.playerName + " execute command: " + cmd);
/* 35:   */       }
/* 36:46 */       Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 37:   */       {
/* 38:   */         public void run()
/* 39:   */         {
/* 40:49 */           for (String cmd : parsedCommands) {
/* 41:50 */             state.getPlayer().performCommand(cmd);
/* 42:   */           }
/* 43:   */         }
/* 44:54 */       });
/* 45:55 */       return true;
/* 46:   */     }
/* 47:57 */     state.addLogMessage("Could not execute cmdchain on non-player.");
/* 48:58 */     state.setCancelled(true);
/* 49:59 */     return false;
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actioncmdchain
 * JD-Core Version:    0.7.0.1
 */