/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  5:   */ import com.pwn9.PwnFilter.util.DefaultMessages;
/*  6:   */ import org.bukkit.Bukkit;
/*  7:   */ import org.bukkit.entity.Player;
/*  8:   */ import org.bukkit.scheduler.BukkitRunnable;
/*  9:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 10:   */ 
/* 11:   */ public class Actionkill
/* 12:   */   implements Action
/* 13:   */ {
/* 14:   */   String messageString;
/* 15:   */   
/* 16:   */   public void init(String s)
/* 17:   */   {
/* 18:29 */     this.messageString = DefaultMessages.prepareMessage(s, "burnmsg");
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean execute(final FilterState state)
/* 22:   */   {
/* 23:33 */     if (state.getPlayer() == null) {
/* 24:33 */       return false;
/* 25:   */     }
/* 26:35 */     PwnFilter.addKilledPlayer(state.getPlayer(), state.playerName + " " + this.messageString);
/* 27:36 */     state.addLogMessage("Killed by Filter: " + state.playerName + " " + this.messageString);
/* 28:   */     
/* 29:38 */     Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 30:   */     {
/* 31:   */       public void run()
/* 32:   */       {
/* 33:41 */         state.getPlayer().setHealth(0.0D);
/* 34:   */       }
/* 35:43 */     });
/* 36:44 */     return true;
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionkill
 * JD-Core Version:    0.7.0.1
 */