/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.rules.Rule;
/*  5:   */ import com.pwn9.PwnFilter.util.LogManager;
/*  6:   */ import com.pwn9.PwnFilter.util.PointManager;
/*  7:   */ import org.bukkit.Bukkit;
/*  8:   */ import org.bukkit.ChatColor;
/*  9:   */ import org.bukkit.entity.Player;
/* 10:   */ import org.bukkit.scheduler.BukkitRunnable;
/* 11:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 12:   */ 
/* 13:   */ public class Actionpoints
/* 14:   */   implements Action
/* 15:   */ {
/* 16:   */   String messageString;
/* 17:   */   double pointsAmount;
/* 18:   */   
/* 19:   */   public void init(String s)
/* 20:   */   {
/* 21:34 */     String[] parts = s.split("\\s", 2);
/* 22:   */     try
/* 23:   */     {
/* 24:36 */       this.pointsAmount = Double.parseDouble(parts[0]);
/* 25:   */     }
/* 26:   */     catch (NumberFormatException e)
/* 27:   */     {
/* 28:38 */       throw new IllegalArgumentException("'points' action did not have a valid amount.");
/* 29:   */     }
/* 30:40 */     this.messageString = (parts.length > 1 ? ChatColor.translateAlternateColorCodes('&', parts[1]) : "");
/* 31:   */   }
/* 32:   */   
/* 33:   */   public boolean execute(final FilterState state)
/* 34:   */   {
/* 35:44 */     Player p = state.getPlayer();
/* 36:46 */     if (p == null) {
/* 37:46 */       return false;
/* 38:   */     }
/* 39:   */     PointManager pm;
/* 40:   */     try
/* 41:   */     {
/* 42:50 */       pm = PointManager.getInstance();
/* 43:   */     }
/* 44:   */     catch (IllegalStateException ex)
/* 45:   */     {
/* 46:52 */       LogManager.getInstance().debugLow(String.format("Rule: %s has 'then points', but PointManager is disabled in config.yml", new Object[] { state.rule.getId() }));
/* 47:53 */       return false;
/* 48:   */     }
/* 49:58 */     pm.addPlayerPoints(p.getName(), Double.valueOf(this.pointsAmount));
/* 50:   */     
/* 51:60 */     state.addLogMessage(String.format("Points Accumulated %s : %f. Total: %f", new Object[] { state.playerName, Double.valueOf(this.pointsAmount), pm.getPlayerPoints(p) }));
/* 52:62 */     if (!this.messageString.isEmpty()) {
/* 53:63 */       Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 54:   */       {
/* 55:   */         public void run()
/* 56:   */         {
/* 57:66 */           state.getPlayer().sendMessage(Actionpoints.this.messageString);
/* 58:   */         }
/* 59:   */       });
/* 60:   */     }
/* 61:71 */     return true;
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionpoints
 * JD-Core Version:    0.7.0.1
 */