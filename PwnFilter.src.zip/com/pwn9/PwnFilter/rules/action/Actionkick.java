/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.util.DefaultMessages;
/*  5:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  6:   */ import org.bukkit.Bukkit;
/*  7:   */ import org.bukkit.entity.Player;
/*  8:   */ import org.bukkit.scheduler.BukkitRunnable;
/*  9:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 10:   */ 
/* 11:   */ public class Actionkick
/* 12:   */   implements Action
/* 13:   */ {
/* 14:   */   String messageString;
/* 15:   */   
/* 16:   */   public void init(String s)
/* 17:   */   {
/* 18:30 */     this.messageString = DefaultMessages.prepareMessage(s, "burnmsg");
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean execute(final FilterState state)
/* 22:   */   {
/* 23:35 */     if (state.getPlayer() == null) {
/* 24:35 */       return false;
/* 25:   */     }
/* 26:36 */     String outMessage = Patterns.replaceVars(this.messageString, state);
/* 27:   */     
/* 28:38 */     state.addLogMessage("Kicked " + state.playerName + ": " + this.messageString);
/* 29:39 */     Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 30:   */     {
/* 31:   */       public void run()
/* 32:   */       {
/* 33:42 */         state.getPlayer().kickPlayer(Actionkick.this.messageString);
/* 34:   */       }
/* 35:45 */     });
/* 36:46 */     return true;
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionkick
 * JD-Core Version:    0.7.0.1
 */