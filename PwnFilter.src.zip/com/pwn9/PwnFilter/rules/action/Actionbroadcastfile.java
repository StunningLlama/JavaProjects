/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  5:   */ import com.pwn9.PwnFilter.util.FileUtil;
/*  6:   */ import com.pwn9.PwnFilter.util.LogManager;
/*  7:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  8:   */ import java.io.BufferedReader;
/*  9:   */ import java.io.File;
/* 10:   */ import java.io.FileInputStream;
/* 11:   */ import java.io.FileNotFoundException;
/* 12:   */ import java.io.IOException;
/* 13:   */ import java.io.InputStreamReader;
/* 14:   */ import java.util.ArrayList;
/* 15:   */ import java.util.logging.Logger;
/* 16:   */ import org.bukkit.Bukkit;
/* 17:   */ import org.bukkit.ChatColor;
/* 18:   */ import org.bukkit.scheduler.BukkitRunnable;
/* 19:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 20:   */ 
/* 21:   */ public class Actionbroadcastfile
/* 22:   */   implements Action
/* 23:   */ {
/* 24:30 */   ArrayList<String> messageStrings = new ArrayList();
/* 25:   */   
/* 26:   */   public void init(String s)
/* 27:   */   {
/* 28:34 */     File textDir = PwnFilter.getInstance().getTextDir();
/* 29:35 */     if (textDir == null) {
/* 30:35 */       return;
/* 31:   */     }
/* 32:37 */     File textfile = FileUtil.getFile(textDir, s, false);
/* 33:38 */     if (textfile == null) {
/* 34:38 */       return;
/* 35:   */     }
/* 36:   */     try
/* 37:   */     {
/* 38:41 */       FileInputStream fs = new FileInputStream(textfile);
/* 39:42 */       BufferedReader br = new BufferedReader(new InputStreamReader(fs));
/* 40:   */       String message;
/* 41:44 */       while ((message = br.readLine()) != null) {
/* 42:45 */         this.messageStrings.add(ChatColor.translateAlternateColorCodes('&', message));
/* 43:   */       }
/* 44:   */     }
/* 45:   */     catch (FileNotFoundException ex)
/* 46:   */     {
/* 47:48 */       LogManager.logger.warning("File not found while trying to add Action: " + ex.getMessage());
/* 48:   */     }
/* 49:   */     catch (IOException ex)
/* 50:   */     {
/* 51:50 */       LogManager.logger.warning("Error reading: " + textfile.getName());
/* 52:   */     }
/* 53:   */   }
/* 54:   */   
/* 55:   */   public boolean execute(FilterState state)
/* 56:   */   {
/* 57:55 */     final ArrayList<String> preparedMessages = new ArrayList();
/* 58:57 */     for (String message : this.messageStrings) {
/* 59:58 */       preparedMessages.add(Patterns.replaceVars(message, state));
/* 60:   */     }
/* 61:61 */     state.addLogMessage("Broadcasted: " + (String)preparedMessages.get(0) + (preparedMessages.size() > 1 ? "..." : ""));
/* 62:   */     
/* 63:63 */     Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 64:   */     {
/* 65:   */       public void run()
/* 66:   */       {
/* 67:66 */         for (String m : preparedMessages) {
/* 68:67 */           Bukkit.broadcastMessage(m);
/* 69:   */         }
/* 70:   */       }
/* 71:71 */     });
/* 72:72 */     return true;
/* 73:   */   }
/* 74:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionbroadcastfile
 * JD-Core Version:    0.7.0.1
 */