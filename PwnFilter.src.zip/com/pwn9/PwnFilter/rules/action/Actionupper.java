/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.rules.Rule;
/*  5:   */ import com.pwn9.PwnFilter.util.ColoredString;
/*  6:   */ 
/*  7:   */ public class Actionupper
/*  8:   */   implements Action
/*  9:   */ {
/* 10:   */   public void init(String s) {}
/* 11:   */   
/* 12:   */   public boolean execute(FilterState state)
/* 13:   */   {
/* 14:28 */     ColoredString cs = state.getModifiedMessage();
/* 15:29 */     state.addLogMessage("Converting to uppercase.");
/* 16:30 */     state.setModifiedMessage(cs.patternToUpper(state.pattern));
/* 17:32 */     if (state.rule.modifyRaw()) {
/* 18:34 */       state.setUnfilteredMessage(state.getUnfilteredMessage().patternToUpper(state.pattern));
/* 19:   */     }
/* 20:35 */     return true;
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionupper
 * JD-Core Version:    0.7.0.1
 */