/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ 
/*  5:   */ public class Actiondeny
/*  6:   */   implements Action
/*  7:   */ {
/*  8:   */   public void init(String s) {}
/*  9:   */   
/* 10:   */   public boolean execute(FilterState state)
/* 11:   */   {
/* 12:27 */     state.cancel = true;
/* 13:28 */     return true;
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actiondeny
 * JD-Core Version:    0.7.0.1
 */