/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  5:   */ import org.bukkit.Bukkit;
/*  6:   */ import org.bukkit.scheduler.BukkitRunnable;
/*  7:   */ import org.bukkit.scheduler.BukkitScheduler;
/*  8:   */ 
/*  9:   */ public class Actionconsole
/* 10:   */   implements Action
/* 11:   */ {
/* 12:   */   String command;
/* 13:   */   
/* 14:   */   public void init(String s)
/* 15:   */   {
/* 16:27 */     if ((this.command = s).isEmpty()) {
/* 17:27 */       throw new IllegalArgumentException("No command was provided to 'console'");
/* 18:   */     }
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean execute(FilterState state)
/* 22:   */   {
/* 23:32 */     final String cmd = Patterns.replaceVars(this.command, state);
/* 24:33 */     state.addLogMessage("Sending console command: " + cmd);
/* 25:34 */     Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 26:   */     {
/* 27:   */       public void run()
/* 28:   */       {
/* 29:37 */         Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
/* 30:   */       }
/* 31:39 */     });
/* 32:40 */     return true;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionconsole
 * JD-Core Version:    0.7.0.1
 */