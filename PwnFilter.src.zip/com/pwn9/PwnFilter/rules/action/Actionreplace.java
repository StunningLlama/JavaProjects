/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.rules.Rule;
/*  5:   */ import com.pwn9.PwnFilter.util.ColoredString;
/*  6:   */ import org.bukkit.ChatColor;
/*  7:   */ 
/*  8:   */ public class Actionreplace
/*  9:   */   implements Action
/* 10:   */ {
/* 11:22 */   String messageString = "";
/* 12:   */   
/* 13:   */   public void init(String s)
/* 14:   */   {
/* 15:27 */     this.messageString = ChatColor.translateAlternateColorCodes('&', s).replaceAll("\"", "");
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean execute(FilterState state)
/* 19:   */   {
/* 20:31 */     state.setModifiedMessage(state.getModifiedMessage().decolor().replaceText(state.pattern, this.messageString));
/* 21:33 */     if (state.rule.modifyRaw()) {
/* 22:34 */       state.setUnfilteredMessage(state.getUnfilteredMessage().replaceText(state.pattern, this.messageString));
/* 23:   */     }
/* 24:36 */     return true;
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionreplace
 * JD-Core Version:    0.7.0.1
 */