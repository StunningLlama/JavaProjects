/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.util.ColoredString;
/*  5:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  6:   */ import org.bukkit.Bukkit;
/*  7:   */ import org.bukkit.entity.Player;
/*  8:   */ import org.bukkit.scheduler.BukkitRunnable;
/*  9:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 10:   */ 
/* 11:   */ public class Actioncommand
/* 12:   */   implements Action
/* 13:   */ {
/* 14:   */   String command;
/* 15:   */   
/* 16:   */   public void init(String s)
/* 17:   */   {
/* 18:27 */     if ((this.command = s).isEmpty()) {
/* 19:27 */       throw new IllegalArgumentException("No command was provided to 'command'");
/* 20:   */     }
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean execute(final FilterState state)
/* 24:   */   {
/* 25:31 */     state.cancel = true;
/* 26:33 */     if (state.getPlayer() != null)
/* 27:   */     {
/* 28:   */       final String cmd;
/* 29:34 */       if (!this.command.isEmpty())
/* 30:   */       {
/* 31:35 */         String cmd = Patterns.replaceVars(this.command, state);
/* 32:36 */         state.addLogMessage("Helped " + state.playerName + " execute command: " + cmd);
/* 33:   */       }
/* 34:   */       else
/* 35:   */       {
/* 36:38 */         cmd = state.getModifiedMessage().getColoredString();
/* 37:   */       }
/* 38:40 */       state.addLogMessage("Helped " + state.playerName + " execute command: " + cmd);
/* 39:41 */       Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 40:   */       {
/* 41:   */         public void run()
/* 42:   */         {
/* 43:44 */           state.getPlayer().chat("/" + cmd);
/* 44:   */         }
/* 45:47 */       });
/* 46:48 */       return true;
/* 47:   */     }
/* 48:50 */     state.addLogMessage("Could not execute command as non-player.");
/* 49:51 */     state.setCancelled(true);
/* 50:52 */     return false;
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actioncommand
 * JD-Core Version:    0.7.0.1
 */