/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.rules.Rule;
/*  5:   */ import com.pwn9.PwnFilter.util.ColoredString;
/*  6:   */ import java.util.Random;
/*  7:   */ 
/*  8:   */ public class Actionrandrep
/*  9:   */   implements Action
/* 10:   */ {
/* 11:22 */   private static Random random = new Random();
/* 12:   */   String[] toRand;
/* 13:   */   
/* 14:   */   public void init(String s)
/* 15:   */   {
/* 16:29 */     this.toRand = s.split("\\|");
/* 17:30 */     if (this.toRand[0].isEmpty()) {
/* 18:30 */       throw new IllegalArgumentException("'randrep' requires at least one replacement string.");
/* 19:   */     }
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean execute(FilterState state)
/* 23:   */   {
/* 24:34 */     int randomInt = random.nextInt(this.toRand.length);
/* 25:35 */     state.setModifiedMessage(state.getModifiedMessage().replaceText(state.pattern, this.toRand[randomInt]));
/* 26:37 */     if (state.rule.modifyRaw()) {
/* 27:38 */       state.setUnfilteredMessage(state.getUnfilteredMessage().replaceText(state.pattern, this.toRand[randomInt]));
/* 28:   */     }
/* 29:40 */     return true;
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionrandrep
 * JD-Core Version:    0.7.0.1
 */