/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  5:   */ import com.pwn9.PwnFilter.util.DefaultMessages;
/*  6:   */ import net.milkbowl.vault.economy.Economy;
/*  7:   */ import net.milkbowl.vault.economy.EconomyResponse;
/*  8:   */ import org.bukkit.Bukkit;
/*  9:   */ import org.bukkit.entity.Player;
/* 10:   */ import org.bukkit.scheduler.BukkitRunnable;
/* 11:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 12:   */ 
/* 13:   */ public class Actionfine
/* 14:   */   implements Action
/* 15:   */ {
/* 16:   */   String messageString;
/* 17:   */   double fineAmount;
/* 18:   */   
/* 19:   */   public void init(String s)
/* 20:   */   {
/* 21:31 */     if (PwnFilter.economy == null) {
/* 22:32 */       throw new IllegalArgumentException("Parsed rule requiring an Economy, but one was not detected. Check Vault configuration, or remove 'then fine' rules.");
/* 23:   */     }
/* 24:38 */     String[] parts = s.split("\\s", 2);
/* 25:   */     try
/* 26:   */     {
/* 27:40 */       this.fineAmount = Double.parseDouble(parts[0]);
/* 28:   */     }
/* 29:   */     catch (NumberFormatException e)
/* 30:   */     {
/* 31:42 */       throw new IllegalArgumentException("'fine' action did not have a valid amount.");
/* 32:   */     }
/* 33:45 */     this.messageString = DefaultMessages.prepareMessage(parts.length > 1 ? parts[1] : "", "finemsg");
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean execute(final FilterState state)
/* 37:   */   {
/* 38:50 */     if (state.getPlayer() == null) {
/* 39:50 */       return false;
/* 40:   */     }
/* 41:52 */     if (PwnFilter.economy != null)
/* 42:   */     {
/* 43:53 */       EconomyResponse resp = PwnFilter.economy.withdrawPlayer(state.playerName, this.fineAmount);
/* 44:54 */       if (resp.transactionSuccess())
/* 45:   */       {
/* 46:55 */         state.addLogMessage(String.format("Fined %s : %f", new Object[] { state.playerName, Double.valueOf(resp.amount) }));
/* 47:   */       }
/* 48:   */       else
/* 49:   */       {
/* 50:57 */         state.addLogMessage(String.format("Failed to fine %s : %f. Error: %s", new Object[] { state.playerName, Double.valueOf(resp.amount), resp.errorMessage }));
/* 51:   */         
/* 52:59 */         return false;
/* 53:   */       }
/* 54:61 */       Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 55:   */       {
/* 56:   */         public void run()
/* 57:   */         {
/* 58:64 */           state.getPlayer().sendMessage(Actionfine.this.messageString);
/* 59:   */         }
/* 60:67 */       });
/* 61:68 */       return true;
/* 62:   */     }
/* 63:70 */     return false;
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionfine
 * JD-Core Version:    0.7.0.1
 */