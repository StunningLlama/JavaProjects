/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.util.DefaultMessages;
/*  5:   */ import org.bukkit.Bukkit;
/*  6:   */ import org.bukkit.entity.Player;
/*  7:   */ import org.bukkit.scheduler.BukkitRunnable;
/*  8:   */ import org.bukkit.scheduler.BukkitScheduler;
/*  9:   */ 
/* 10:   */ public class Actionburn
/* 11:   */   implements Action
/* 12:   */ {
/* 13:   */   String messageString;
/* 14:   */   
/* 15:   */   public void init(String s)
/* 16:   */   {
/* 17:31 */     this.messageString = DefaultMessages.prepareMessage(s, "burnmsg");
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean execute(final FilterState state)
/* 21:   */   {
/* 22:35 */     if (state.getPlayer() != null)
/* 23:   */     {
/* 24:36 */       Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 25:   */       {
/* 26:   */         public void run()
/* 27:   */         {
/* 28:39 */           state.getPlayer().setFireTicks(5000);
/* 29:40 */           state.getPlayer().sendMessage(Actionburn.this.messageString);
/* 30:   */         }
/* 31:43 */       });
/* 32:44 */       state.addLogMessage("Burned " + state.playerName + ": " + this.messageString);
/* 33:45 */       return true;
/* 34:   */     }
/* 35:47 */     return false;
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionburn
 * JD-Core Version:    0.7.0.1
 */