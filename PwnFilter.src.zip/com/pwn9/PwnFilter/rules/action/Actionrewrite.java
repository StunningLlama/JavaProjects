/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.rules.Rule;
/*  5:   */ import com.pwn9.PwnFilter.util.ColoredString;
/*  6:   */ import org.bukkit.ChatColor;
/*  7:   */ 
/*  8:   */ public class Actionrewrite
/*  9:   */   implements Action
/* 10:   */ {
/* 11:22 */   String messageString = "";
/* 12:   */   
/* 13:   */   public void init(String s)
/* 14:   */   {
/* 15:26 */     this.messageString = ChatColor.translateAlternateColorCodes('&', s);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean execute(FilterState state)
/* 19:   */   {
/* 20:30 */     state.setModifiedMessage(state.getModifiedMessage().replaceText(state.pattern, this.messageString));
/* 21:32 */     if (state.rule.modifyRaw()) {
/* 22:33 */       state.setUnfilteredMessage(state.getUnfilteredMessage().replaceText(state.pattern, this.messageString));
/* 23:   */     }
/* 24:35 */     return true;
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionrewrite
 * JD-Core Version:    0.7.0.1
 */