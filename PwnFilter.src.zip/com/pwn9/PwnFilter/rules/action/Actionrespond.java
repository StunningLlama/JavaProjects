/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import org.bukkit.Bukkit;
/*  7:   */ import org.bukkit.ChatColor;
/*  8:   */ import org.bukkit.entity.Player;
/*  9:   */ import org.bukkit.scheduler.BukkitRunnable;
/* 10:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 11:   */ 
/* 12:   */ public class Actionrespond
/* 13:   */   implements Action
/* 14:   */ {
/* 15:26 */   ArrayList<String> messageStrings = new ArrayList();
/* 16:   */   
/* 17:   */   public void init(String s)
/* 18:   */   {
/* 19:30 */     for (String message : s.split("\n")) {
/* 20:31 */       this.messageStrings.add(ChatColor.translateAlternateColorCodes('&', message));
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean execute(final FilterState state)
/* 25:   */   {
/* 26:36 */     if (state.getPlayer() == null) {
/* 27:36 */       return false;
/* 28:   */     }
/* 29:38 */     final ArrayList<String> preparedMessages = new ArrayList();
/* 30:40 */     for (String message : this.messageStrings) {
/* 31:41 */       preparedMessages.add(Patterns.replaceVars(message, state));
/* 32:   */     }
/* 33:44 */     state.addLogMessage("Responded to " + state.playerName + " with: " + (String)preparedMessages.get(0) + "...");
/* 34:   */     
/* 35:46 */     Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 36:   */     {
/* 37:   */       public void run()
/* 38:   */       {
/* 39:49 */         for (String m : preparedMessages) {
/* 40:50 */           state.getPlayer().sendMessage(m);
/* 41:   */         }
/* 42:   */       }
/* 43:54 */     });
/* 44:55 */     return true;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionrespond
 * JD-Core Version:    0.7.0.1
 */