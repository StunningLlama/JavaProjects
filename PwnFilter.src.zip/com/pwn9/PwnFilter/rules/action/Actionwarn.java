/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.util.DefaultMessages;
/*  5:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  6:   */ import org.bukkit.Bukkit;
/*  7:   */ import org.bukkit.entity.Player;
/*  8:   */ import org.bukkit.scheduler.BukkitRunnable;
/*  9:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 10:   */ 
/* 11:   */ public class Actionwarn
/* 12:   */   implements Action
/* 13:   */ {
/* 14:   */   String messageString;
/* 15:   */   
/* 16:   */   public void init(String s)
/* 17:   */   {
/* 18:29 */     this.messageString = DefaultMessages.prepareMessage(s, "warnmsg");
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean execute(final FilterState state)
/* 22:   */   {
/* 23:33 */     if (state.getPlayer() == null) {
/* 24:33 */       return false;
/* 25:   */     }
/* 26:34 */     final String message = Patterns.replaceVars(this.messageString, state);
/* 27:35 */     state.addLogMessage("Warned " + state.playerName + ": " + message);
/* 28:36 */     Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 29:   */     {
/* 30:   */       public void run()
/* 31:   */       {
/* 32:39 */         state.getPlayer().sendMessage(message);
/* 33:   */       }
/* 34:42 */     });
/* 35:43 */     return true;
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionwarn
 * JD-Core Version:    0.7.0.1
 */