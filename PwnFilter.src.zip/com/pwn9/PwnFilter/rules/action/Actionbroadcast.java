/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import org.bukkit.Bukkit;
/*  7:   */ import org.bukkit.ChatColor;
/*  8:   */ import org.bukkit.scheduler.BukkitRunnable;
/*  9:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 10:   */ 
/* 11:   */ public class Actionbroadcast
/* 12:   */   implements Action
/* 13:   */ {
/* 14:26 */   ArrayList<String> messageStrings = new ArrayList();
/* 15:   */   
/* 16:   */   public void init(String s)
/* 17:   */   {
/* 18:30 */     for (String message : s.split("\n")) {
/* 19:31 */       this.messageStrings.add(ChatColor.translateAlternateColorCodes('&', message));
/* 20:   */     }
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean execute(FilterState state)
/* 24:   */   {
/* 25:37 */     final ArrayList<String> preparedMessages = new ArrayList();
/* 26:39 */     for (String message : this.messageStrings) {
/* 27:40 */       preparedMessages.add(Patterns.replaceVars(message, state));
/* 28:   */     }
/* 29:43 */     state.addLogMessage("Broadcasted: " + (String)preparedMessages.get(0) + (preparedMessages.size() > 1 ? "..." : ""));
/* 30:   */     
/* 31:45 */     Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 32:   */     {
/* 33:   */       public void run()
/* 34:   */       {
/* 35:48 */         for (String m : preparedMessages) {
/* 36:49 */           Bukkit.broadcastMessage(m);
/* 37:   */         }
/* 38:   */       }
/* 39:53 */     });
/* 40:54 */     return true;
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionbroadcast
 * JD-Core Version:    0.7.0.1
 */