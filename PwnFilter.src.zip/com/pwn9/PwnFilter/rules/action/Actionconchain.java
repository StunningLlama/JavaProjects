/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import org.bukkit.Bukkit;
/*  7:   */ import org.bukkit.scheduler.BukkitRunnable;
/*  8:   */ import org.bukkit.scheduler.BukkitScheduler;
/*  9:   */ 
/* 10:   */ public class Actionconchain
/* 11:   */   implements Action
/* 12:   */ {
/* 13:   */   String[] commands;
/* 14:   */   
/* 15:   */   public void init(String s)
/* 16:   */   {
/* 17:29 */     this.commands = s.split("\\|");
/* 18:30 */     if (this.commands[0].isEmpty()) {
/* 19:30 */       throw new IllegalArgumentException("No commands were provided to 'conchain'");
/* 20:   */     }
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean execute(FilterState state)
/* 24:   */   {
/* 25:34 */     final ArrayList<String> parsedCommands = new ArrayList();
/* 26:36 */     for (String cmd : this.commands) {
/* 27:37 */       parsedCommands.add(Patterns.replaceVars(cmd, state));
/* 28:   */     }
/* 29:39 */     for (String cmd : parsedCommands) {
/* 30:40 */       state.addLogMessage("Sending console command: " + cmd);
/* 31:   */     }
/* 32:42 */     Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 33:   */     {
/* 34:   */       public void run()
/* 35:   */       {
/* 36:45 */         for (String cmd : parsedCommands) {
/* 37:46 */           Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
/* 38:   */         }
/* 39:   */       }
/* 40:49 */     });
/* 41:50 */     return true;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionconchain
 * JD-Core Version:    0.7.0.1
 */