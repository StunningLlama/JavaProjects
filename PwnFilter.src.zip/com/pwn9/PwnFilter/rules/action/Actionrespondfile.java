/*  1:   */ package com.pwn9.PwnFilter.rules.action;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.FilterState;
/*  4:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  5:   */ import com.pwn9.PwnFilter.util.LogManager;
/*  6:   */ import com.pwn9.PwnFilter.util.Patterns;
/*  7:   */ import java.io.BufferedReader;
/*  8:   */ import java.io.FileNotFoundException;
/*  9:   */ import java.io.IOException;
/* 10:   */ import java.util.ArrayList;
/* 11:   */ import java.util.logging.Logger;
/* 12:   */ import org.bukkit.Bukkit;
/* 13:   */ import org.bukkit.ChatColor;
/* 14:   */ import org.bukkit.entity.Player;
/* 15:   */ import org.bukkit.scheduler.BukkitRunnable;
/* 16:   */ import org.bukkit.scheduler.BukkitScheduler;
/* 17:   */ 
/* 18:   */ public class Actionrespondfile
/* 19:   */   implements Action
/* 20:   */ {
/* 21:31 */   ArrayList<String> messageStrings = new ArrayList();
/* 22:   */   
/* 23:   */   public void init(String s)
/* 24:   */   {
/* 25:   */     try
/* 26:   */     {
/* 27:36 */       BufferedReader br = PwnFilter.getInstance().getBufferedReader(s);
/* 28:   */       String message;
/* 29:38 */       while ((message = br.readLine()) != null) {
/* 30:39 */         this.messageStrings.add(ChatColor.translateAlternateColorCodes('&', message));
/* 31:   */       }
/* 32:   */     }
/* 33:   */     catch (FileNotFoundException ex)
/* 34:   */     {
/* 35:42 */       LogManager.logger.warning("File not found while trying to add Action: " + ex.getMessage());
/* 36:43 */       this.messageStrings.add("[PwnFilter] Configuration error: file not found.");
/* 37:   */     }
/* 38:   */     catch (IOException ex)
/* 39:   */     {
/* 40:45 */       LogManager.logger.warning("Error reading file: " + s);
/* 41:46 */       this.messageStrings.add("[PwnFilter] Error: respondfile IO.  Please notify admins.");
/* 42:   */     }
/* 43:   */   }
/* 44:   */   
/* 45:   */   public boolean execute(final FilterState state)
/* 46:   */   {
/* 47:51 */     final ArrayList<String> preparedMessages = new ArrayList();
/* 48:53 */     for (String message : this.messageStrings) {
/* 49:54 */       preparedMessages.add(Patterns.replaceVars(message, state));
/* 50:   */     }
/* 51:57 */     state.addLogMessage("Responded to " + state.playerName + " with: " + (String)preparedMessages.get(0) + "...");
/* 52:   */     
/* 53:59 */     Bukkit.getScheduler().runTask(state.plugin, new BukkitRunnable()
/* 54:   */     {
/* 55:   */       public void run()
/* 56:   */       {
/* 57:62 */         for (String m : preparedMessages) {
/* 58:63 */           state.getPlayer().sendMessage(m);
/* 59:   */         }
/* 60:   */       }
/* 61:67 */     });
/* 62:68 */     return true;
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.action.Actionrespondfile
 * JD-Core Version:    0.7.0.1
 */