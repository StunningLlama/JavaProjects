/*   1:    */ package com.pwn9.PwnFilter.rules;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.FilterState;
/*   4:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   5:    */ import com.pwn9.PwnFilter.api.FilterClient;
/*   6:    */ import com.pwn9.PwnFilter.rules.action.Action;
/*   7:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*   8:    */ import com.pwn9.PwnFilter.util.LimitedRegexCharSequence;
/*   9:    */ import com.pwn9.PwnFilter.util.LogManager;
/*  10:    */ import com.pwn9.PwnFilter.util.LogManager.DebugModes;
/*  11:    */ import com.pwn9.PwnFilter.util.Patterns;
/*  12:    */ import com.pwn9.PwnFilter.util.Tracker;
/*  13:    */ import java.util.ArrayList;
/*  14:    */ import java.util.Collection;
/*  15:    */ import java.util.Collections;
/*  16:    */ import java.util.HashSet;
/*  17:    */ import java.util.List;
/*  18:    */ import java.util.Set;
/*  19:    */ import java.util.logging.Logger;
/*  20:    */ import java.util.regex.Matcher;
/*  21:    */ import java.util.regex.Pattern;
/*  22:    */ 
/*  23:    */ public class Rule
/*  24:    */   implements ChainEntry
/*  25:    */ {
/*  26:    */   private Pattern pattern;
/*  27: 33 */   private String description = "";
/*  28: 34 */   private String id = "";
/*  29: 35 */   private boolean modifyRaw = false;
/*  30: 37 */   List<Condition> conditions = new ArrayList();
/*  31: 38 */   List<Action> actions = new ArrayList();
/*  32: 39 */   public List<String> includeEvents = new ArrayList();
/*  33: 40 */   public List<String> excludeEvents = new ArrayList();
/*  34:    */   
/*  35:    */   public Rule() {}
/*  36:    */   
/*  37:    */   public Rule(String matchStr)
/*  38:    */   {
/*  39: 47 */     this.pattern = Patterns.compilePattern(matchStr);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Rule(String id, String description)
/*  43:    */   {
/*  44: 51 */     this.id = id;
/*  45: 52 */     this.description = description;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public Pattern getPattern()
/*  49:    */   {
/*  50: 56 */     return this.pattern;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public String getDescription()
/*  54:    */   {
/*  55: 60 */     return this.description;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public String getId()
/*  59:    */   {
/*  60: 64 */     return this.id;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void setPattern(String pattern)
/*  64:    */   {
/*  65: 68 */     this.pattern = Patterns.compilePattern(pattern);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setDescription(String description)
/*  69:    */   {
/*  70: 72 */     this.description = description;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void setId(String id)
/*  74:    */   {
/*  75: 76 */     this.id = id;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Set<String> getPermissionList()
/*  79:    */   {
/*  80: 81 */     Set<String> permList = new HashSet();
/*  81: 83 */     for (Condition c : this.conditions) {
/*  82: 84 */       if (c.type == Condition.CondType.permission) {
/*  83: 85 */         Collections.addAll(permList, c.parameters.split("\\|"));
/*  84:    */       }
/*  85:    */     }
/*  86: 89 */     return permList;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void apply(FilterState state)
/*  90:    */   {
/*  91:102 */     if (LogManager.debugMode.compareTo(LogManager.DebugModes.high) >= 0) {
/*  92:103 */       LogManager.logger.info("Testing Pattern: '" + this.pattern.toString() + "' on string: '" + state.getModifiedMessage().getPlainString() + "'");
/*  93:    */     }
/*  94:106 */     LimitedRegexCharSequence limitedRegexCharSequence = new LimitedRegexCharSequence(state.getModifiedMessage().getPlainString(), 100);
/*  95:107 */     Matcher matcher = this.pattern.matcher(limitedRegexCharSequence);
/*  96:    */     try
/*  97:    */     {
/*  98:110 */       if (!matcher.find()) {
/*  99:110 */         return;
/* 100:    */       }
/* 101:    */     }
/* 102:    */     catch (RuntimeException ex)
/* 103:    */     {
/* 104:112 */       LogManager.logger.severe("Regex match timed out! Regex: " + this.pattern.toString());
/* 105:113 */       LogManager.logger.severe("Failed string was: " + limitedRegexCharSequence);
/* 106:114 */       return;
/* 107:    */     }
/* 108:117 */     state.pattern = this.pattern;
/* 109:118 */     state.rule = this;
/* 110:    */     
/* 111:    */ 
/* 112:121 */     state.addLogMessage("|" + state.listener.getShortName() + "| MATCH " + (this.id.isEmpty() ? "" : new StringBuilder().append("(").append(this.id).append(")").toString()) + " <" + state.playerName + "> " + state.getModifiedMessage().getPlainString());
/* 113:    */     
/* 114:    */ 
/* 115:    */ 
/* 116:125 */     LogManager.getInstance().debugLow("Match String: " + matcher.group());
/* 117:128 */     for (Condition c : this.conditions) {
/* 118:130 */       if (!c.check(state))
/* 119:    */       {
/* 120:131 */         state.addLogMessage("CONDITION not met <" + c.flag.toString() + " " + c.type.toString() + " " + c.parameters + "> " + state.getOriginalMessage());
/* 121:    */         
/* 122:133 */         return;
/* 123:    */       }
/* 124:    */     }
/* 125:138 */     if (PwnFilter.matchTracker != null) {
/* 126:139 */       PwnFilter.matchTracker.increment();
/* 127:    */     }
/* 128:143 */     for (Action a : this.actions) {
/* 129:144 */       a.execute(state);
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   public boolean isValid()
/* 134:    */   {
/* 135:151 */     return (this.pattern != null) && (this.actions != null);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public String toString()
/* 139:    */   {
/* 140:155 */     return this.pattern.toString();
/* 141:    */   }
/* 142:    */   
/* 143:    */   public boolean addCondition(Condition c)
/* 144:    */   {
/* 145:159 */     return (c != null) && (this.conditions.add(c));
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean addConditions(Collection<Condition> conditionList)
/* 149:    */   {
/* 150:162 */     return (conditionList != null) && (this.conditions.addAll(conditionList));
/* 151:    */   }
/* 152:    */   
/* 153:    */   public List<Condition> getConditions()
/* 154:    */   {
/* 155:166 */     return this.conditions;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public boolean addAction(Action a)
/* 159:    */   {
/* 160:170 */     return (a != null) && (this.actions.add(a));
/* 161:    */   }
/* 162:    */   
/* 163:    */   public boolean addActions(Collection<Action> actionList)
/* 164:    */   {
/* 165:174 */     return (actionList != null) && (this.actions.addAll(actionList));
/* 166:    */   }
/* 167:    */   
/* 168:    */   public List<Action> getActions()
/* 169:    */   {
/* 170:178 */     return this.actions;
/* 171:    */   }
/* 172:    */   
/* 173:    */   public boolean modifyRaw()
/* 174:    */   {
/* 175:182 */     return this.modifyRaw;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public void setModifyRaw(boolean modifyRaw)
/* 179:    */   {
/* 180:186 */     this.modifyRaw = modifyRaw;
/* 181:    */   }
/* 182:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.Rule
 * JD-Core Version:    0.7.0.1
 */