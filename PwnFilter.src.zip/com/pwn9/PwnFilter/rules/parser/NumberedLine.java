/*  1:   */ package com.pwn9.PwnFilter.rules.parser;
/*  2:   */ 
/*  3:   */ public class NumberedLine
/*  4:   */ {
/*  5:   */   public final Integer number;
/*  6:   */   public final String string;
/*  7:   */   
/*  8:   */   public NumberedLine(Integer number, String string)
/*  9:   */   {
/* 10:18 */     this.number = number;
/* 11:19 */     this.string = string;
/* 12:   */   }
/* 13:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.parser.NumberedLine
 * JD-Core Version:    0.7.0.1
 */