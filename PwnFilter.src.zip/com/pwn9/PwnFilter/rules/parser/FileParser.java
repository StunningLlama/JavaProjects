/*   1:    */ package com.pwn9.PwnFilter.rules.parser;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.Multimap;
/*   4:    */ import com.pwn9.PwnFilter.rules.Chain;
/*   5:    */ import com.pwn9.PwnFilter.rules.Condition;
/*   6:    */ import com.pwn9.PwnFilter.rules.Rule;
/*   7:    */ import com.pwn9.PwnFilter.rules.RuleManager;
/*   8:    */ import com.pwn9.PwnFilter.rules.ShortCutManager;
/*   9:    */ import com.pwn9.PwnFilter.rules.action.Action;
/*  10:    */ import com.pwn9.PwnFilter.rules.action.ActionFactory;
/*  11:    */ import com.pwn9.PwnFilter.util.LogManager;
/*  12:    */ import java.io.File;
/*  13:    */ import java.io.FileNotFoundException;
/*  14:    */ import java.io.FileReader;
/*  15:    */ import java.io.IOException;
/*  16:    */ import java.util.ArrayList;
/*  17:    */ import java.util.HashSet;
/*  18:    */ import java.util.List;
/*  19:    */ import java.util.Map;
/*  20:    */ import java.util.Set;
/*  21:    */ import java.util.logging.Logger;
/*  22:    */ 
/*  23:    */ public class FileParser
/*  24:    */ {
/*  25:    */   private final String filename;
/*  26:    */   private final FileParser parent;
/*  27:    */   private final boolean createFile;
/*  28:    */   private int lineNo;
/*  29: 38 */   private Map<String, String> shortcuts = null;
/*  30:    */   private Chain chain;
/*  31:    */   
/*  32:    */   public FileParser(String filename, FileParser parent, boolean createFile)
/*  33:    */   {
/*  34: 42 */     this.filename = filename;
/*  35: 43 */     this.parent = parent;
/*  36: 44 */     this.createFile = createFile;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public FileParser(String filename)
/*  40:    */   {
/*  41: 48 */     this(filename, null, true);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public String getFilename()
/*  45:    */   {
/*  46: 52 */     return this.filename;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public FileParser getParent()
/*  50:    */   {
/*  51: 56 */     return this.parent;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public Set<String> getParentFiles()
/*  55:    */   {
/*  56: 60 */     FileParser nextParent = this.parent;
/*  57: 61 */     HashSet<String> result = new HashSet();
/*  58: 63 */     while (nextParent != null)
/*  59:    */     {
/*  60: 64 */       result.add(nextParent.getFilename());
/*  61: 65 */       nextParent = nextParent.getParent();
/*  62:    */     }
/*  63: 68 */     return result;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean parseRules(Chain chain)
/*  67:    */   {
/*  68: 79 */     this.chain = chain;
/*  69: 81 */     if (getParentFiles().contains(this.filename))
/*  70:    */     {
/*  71: 82 */       parserError(this.lineNo, "Recursion loop!  " + this.filename + " is included already!");
/*  72: 83 */       return false;
/*  73:    */     }
/*  74: 87 */     File ruleFile = RuleManager.getInstance().getFile(this.filename, this.createFile);
/*  75: 88 */     if (ruleFile == null)
/*  76:    */     {
/*  77: 89 */       LogManager.logger.warning("File not found: " + this.filename + ". Aborting parsing.");
/*  78: 90 */       return false;
/*  79:    */     }
/*  80:    */     RuleStreamReader reader;
/*  81:    */     try
/*  82:    */     {
/*  83: 93 */       reader = new RuleStreamReader(new FileReader(ruleFile));
/*  84:    */     }
/*  85:    */     catch (FileNotFoundException ex)
/*  86:    */     {
/*  87: 95 */       LogManager.logger.warning("File not found: " + this.filename + ". Aborting parsing.");
/*  88: 96 */       return false;
/*  89:    */     }
/*  90:    */     try
/*  91:    */     {
/*  92:    */       String line;
/*  93:104 */       while ((line = reader.readLine()) != null) {
/*  94:107 */         if (!line.isEmpty())
/*  95:    */         {
/*  96:109 */           TokenString tokenString = new TokenString(line);
/*  97:110 */           String command = tokenString.popToken();
/*  98:111 */           this.lineNo = reader.getLineNumber();
/*  99:    */           try
/* 100:    */           {
/* 101:115 */             if (command.equalsIgnoreCase("actiongroup"))
/* 102:    */             {
/* 103:116 */               String groupName = tokenString.popToken();
/* 104:117 */               parseActionGroup(groupName, reader.readSection());
/* 105:    */             }
/* 106:120 */             else if (command.equalsIgnoreCase("conditiongroup"))
/* 107:    */             {
/* 108:121 */               String groupName = tokenString.popToken();
/* 109:122 */               parseConditionGroup(groupName, reader.readSection());
/* 110:    */             }
/* 111:125 */             else if (command.equalsIgnoreCase("shortcuts"))
/* 112:    */             {
/* 113:126 */               String fileName = tokenString.popToken();
/* 114:127 */               toggleShortcuts(fileName);
/* 115:    */             }
/* 116:130 */             else if (command.equalsIgnoreCase("include"))
/* 117:    */             {
/* 118:131 */               String fileName = tokenString.popToken();
/* 119:132 */               processIncludedFile(fileName);
/* 120:    */             }
/* 121:135 */             else if (command.matches("match|catch|replace|rewrite"))
/* 122:    */             {
/* 123:136 */               String pattern = ShortCutManager.replace(this.shortcuts, tokenString.getString());
/* 124:137 */               parseRule(new Rule(pattern), reader.readSection());
/* 125:    */             }
/* 126:140 */             else if (command.matches("rule"))
/* 127:    */             {
/* 128:141 */               String id = tokenString.popToken();
/* 129:142 */               String descr = tokenString.getString();
/* 130:143 */               parseRule(new Rule(id, descr), reader.readSection());
/* 131:    */             }
/* 132:    */           }
/* 133:    */           catch (ParserException e)
/* 134:    */           {
/* 135:146 */             parserError(e.getLineNo(), e.getMessage());
/* 136:    */           }
/* 137:    */         }
/* 138:    */       }
/* 139:151 */       reader.close();
/* 140:    */     }
/* 141:    */     catch (IOException e)
/* 142:    */     {
/* 143:154 */       LogManager.logger.severe("IO Exception during processing: " + e.getMessage());
/* 144:155 */       return false;
/* 145:    */     }
/* 146:157 */     return !chain.isEmpty();
/* 147:    */   }
/* 148:    */   
/* 149:    */   private boolean parseRule(Rule rule, List<NumberedLine> lines)
/* 150:    */     throws IOException, FileParser.ParserException
/* 151:    */   {
/* 152:165 */     for (NumberedLine line : lines)
/* 153:    */     {
/* 154:166 */       TokenString tokenString = new TokenString(line.string);
/* 155:167 */       String command = tokenString.popToken();
/* 156:170 */       if (command.equalsIgnoreCase("rule"))
/* 157:    */       {
/* 158:171 */         rule.setId(tokenString.popToken());
/* 159:172 */         rule.setDescription(tokenString.getString());
/* 160:    */       }
/* 161:174 */       else if (command.equalsIgnoreCase("match"))
/* 162:    */       {
/* 163:175 */         rule.setPattern(ShortCutManager.replace(this.shortcuts, tokenString.getString()));
/* 164:    */       }
/* 165:178 */       else if (command.equalsIgnoreCase("conditions"))
/* 166:    */       {
/* 167:179 */         String groupName = tokenString.popToken();
/* 168:180 */         if (!rule.addConditions(this.chain.getConditionGroups().get(groupName))) {
/* 169:181 */           throw new ParserException(line.number.intValue(), "Unable to find Condition Group: " + groupName);
/* 170:    */         }
/* 171:    */       }
/* 172:185 */       else if (command.equalsIgnoreCase("actions"))
/* 173:    */       {
/* 174:186 */         String groupName = tokenString.popToken();
/* 175:187 */         if (!rule.addActions(this.chain.getActionGroups().get(groupName))) {
/* 176:188 */           throw new ParserException(line.number.intValue(), "Unable to find Action Group: " + groupName);
/* 177:    */         }
/* 178:    */       }
/* 179:192 */       else if (command.equalsIgnoreCase("then"))
/* 180:    */       {
/* 181:193 */         String actionName = tokenString.popToken();
/* 182:    */         try
/* 183:    */         {
/* 184:195 */           Action newAction = ActionFactory.getAction(actionName, tokenString.getString());
/* 185:196 */           if (!rule.addAction(newAction)) {
/* 186:197 */             throw new ParserException(line.number.intValue(), "Unable to add action to rule: " + actionName);
/* 187:    */           }
/* 188:    */         }
/* 189:    */         catch (IllegalArgumentException ex)
/* 190:    */         {
/* 191:200 */           parserError(line.number.intValue(), "Error in action line: " + ex.getMessage());
/* 192:    */         }
/* 193:    */       }
/* 194:204 */       else if (Condition.isCondition(command))
/* 195:    */       {
/* 196:206 */         Condition newCondition = Condition.newCondition(tokenString.getOriginalString());
/* 197:207 */         if (!rule.addCondition(newCondition)) {
/* 198:208 */           throw new ParserException(line.number.intValue(), "Could not parse condition: " + tokenString.getOriginalString());
/* 199:    */         }
/* 200:    */       }
/* 201:212 */       else if (command.equalsIgnoreCase("events"))
/* 202:    */       {
/* 203:213 */         parserError(line.number.intValue(), "Deprecation warning: 'events' keyword is deprecated.  Please add rules to the correct file instead of using 'events' (eg: command.txt, chat.txt, etc.)");
/* 204:    */         List<String> eventlist;
/* 205:    */         List<String> eventlist;
/* 206:216 */         if (tokenString.getString().matches("^not\b")) {
/* 207:217 */           eventlist = rule.excludeEvents;
/* 208:    */         } else {
/* 209:219 */           eventlist = rule.includeEvents;
/* 210:    */         }
/* 211:    */         String token;
/* 212:222 */         while (!(token = tokenString.popToken()).isEmpty()) {
/* 213:223 */           for (String subtoken : token.split(",")) {
/* 214:224 */             eventlist.add(subtoken.trim().toUpperCase());
/* 215:    */           }
/* 216:    */         }
/* 217:    */       }
/* 218:    */     }
/* 219:229 */     if ((rule != null) && (rule.isValid()))
/* 220:    */     {
/* 221:230 */       this.chain.append(rule);
/* 222:231 */       return true;
/* 223:    */     }
/* 224:234 */     throw new ParserException(this.lineNo, "Unable to parse a valid rule.");
/* 225:    */   }
/* 226:    */   
/* 227:    */   private boolean parseActionGroup(String groupName, List<NumberedLine> lines)
/* 228:    */     throws IOException, FileParser.ParserException
/* 229:    */   {
/* 230:248 */     ArrayList<Action> actionGroup = new ArrayList();
/* 231:250 */     for (NumberedLine line : lines)
/* 232:    */     {
/* 233:251 */       TokenString tString = new TokenString(line.string);
/* 234:252 */       String command = tString.popToken();
/* 235:254 */       if (command.equals("then")) {
/* 236:254 */         command = tString.popToken();
/* 237:    */       }
/* 238:255 */       Action thisAction = ActionFactory.getAction(command, tString.getString());
/* 239:257 */       if (thisAction != null) {
/* 240:258 */         actionGroup.add(thisAction);
/* 241:    */       } else {
/* 242:260 */         throw new ParserException(line.number.intValue(), "Unable to parse action: " + command);
/* 243:    */       }
/* 244:    */     }
/* 245:264 */     if (actionGroup.size() == 0) {
/* 246:265 */       throw new ParserException(this.lineNo, "Empty actionGroup found: " + groupName);
/* 247:    */     }
/* 248:267 */     this.chain.addActionGroup(groupName, actionGroup);
/* 249:268 */     return true;
/* 250:    */   }
/* 251:    */   
/* 252:    */   private boolean parseConditionGroup(String groupName, List<NumberedLine> lines)
/* 253:    */     throws IOException, FileParser.ParserException
/* 254:    */   {
/* 255:283 */     ArrayList<Condition> conditionGroup = new ArrayList();
/* 256:285 */     for (NumberedLine line : lines)
/* 257:    */     {
/* 258:286 */       TokenString tString = new TokenString(line.string);
/* 259:287 */       String command = tString.popToken();
/* 260:    */       
/* 261:289 */       Condition thisCondition = Condition.newCondition(command, tString.getString());
/* 262:291 */       if (thisCondition != null) {
/* 263:292 */         conditionGroup.add(thisCondition);
/* 264:    */       } else {
/* 265:294 */         throw new ParserException(line.number.intValue(), "Unable to parse condition: " + command + " " + tString.getString());
/* 266:    */       }
/* 267:    */     }
/* 268:298 */     if (conditionGroup.size() == 0) {
/* 269:299 */       throw new ParserException(this.lineNo, "Empty Condition Group found: " + groupName);
/* 270:    */     }
/* 271:301 */     this.chain.addConditionGroup(groupName, conditionGroup);
/* 272:302 */     return true;
/* 273:    */   }
/* 274:    */   
/* 275:    */   private void processIncludedFile(String lineData)
/* 276:    */     throws FileParser.ParserException
/* 277:    */   {
/* 278:313 */     LogManager.getInstance().debugMedium("Including chain: " + lineData + " in: " + this.chain.getConfigName());
/* 279:315 */     if (getParentFiles().contains(lineData)) {
/* 280:316 */       throw new ParserException(this.lineNo, "Recursion error.  File: " + lineData + " has already been included.");
/* 281:    */     }
/* 282:318 */     FileParser includedChainParser = new FileParser(lineData, this, false);
/* 283:    */     
/* 284:320 */     includedChainParser.parseRules(this.chain);
/* 285:    */   }
/* 286:    */   
/* 287:    */   private void toggleShortcuts(String name)
/* 288:    */     throws FileParser.ParserException
/* 289:    */   {
/* 290:326 */     if (name.isEmpty())
/* 291:    */     {
/* 292:327 */       this.shortcuts = null;
/* 293:    */     }
/* 294:    */     else
/* 295:    */     {
/* 296:329 */       this.shortcuts = ShortCutManager.getInstance().getShortcutMap(name);
/* 297:330 */       if ((this.shortcuts == null) || (this.shortcuts.isEmpty())) {
/* 298:331 */         throw new ParserException(this.lineNo, "Could not load shortcuts file: " + name);
/* 299:    */       }
/* 300:    */     }
/* 301:    */   }
/* 302:    */   
/* 303:    */   private void parserError(int line, String error)
/* 304:    */   {
/* 305:344 */     LogManager.logger.warning(String.format("Parser Error (%s:%d) %s", new Object[] { this.filename, Integer.valueOf(line), error }));
/* 306:    */   }
/* 307:    */   
/* 308:    */   class ParserException
/* 309:    */     extends Exception
/* 310:    */   {
/* 311:    */     int lineNo;
/* 312:    */     
/* 313:    */     public ParserException(String error)
/* 314:    */     {
/* 315:354 */       super();
/* 316:    */     }
/* 317:    */     
/* 318:    */     public ParserException(int lineNo, String error)
/* 319:    */     {
/* 320:358 */       super();
/* 321:359 */       this.lineNo = lineNo;
/* 322:    */     }
/* 323:    */     
/* 324:    */     public int getLineNo()
/* 325:    */     {
/* 326:363 */       return this.lineNo;
/* 327:    */     }
/* 328:    */   }
/* 329:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.parser.FileParser
 * JD-Core Version:    0.7.0.1
 */