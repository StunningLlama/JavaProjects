/*   1:    */ package com.pwn9.PwnFilter.rules.parser;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.LineNumberReader;
/*   5:    */ import java.io.Reader;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.List;
/*   8:    */ 
/*   9:    */ public class RuleStreamReader
/*  10:    */   extends LineNumberReader
/*  11:    */ {
/*  12:    */   public RuleStreamReader(Reader in)
/*  13:    */   {
/*  14: 35 */     super(in);
/*  15: 36 */     setLineNumber(1);
/*  16:    */   }
/*  17:    */   
/*  18:    */   public RuleStreamReader(Reader in, int sz)
/*  19:    */   {
/*  20: 47 */     super(in, sz);
/*  21: 48 */     setLineNumber(1);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public String readLine()
/*  25:    */     throws IOException
/*  26:    */   {
/*  27: 65 */     String result = null;
/*  28:    */     
/*  29: 67 */     boolean multiline = false;
/*  30:    */     String line;
/*  31: 69 */     while ((line = super.readLine()) != null)
/*  32:    */     {
/*  33: 71 */       line = line.trim();
/*  34: 74 */       if (!line.matches("^#.*")) {
/*  35: 76 */         if ((multiline) && (line.equals("EOF")))
/*  36:    */         {
/*  37: 77 */           result = result.substring(0, result.length() - 1);
/*  38:    */         }
/*  39: 80 */         else if (line.endsWith("<<EOF"))
/*  40:    */         {
/*  41: 81 */           result = line.substring(0, line.length() - 5);
/*  42: 82 */           multiline = true;
/*  43:    */         }
/*  44: 84 */         else if (multiline)
/*  45:    */         {
/*  46: 85 */           result = result + line + '\n';
/*  47:    */         }
/*  48:    */         else
/*  49:    */         {
/*  50: 86 */           return line;
/*  51:    */         }
/*  52:    */       }
/*  53:    */     }
/*  54: 88 */     return result;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public List<NumberedLine> readSection()
/*  58:    */     throws IOException
/*  59:    */   {
/*  60:100 */     List<NumberedLine> result = new ArrayList();
/*  61:    */     String line;
/*  62:103 */     while (((line = readLine()) != null) && 
/*  63:104 */       (!line.isEmpty())) {
/*  64:107 */       result.add(new NumberedLine(Integer.valueOf(getLineNumber()), line));
/*  65:    */     }
/*  66:110 */     return result;
/*  67:    */   }
/*  68:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.parser.RuleStreamReader
 * JD-Core Version:    0.7.0.1
 */