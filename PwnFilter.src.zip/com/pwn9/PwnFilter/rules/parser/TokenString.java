/*  1:   */ package com.pwn9.PwnFilter.rules.parser;
/*  2:   */ 
/*  3:   */ public class TokenString
/*  4:   */ {
/*  5:   */   private final String originalString;
/*  6:   */   private String string;
/*  7:   */   
/*  8:   */   public TokenString(String originalString)
/*  9:   */   {
/* 10:29 */     this.string = (originalString == null ? "" : originalString);
/* 11:30 */     this.originalString = originalString;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String popToken()
/* 15:   */   {
/* 16:44 */     String[] parts = this.string.split("\\s", 2);
/* 17:   */     
/* 18:46 */     this.string = (parts.length == 2 ? parts[1] : "");
/* 19:   */     
/* 20:48 */     return parts[0];
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getString()
/* 24:   */   {
/* 25:52 */     return this.string;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getOriginalString()
/* 29:   */   {
/* 30:56 */     return this.originalString;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void reset()
/* 34:   */   {
/* 35:63 */     this.string = this.originalString;
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.parser.TokenString
 * JD-Core Version:    0.7.0.1
 */