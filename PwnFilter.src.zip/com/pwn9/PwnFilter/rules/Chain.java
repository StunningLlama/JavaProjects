package com.pwn9.PwnFilter.rules;

import com.google.common.collect.Multimap;
import com.pwn9.PwnFilter.rules.action.Action;
import java.util.List;

public abstract interface Chain
{
  public abstract String getConfigName();
  
  public abstract boolean append(ChainEntry paramChainEntry);
  
  public abstract boolean isValid();
  
  public abstract Multimap<String, Action> getActionGroups();
  
  public abstract Multimap<String, Condition> getConditionGroups();
  
  public abstract void resetChain();
  
  public abstract void addConditionGroup(String paramString, List<Condition> paramList);
  
  public abstract void addActionGroup(String paramString, List<Action> paramList);
  
  public abstract boolean isEmpty();
}


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.Chain
 * JD-Core Version:    0.7.0.1
 */