package com.pwn9.PwnFilter.rules;

import com.pwn9.PwnFilter.FilterState;
import java.util.Set;

public abstract interface ChainEntry
{
  public abstract String toString();
  
  public abstract boolean isValid();
  
  public abstract void apply(FilterState paramFilterState);
  
  public abstract Set<String> getPermissionList();
}


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.ChainEntry
 * JD-Core Version:    0.7.0.1
 */