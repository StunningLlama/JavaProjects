/*   1:    */ package com.pwn9.PwnFilter.rules;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   4:    */ import com.pwn9.PwnFilter.util.FileUtil;
/*   5:    */ import com.pwn9.PwnFilter.util.LogManager;
/*   6:    */ import java.io.File;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.HashMap;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.Map;
/*  11:    */ import java.util.Map.Entry;
/*  12:    */ import java.util.Set;
/*  13:    */ import java.util.logging.Logger;
/*  14:    */ import org.bukkit.plugin.PluginLoader;
/*  15:    */ 
/*  16:    */ public class RuleManager
/*  17:    */ {
/*  18: 33 */   private static RuleManager _instance = null;
/*  19: 34 */   private final Map<String, RuleChain> ruleChains = Collections.synchronizedMap(new HashMap());
/*  20:    */   private File ruleDir;
/*  21:    */   private PwnFilter plugin;
/*  22:    */   
/*  23:    */   private RuleManager(PwnFilter p)
/*  24:    */   {
/*  25: 40 */     this.plugin = p;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static RuleManager getInstance()
/*  29:    */   {
/*  30: 44 */     if (_instance == null) {
/*  31: 45 */       throw new IllegalStateException("Rule Manager not initialized.");
/*  32:    */     }
/*  33: 47 */     return _instance;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static RuleManager init(PwnFilter p)
/*  37:    */   {
/*  38: 51 */     if (_instance == null)
/*  39:    */     {
/*  40: 52 */       _instance = new RuleManager(p);
/*  41: 53 */       return _instance;
/*  42:    */     }
/*  43: 55 */     return _instance;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public File getRuleDir()
/*  47:    */   {
/*  48: 60 */     return this.ruleDir;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean setRuleDir(String dirName)
/*  52:    */   {
/*  53: 68 */     if ((dirName != null) && (!dirName.isEmpty())) {
/*  54: 69 */       this.ruleDir = new File(dirName);
/*  55:    */     } else {
/*  56: 71 */       this.ruleDir = new File(this.plugin.getDataFolder(), "rules");
/*  57:    */     }
/*  58: 74 */     if (!this.ruleDir.exists()) {
/*  59:    */       try
/*  60:    */       {
/*  61: 76 */         if (!this.ruleDir.mkdir())
/*  62:    */         {
/*  63: 77 */           LogManager.logger.severe("Unable to create rule directory: " + this.ruleDir.getAbsolutePath());
/*  64: 78 */           LogManager.logger.severe("Disabling PwnFilter");
/*  65: 79 */           this.plugin.getPluginLoader().disablePlugin(this.plugin);
/*  66: 80 */           return false;
/*  67:    */         }
/*  68:    */       }
/*  69:    */       catch (SecurityException ex)
/*  70:    */       {
/*  71: 83 */         LogManager.logger.severe("Unable to create rule directory: " + this.ruleDir.getAbsolutePath());
/*  72: 84 */         LogManager.logger.severe("Exception: " + ex.getMessage());
/*  73: 85 */         LogManager.logger.severe("Disabling PwnFilter");
/*  74: 86 */         this.plugin.getPluginLoader().disablePlugin(this.plugin);
/*  75: 87 */         return false;
/*  76:    */       }
/*  77:    */     }
/*  78: 92 */     return ShortCutManager.getInstance().setShortcutDir(this.ruleDir);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public boolean migrateRules(File dataFolder)
/*  82:    */   {
/*  83: 97 */     File oldRuleFile = new File(dataFolder, "rules.txt");
/*  84: 98 */     if (oldRuleFile.exists()) {
/*  85:    */       try
/*  86:    */       {
/*  87:100 */         LogManager.logger.info("Migrating your old rules.txt into the new rules directory: " + this.ruleDir.getAbsolutePath());
/*  88:101 */         if (!oldRuleFile.renameTo(new File(this.ruleDir, "rules.txt")))
/*  89:    */         {
/*  90:102 */           LogManager.logger.severe("Unable to move old rules.txt file to new dir: " + this.ruleDir.getAbsolutePath());
/*  91:103 */           LogManager.logger.severe("Please look in your plugin directory: " + this.plugin.getDataFolder().getAbsolutePath() + " and manually migrate your rules.");
/*  92:104 */           this.plugin.getPluginLoader().disablePlugin(this.plugin);
/*  93:105 */           return false;
/*  94:    */         }
/*  95:    */       }
/*  96:    */       catch (Exception ex)
/*  97:    */       {
/*  98:108 */         LogManager.logger.severe("Unable to move old rules.txt file to new dir.");
/*  99:109 */         LogManager.logger.severe("Please look in your plugin directory: " + this.plugin.getDataFolder().getAbsolutePath() + " and manually migrate your rules.");
/* 100:110 */         LogManager.logger.severe("Disabling PwnFilter");
/* 101:111 */         this.plugin.getPluginLoader().disablePlugin(this.plugin);
/* 102:112 */         return false;
/* 103:    */       }
/* 104:    */     }
/* 105:115 */     return true;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public RuleChain getRuleChain(String configName)
/* 109:    */   {
/* 110:123 */     if (this.ruleChains.containsKey(configName)) {
/* 111:124 */       return (RuleChain)this.ruleChains.get(configName);
/* 112:    */     }
/* 113:126 */     RuleChain newRuleChain = new RuleChain(configName);
/* 114:127 */     this.ruleChains.put(configName, newRuleChain);
/* 115:128 */     return newRuleChain;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void reloadAllConfigs()
/* 119:    */   {
/* 120:    */     Iterator<Map.Entry<String, RuleChain>> it;
/* 121:142 */     synchronized (this.ruleChains)
/* 122:    */     {
/* 123:143 */       for (RuleChain rc : this.ruleChains.values()) {
/* 124:144 */         rc.resetChain();
/* 125:    */       }
/* 126:148 */       ShortCutManager.getInstance().reloadFiles();
/* 127:151 */       for (Map.Entry<String, RuleChain> entry : this.ruleChains.entrySet()) {
/* 128:152 */         if (((RuleChain)entry.getValue()).loadConfigFile()) {
/* 129:153 */           LogManager.getInstance().debugMedium("Re-loaded RuleChain from config: " + ((RuleChain)entry.getValue()).getConfigName());
/* 130:    */         } else {
/* 131:155 */           LogManager.getInstance().debugMedium("Unable to load RuleChain from config: " + ((RuleChain)entry.getValue()).getConfigName());
/* 132:    */         }
/* 133:    */       }
/* 134:160 */       for (it = this.ruleChains.entrySet().iterator(); it.hasNext();)
/* 135:    */       {
/* 136:161 */         Map.Entry<String, RuleChain> e = (Map.Entry)it.next();
/* 137:162 */         if (!((RuleChain)e.getValue()).isValid()) {
/* 138:163 */           it.remove();
/* 139:    */         }
/* 140:    */       }
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   public File getFile(String fileName, boolean createFile)
/* 145:    */   {
/* 146:170 */     return FileUtil.getFile(this.ruleDir, fileName, createFile);
/* 147:    */   }
/* 148:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.RuleManager
 * JD-Core Version:    0.7.0.1
 */