/*   1:    */ package com.pwn9.PwnFilter.rules;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.FilterState;
/*   4:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*   5:    */ 
/*   6:    */ public class Condition
/*   7:    */ {
/*   8:    */   final CondType type;
/*   9:    */   final CondFlag flag;
/*  10:    */   final String parameters;
/*  11:    */   
/*  12:    */   public static enum CondFlag
/*  13:    */   {
/*  14: 20 */     NONE,  ignore,  require;
/*  15:    */     
/*  16:    */     private CondFlag() {}
/*  17:    */   }
/*  18:    */   
/*  19:    */   public static enum CondType
/*  20:    */   {
/*  21: 24 */     permission,  user,  string,  command;
/*  22:    */     
/*  23:    */     private CondType() {}
/*  24:    */   }
/*  25:    */   
/*  26:    */   public Condition(CondType t, CondFlag f, String p)
/*  27:    */   {
/*  28: 33 */     this.type = t;
/*  29: 34 */     this.flag = f;
/*  30: 35 */     this.parameters = p;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static Condition newCondition(String line)
/*  34:    */   {
/*  35: 39 */     String[] parts = line.split("\\s", 2);
/*  36: 40 */     String conditionName = parts[0];
/*  37:    */     
/*  38: 42 */     String conditionData = parts.length > 1 ? parts[1] : "";
/*  39:    */     
/*  40: 44 */     return newCondition(conditionName, conditionData);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static Condition newCondition(String command, String parameterString)
/*  44:    */   {
/*  45:    */     CondFlag newFlag;
/*  46:    */     try
/*  47:    */     {
/*  48: 54 */       newFlag = CondFlag.valueOf(command);
/*  49:    */     }
/*  50:    */     catch (IllegalArgumentException e)
/*  51:    */     {
/*  52: 56 */       return null;
/*  53:    */     }
/*  54: 59 */     String[] parts = parameterString.split("\\s", 2);
/*  55: 60 */     String subCmd = parts[0].toLowerCase();
/*  56:    */     CondType newType;
/*  57:    */     try
/*  58:    */     {
/*  59: 62 */       newType = CondType.valueOf(subCmd);
/*  60:    */     }
/*  61:    */     catch (IllegalArgumentException e)
/*  62:    */     {
/*  63: 64 */       return null;
/*  64:    */     }
/*  65:    */     String newParameters;
/*  66:    */     String newParameters;
/*  67: 66 */     if (parts.length > 1) {
/*  68: 67 */       newParameters = parts[1];
/*  69:    */     } else {
/*  70: 69 */       newParameters = "";
/*  71:    */     }
/*  72: 72 */     return new Condition(newType, newFlag, newParameters);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static boolean isCondition(String command)
/*  76:    */   {
/*  77:    */     try
/*  78:    */     {
/*  79: 77 */       return CondFlag.valueOf(command) != CondFlag.NONE;
/*  80:    */     }
/*  81:    */     catch (IllegalArgumentException e) {}
/*  82: 79 */     return false;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean check(FilterState state)
/*  86:    */   {
/*  87: 92 */     boolean matched = false;
/*  88: 93 */     switch (1.$SwitchMap$com$pwn9$PwnFilter$rules$Condition$CondType[this.type.ordinal()])
/*  89:    */     {
/*  90:    */     case 1: 
/*  91: 95 */       for (String check : this.parameters.split("\\s")) {
/*  92: 96 */         if (state.playerName.equalsIgnoreCase(check)) {
/*  93: 96 */           matched = true;
/*  94:    */         }
/*  95:    */       }
/*  96:    */     case 2: 
/*  97: 99 */       for (String check : this.parameters.split("\\s")) {
/*  98:100 */         if (state.playerHasPermission(check)) {
/*  99:100 */           matched = true;
/* 100:    */         }
/* 101:    */       }
/* 102:    */     case 3: 
/* 103:103 */       for (String check : this.parameters.split("\\|")) {
/* 104:104 */         if (state.getOriginalMessage().getPlainString().toUpperCase().contains(check.toUpperCase())) {
/* 105:104 */           matched = true;
/* 106:    */         }
/* 107:    */       }
/* 108:    */     case 4: 
/* 109:107 */       for (String check : this.parameters.split("\\|")) {
/* 110:108 */         if (state.getListenerName().equals("COMMAND"))
/* 111:    */         {
/* 112:109 */           String command = state.getOriginalMessage().getPlainString().split("\\s")[0].replaceFirst("^\\/", "");
/* 113:110 */           if (command.toUpperCase().matches(check.toUpperCase())) {
/* 114:110 */             matched = true;
/* 115:    */           }
/* 116:    */         }
/* 117:    */       }
/* 118:    */     }
/* 119:115 */     switch (this.flag)
/* 120:    */     {
/* 121:    */     case ignore: 
/* 122:117 */       return !matched;
/* 123:    */     case require: 
/* 124:119 */       return matched;
/* 125:    */     }
/* 126:122 */     return false;
/* 127:    */   }
/* 128:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.Condition
 * JD-Core Version:    0.7.0.1
 */