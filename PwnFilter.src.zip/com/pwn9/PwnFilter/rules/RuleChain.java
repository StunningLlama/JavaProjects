/*   1:    */ package com.pwn9.PwnFilter.rules;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.ArrayListMultimap;
/*   4:    */ import com.google.common.collect.Multimap;
/*   5:    */ import com.pwn9.PwnFilter.DataCache;
/*   6:    */ import com.pwn9.PwnFilter.FilterState;
/*   7:    */ import com.pwn9.PwnFilter.api.FilterClient;
/*   8:    */ import com.pwn9.PwnFilter.rules.action.Action;
/*   9:    */ import com.pwn9.PwnFilter.rules.parser.FileParser;
/*  10:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*  11:    */ import com.pwn9.PwnFilter.util.LogManager;
/*  12:    */ import java.util.ArrayList;
/*  13:    */ import java.util.Collection;
/*  14:    */ import java.util.List;
/*  15:    */ import java.util.Set;
/*  16:    */ import java.util.TreeSet;
/*  17:    */ import java.util.logging.Logger;
/*  18:    */ import java.util.regex.Pattern;
/*  19:    */ 
/*  20:    */ public class RuleChain
/*  21:    */   implements Chain, ChainEntry
/*  22:    */ {
/*  23:    */   private ChainState chainState;
/*  24:    */   
/*  25:    */   static enum ChainState
/*  26:    */   {
/*  27: 44 */     INIT,  PARTIAL,  READY;
/*  28:    */     
/*  29:    */     private ChainState() {}
/*  30:    */   }
/*  31:    */   
/*  32: 50 */   private List<ChainEntry> chain = new ArrayList();
/*  33: 51 */   private Multimap<String, Action> actionGroups = ArrayListMultimap.create();
/*  34: 52 */   private Multimap<String, Condition> conditionGroups = ArrayListMultimap.create();
/*  35:    */   private final String configName;
/*  36:    */   
/*  37:    */   public RuleChain(String configName)
/*  38:    */   {
/*  39: 58 */     this.configName = configName;
/*  40: 59 */     this.chainState = ChainState.INIT;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public boolean loadConfigFile()
/*  44:    */   {
/*  45: 69 */     resetChain();
/*  46:    */     
/*  47:    */ 
/*  48: 72 */     this.chainState = ChainState.PARTIAL;
/*  49:    */     
/*  50: 74 */     FileParser parser = new FileParser(this.configName);
/*  51: 76 */     if (parser.parseRules(this))
/*  52:    */     {
/*  53: 77 */       this.chainState = ChainState.READY;
/*  54: 78 */       DataCache.getInstance().addPermissions(getPermissionList());
/*  55: 79 */       return true;
/*  56:    */     }
/*  57: 81 */     return false;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public String getConfigName()
/*  61:    */   {
/*  62: 85 */     return this.configName;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public int ruleCount()
/*  66:    */   {
/*  67: 88 */     Integer count = Integer.valueOf(0);
/*  68: 89 */     for (ChainEntry c : this.chain) {
/*  69: 90 */       if ((c instanceof RuleChain))
/*  70:    */       {
/*  71: 91 */         count = Integer.valueOf(count.intValue() + ((RuleChain)c).ruleCount());
/*  72:    */       }
/*  73:    */       else
/*  74:    */       {
/*  75: 92 */         localInteger1 = count;Integer localInteger2 = count = Integer.valueOf(count.intValue() + 1);
/*  76:    */       }
/*  77:    */     }
/*  78:    */     Integer localInteger1;
/*  79: 94 */     return count.intValue();
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void apply(FilterState state)
/*  83:    */     throws IllegalStateException
/*  84:    */   {
/*  85:112 */     if (this.chain == null) {
/*  86:113 */       throw new IllegalStateException("Chain is empty: " + this.configName);
/*  87:    */     }
/*  88:116 */     for (ChainEntry entry : this.chain)
/*  89:    */     {
/*  90:117 */       entry.apply(state);
/*  91:118 */       if (state.stop) {
/*  92:    */         break;
/*  93:    */       }
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void execute(FilterState state)
/*  98:    */   {
/*  99:126 */     LogManager logManager = LogManager.getInstance();
/* 100:    */     
/* 101:128 */     apply(state);
/* 102:130 */     if (state.pattern != null)
/* 103:    */     {
/* 104:131 */       logManager.debugHigh("Debug last match: " + state.pattern.pattern());
/* 105:132 */       logManager.debugHigh("Debug original: " + state.getOriginalMessage().getColoredString());
/* 106:133 */       logManager.debugHigh("Debug current: " + state.getModifiedMessage().getColoredString());
/* 107:134 */       logManager.debugHigh("Debug log: " + (state.log ? "yes" : "no"));
/* 108:135 */       logManager.debugHigh("Debug deny: " + (state.cancel ? "yes" : "no"));
/* 109:    */     }
/* 110:    */     else
/* 111:    */     {
/* 112:137 */       logManager.debugHigh("[PwnFilter] Debug no match: " + state.getOriginalMessage().getColoredString());
/* 113:    */     }
/* 114:140 */     if (state.cancel) {
/* 115:141 */       state.addLogMessage("<" + state.playerName + "> Original message cancelled.");
/* 116:142 */     } else if (state.pattern != null) {
/* 117:143 */       state.addLogMessage("|" + state.listener.getShortName() + "| SENT <" + state.playerName + "> " + state.getModifiedMessage().getPlainString());
/* 118:    */     }
/* 119:147 */     for (String s : state.getLogMessages()) {
/* 120:148 */       if (state.log) {
/* 121:149 */         LogManager.logger.info(s);
/* 122:    */       } else {
/* 123:151 */         LogManager.logger.log(LogManager.getRuleLogLevel(), s);
/* 124:    */       }
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   public boolean append(ChainEntry r)
/* 129:    */   {
/* 130:157 */     if (r.isValid())
/* 131:    */     {
/* 132:158 */       this.chain.add(r);
/* 133:159 */       return true;
/* 134:    */     }
/* 135:160 */     return false;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public List<ChainEntry> getChain()
/* 139:    */   {
/* 140:164 */     return this.chain;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public boolean isEmpty()
/* 144:    */   {
/* 145:168 */     return this.chain.isEmpty();
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean isValid()
/* 149:    */   {
/* 150:172 */     return this.chainState == ChainState.READY;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public Set<String> getPermissionList()
/* 154:    */   {
/* 155:184 */     TreeSet<String> permList = new TreeSet();
/* 156:186 */     for (ChainEntry r : this.chain) {
/* 157:187 */       permList.addAll(r.getPermissionList());
/* 158:    */     }
/* 159:189 */     return permList;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public Multimap<String, Action> getActionGroups()
/* 163:    */   {
/* 164:193 */     return this.actionGroups;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public Multimap<String, Condition> getConditionGroups()
/* 168:    */   {
/* 169:197 */     return this.conditionGroups;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void resetChain()
/* 173:    */   {
/* 174:203 */     this.chain.clear();
/* 175:204 */     this.conditionGroups.clear();
/* 176:205 */     this.actionGroups.clear();
/* 177:206 */     this.chainState = ChainState.INIT;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void addConditionGroup(String name, List<Condition> cGroup)
/* 181:    */   {
/* 182:210 */     if ((name != null) && (cGroup != null)) {
/* 183:211 */       if (this.conditionGroups.get(name).isEmpty()) {
/* 184:212 */         this.conditionGroups.get(name).addAll(cGroup);
/* 185:    */       } else {
/* 186:214 */         LogManager.getInstance().debugLow("Condition Group named '" + name + "' already exists in chain: " + getConfigName());
/* 187:    */       }
/* 188:    */     }
/* 189:    */   }
/* 190:    */   
/* 191:    */   public void addActionGroup(String name, List<Action> aGroup)
/* 192:    */   {
/* 193:219 */     if ((name != null) && (aGroup != null)) {
/* 194:220 */       if (!this.actionGroups.containsKey(name)) {
/* 195:221 */         this.actionGroups.get(name).addAll(aGroup);
/* 196:    */       } else {
/* 197:223 */         LogManager.getInstance().debugLow("Action Group named '" + name + "' already exists in chain: " + getConfigName());
/* 198:    */       }
/* 199:    */     }
/* 200:    */   }
/* 201:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.rules.RuleChain
 * JD-Core Version:    0.7.0.1
 */