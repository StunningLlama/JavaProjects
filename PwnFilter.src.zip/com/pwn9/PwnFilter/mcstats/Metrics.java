/*   1:    */ package com.pwn9.PwnFilter.mcstats;
/*   2:    */ 
/*   3:    */ import java.io.BufferedReader;
/*   4:    */ import java.io.ByteArrayOutputStream;
/*   5:    */ import java.io.File;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStreamReader;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ import java.io.PrintStream;
/*  10:    */ import java.io.UnsupportedEncodingException;
/*  11:    */ import java.net.Proxy;
/*  12:    */ import java.net.URL;
/*  13:    */ import java.net.URLConnection;
/*  14:    */ import java.net.URLEncoder;
/*  15:    */ import java.util.Collections;
/*  16:    */ import java.util.HashSet;
/*  17:    */ import java.util.Iterator;
/*  18:    */ import java.util.LinkedHashSet;
/*  19:    */ import java.util.Set;
/*  20:    */ import java.util.UUID;
/*  21:    */ import java.util.logging.Level;
/*  22:    */ import java.util.logging.Logger;
/*  23:    */ import java.util.zip.GZIPOutputStream;
/*  24:    */ import org.bukkit.Bukkit;
/*  25:    */ import org.bukkit.Server;
/*  26:    */ import org.bukkit.configuration.InvalidConfigurationException;
/*  27:    */ import org.bukkit.configuration.file.YamlConfiguration;
/*  28:    */ import org.bukkit.configuration.file.YamlConfigurationOptions;
/*  29:    */ import org.bukkit.plugin.Plugin;
/*  30:    */ import org.bukkit.plugin.PluginDescriptionFile;
/*  31:    */ import org.bukkit.scheduler.BukkitScheduler;
/*  32:    */ import org.bukkit.scheduler.BukkitTask;
/*  33:    */ 
/*  34:    */ public class Metrics
/*  35:    */ {
/*  36:    */   private static final int REVISION = 7;
/*  37:    */   private static final String BASE_URL = "http://report.mcstats.org";
/*  38:    */   private static final String REPORT_URL = "/plugin/%s";
/*  39:    */   private static final int PING_INTERVAL = 15;
/*  40:    */   private final Plugin plugin;
/*  41: 87 */   private final Set<Graph> graphs = Collections.synchronizedSet(new HashSet());
/*  42:    */   private final YamlConfiguration configuration;
/*  43:    */   private final File configurationFile;
/*  44:    */   private final String guid;
/*  45:    */   private final boolean debug;
/*  46:112 */   private final Object optOutLock = new Object();
/*  47:117 */   private volatile BukkitTask task = null;
/*  48:    */   
/*  49:    */   public Metrics(Plugin plugin)
/*  50:    */     throws IOException
/*  51:    */   {
/*  52:120 */     if (plugin == null) {
/*  53:121 */       throw new IllegalArgumentException("Plugin cannot be null");
/*  54:    */     }
/*  55:124 */     this.plugin = plugin;
/*  56:    */     
/*  57:    */ 
/*  58:127 */     this.configurationFile = getConfigFile();
/*  59:128 */     this.configuration = YamlConfiguration.loadConfiguration(this.configurationFile);
/*  60:    */     
/*  61:    */ 
/*  62:131 */     this.configuration.addDefault("opt-out", Boolean.valueOf(false));
/*  63:132 */     this.configuration.addDefault("guid", UUID.randomUUID().toString());
/*  64:133 */     this.configuration.addDefault("debug", Boolean.valueOf(false));
/*  65:136 */     if (this.configuration.get("guid", null) == null)
/*  66:    */     {
/*  67:137 */       this.configuration.options().header("http://mcstats.org").copyDefaults(true);
/*  68:138 */       this.configuration.save(this.configurationFile);
/*  69:    */     }
/*  70:142 */     this.guid = this.configuration.getString("guid");
/*  71:143 */     this.debug = this.configuration.getBoolean("debug", false);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public Graph createGraph(String name)
/*  75:    */   {
/*  76:154 */     if (name == null) {
/*  77:155 */       throw new IllegalArgumentException("Graph name cannot be null");
/*  78:    */     }
/*  79:159 */     Graph graph = new Graph(name, null);
/*  80:    */     
/*  81:    */ 
/*  82:162 */     this.graphs.add(graph);
/*  83:    */     
/*  84:    */ 
/*  85:165 */     return graph;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void addGraph(Graph graph)
/*  89:    */   {
/*  90:174 */     if (graph == null) {
/*  91:175 */       throw new IllegalArgumentException("Graph cannot be null");
/*  92:    */     }
/*  93:178 */     this.graphs.add(graph);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public boolean start()
/*  97:    */   {
/*  98:189 */     synchronized (this.optOutLock)
/*  99:    */     {
/* 100:191 */       if (isOptOut()) {
/* 101:192 */         return false;
/* 102:    */       }
/* 103:196 */       if (this.task != null) {
/* 104:197 */         return true;
/* 105:    */       }
/* 106:201 */       this.task = this.plugin.getServer().getScheduler().runTaskTimerAsynchronously(this.plugin, new Runnable()
/* 107:    */       {
/* 108:203 */         private boolean firstPost = true;
/* 109:    */         
/* 110:    */         public void run()
/* 111:    */         {
/* 112:    */           try
/* 113:    */           {
/* 114:208 */             synchronized (Metrics.this.optOutLock)
/* 115:    */             {
/* 116:210 */               if ((Metrics.this.isOptOut()) && (Metrics.this.task != null))
/* 117:    */               {
/* 118:211 */                 Metrics.this.task.cancel();
/* 119:212 */                 Metrics.this.task = null;
/* 120:214 */                 for (Metrics.Graph graph : Metrics.this.graphs) {
/* 121:215 */                   graph.onOptOut();
/* 122:    */                 }
/* 123:    */               }
/* 124:    */             }
/* 125:223 */             Metrics.this.postPlugin(!this.firstPost);
/* 126:    */             
/* 127:    */ 
/* 128:    */ 
/* 129:227 */             this.firstPost = false;
/* 130:    */           }
/* 131:    */           catch (IOException e)
/* 132:    */           {
/* 133:229 */             if (Metrics.this.debug) {
/* 134:230 */               Bukkit.getLogger().log(Level.INFO, "[Metrics] " + e.getMessage());
/* 135:    */             }
/* 136:    */           }
/* 137:    */         }
/* 138:230 */       }, 0L, 18000L);
/* 139:    */       
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:236 */       return true;
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean isOptOut()
/* 149:    */   {
/* 150:246 */     synchronized (this.optOutLock)
/* 151:    */     {
/* 152:    */       try
/* 153:    */       {
/* 154:249 */         this.configuration.load(getConfigFile());
/* 155:    */       }
/* 156:    */       catch (IOException ex)
/* 157:    */       {
/* 158:251 */         if (this.debug) {
/* 159:252 */           Bukkit.getLogger().log(Level.INFO, "[Metrics] " + ex.getMessage());
/* 160:    */         }
/* 161:254 */         return true;
/* 162:    */       }
/* 163:    */       catch (InvalidConfigurationException ex)
/* 164:    */       {
/* 165:256 */         if (this.debug) {
/* 166:257 */           Bukkit.getLogger().log(Level.INFO, "[Metrics] " + ex.getMessage());
/* 167:    */         }
/* 168:259 */         return true;
/* 169:    */       }
/* 170:261 */       return this.configuration.getBoolean("opt-out", false);
/* 171:    */     }
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void enable()
/* 175:    */     throws IOException
/* 176:    */   {
/* 177:272 */     synchronized (this.optOutLock)
/* 178:    */     {
/* 179:274 */       if (isOptOut())
/* 180:    */       {
/* 181:275 */         this.configuration.set("opt-out", Boolean.valueOf(false));
/* 182:276 */         this.configuration.save(this.configurationFile);
/* 183:    */       }
/* 184:280 */       if (this.task == null) {
/* 185:281 */         start();
/* 186:    */       }
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void disable()
/* 191:    */     throws IOException
/* 192:    */   {
/* 193:293 */     synchronized (this.optOutLock)
/* 194:    */     {
/* 195:295 */       if (!isOptOut())
/* 196:    */       {
/* 197:296 */         this.configuration.set("opt-out", Boolean.valueOf(true));
/* 198:297 */         this.configuration.save(this.configurationFile);
/* 199:    */       }
/* 200:301 */       if (this.task != null)
/* 201:    */       {
/* 202:302 */         this.task.cancel();
/* 203:303 */         this.task = null;
/* 204:    */       }
/* 205:    */     }
/* 206:    */   }
/* 207:    */   
/* 208:    */   public File getConfigFile()
/* 209:    */   {
/* 210:319 */     File pluginsFolder = this.plugin.getDataFolder().getParentFile();
/* 211:    */     
/* 212:    */ 
/* 213:322 */     return new File(new File(pluginsFolder, "PluginMetrics"), "config.yml");
/* 214:    */   }
/* 215:    */   
/* 216:    */   private void postPlugin(boolean isPing)
/* 217:    */     throws IOException
/* 218:    */   {
/* 219:330 */     PluginDescriptionFile description = this.plugin.getDescription();
/* 220:331 */     String pluginName = description.getName();
/* 221:332 */     boolean onlineMode = Bukkit.getServer().getOnlineMode();
/* 222:333 */     String pluginVersion = description.getVersion();
/* 223:334 */     String serverVersion = Bukkit.getVersion();
/* 224:335 */     int playersOnline = Bukkit.getServer().getOnlinePlayers().length;
/* 225:    */     
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:340 */     StringBuilder json = new StringBuilder(1024);
/* 230:341 */     json.append('{');
/* 231:    */     
/* 232:    */ 
/* 233:344 */     appendJSONPair(json, "guid", this.guid);
/* 234:345 */     appendJSONPair(json, "plugin_version", pluginVersion);
/* 235:346 */     appendJSONPair(json, "server_version", serverVersion);
/* 236:347 */     appendJSONPair(json, "players_online", Integer.toString(playersOnline));
/* 237:    */     
/* 238:    */ 
/* 239:350 */     String osname = System.getProperty("os.name");
/* 240:351 */     String osarch = System.getProperty("os.arch");
/* 241:352 */     String osversion = System.getProperty("os.version");
/* 242:353 */     String java_version = System.getProperty("java.version");
/* 243:354 */     int coreCount = Runtime.getRuntime().availableProcessors();
/* 244:357 */     if (osarch.equals("amd64")) {
/* 245:358 */       osarch = "x86_64";
/* 246:    */     }
/* 247:361 */     appendJSONPair(json, "osname", osname);
/* 248:362 */     appendJSONPair(json, "osarch", osarch);
/* 249:363 */     appendJSONPair(json, "osversion", osversion);
/* 250:364 */     appendJSONPair(json, "cores", Integer.toString(coreCount));
/* 251:365 */     appendJSONPair(json, "auth_mode", onlineMode ? "1" : "0");
/* 252:366 */     appendJSONPair(json, "java_version", java_version);
/* 253:369 */     if (isPing) {
/* 254:370 */       appendJSONPair(json, "ping", "1");
/* 255:    */     }
/* 256:373 */     if (this.graphs.size() > 0) {
/* 257:374 */       synchronized (this.graphs)
/* 258:    */       {
/* 259:375 */         json.append(',');
/* 260:376 */         json.append('"');
/* 261:377 */         json.append("graphs");
/* 262:378 */         json.append('"');
/* 263:379 */         json.append(':');
/* 264:380 */         json.append('{');
/* 265:    */         
/* 266:382 */         boolean firstGraph = true;
/* 267:    */         
/* 268:384 */         Iterator<Graph> iter = this.graphs.iterator();
/* 269:386 */         while (iter.hasNext())
/* 270:    */         {
/* 271:387 */           Graph graph = (Graph)iter.next();
/* 272:    */           
/* 273:389 */           StringBuilder graphJson = new StringBuilder();
/* 274:390 */           graphJson.append('{');
/* 275:392 */           for (Plotter plotter : graph.getPlotters()) {
/* 276:393 */             appendJSONPair(graphJson, plotter.getColumnName(), Integer.toString(plotter.getValue()));
/* 277:    */           }
/* 278:396 */           graphJson.append('}');
/* 279:398 */           if (!firstGraph) {
/* 280:399 */             json.append(',');
/* 281:    */           }
/* 282:402 */           json.append(escapeJSON(graph.getName()));
/* 283:403 */           json.append(':');
/* 284:404 */           json.append(graphJson);
/* 285:    */           
/* 286:406 */           firstGraph = false;
/* 287:    */         }
/* 288:409 */         json.append('}');
/* 289:    */       }
/* 290:    */     }
/* 291:414 */     json.append('}');
/* 292:    */     
/* 293:    */ 
/* 294:417 */     URL url = new URL("http://report.mcstats.org" + String.format("/plugin/%s", new Object[] { urlEncode(pluginName) }));
/* 295:    */     URLConnection connection;
/* 296:    */     URLConnection connection;
/* 297:424 */     if (isMineshafterPresent()) {
/* 298:425 */       connection = url.openConnection(Proxy.NO_PROXY);
/* 299:    */     } else {
/* 300:427 */       connection = url.openConnection();
/* 301:    */     }
/* 302:431 */     byte[] uncompressed = json.toString().getBytes();
/* 303:432 */     byte[] compressed = gzip(json.toString());
/* 304:    */     
/* 305:    */ 
/* 306:435 */     connection.addRequestProperty("User-Agent", "MCStats/7");
/* 307:436 */     connection.addRequestProperty("Content-Type", "application/json");
/* 308:437 */     connection.addRequestProperty("Content-Encoding", "gzip");
/* 309:438 */     connection.addRequestProperty("Content-Length", Integer.toString(compressed.length));
/* 310:439 */     connection.addRequestProperty("Accept", "application/json");
/* 311:440 */     connection.addRequestProperty("Connection", "close");
/* 312:    */     
/* 313:442 */     connection.setDoOutput(true);
/* 314:444 */     if (this.debug) {
/* 315:445 */       System.out.println("[Metrics] Prepared request for " + pluginName + " uncompressed=" + uncompressed.length + " compressed=" + compressed.length);
/* 316:    */     }
/* 317:449 */     OutputStream os = connection.getOutputStream();
/* 318:450 */     os.write(compressed);
/* 319:451 */     os.flush();
/* 320:    */     
/* 321:    */ 
/* 322:454 */     BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/* 323:455 */     String response = reader.readLine();
/* 324:    */     
/* 325:    */ 
/* 326:458 */     os.close();
/* 327:459 */     reader.close();
/* 328:461 */     if ((response == null) || (response.startsWith("ERR")) || (response.startsWith("7")))
/* 329:    */     {
/* 330:462 */       if (response == null) {
/* 331:463 */         response = "null";
/* 332:464 */       } else if (response.startsWith("7")) {
/* 333:465 */         response = response.substring(response.startsWith("7,") ? 2 : 1);
/* 334:    */       }
/* 335:468 */       throw new IOException(response);
/* 336:    */     }
/* 337:471 */     if ((response.equals("1")) || (response.contains("This is your first update this hour"))) {
/* 338:472 */       synchronized (this.graphs)
/* 339:    */       {
/* 340:473 */         Iterator<Graph> iter = this.graphs.iterator();
/* 341:475 */         while (iter.hasNext())
/* 342:    */         {
/* 343:476 */           Graph graph = (Graph)iter.next();
/* 344:478 */           for (Plotter plotter : graph.getPlotters()) {
/* 345:479 */             plotter.reset();
/* 346:    */           }
/* 347:    */         }
/* 348:    */       }
/* 349:    */     }
/* 350:    */   }
/* 351:    */   
/* 352:    */   public static byte[] gzip(String input)
/* 353:    */   {
/* 354:494 */     baos = new ByteArrayOutputStream();
/* 355:495 */     GZIPOutputStream gzos = null;
/* 356:    */     try
/* 357:    */     {
/* 358:498 */       gzos = new GZIPOutputStream(baos);
/* 359:499 */       gzos.write(input.getBytes("UTF-8"));
/* 360:    */       
/* 361:    */ 
/* 362:    */ 
/* 363:    */ 
/* 364:    */ 
/* 365:    */ 
/* 366:    */ 
/* 367:    */ 
/* 368:    */ 
/* 369:509 */       return baos.toByteArray();
/* 370:    */     }
/* 371:    */     catch (IOException e)
/* 372:    */     {
/* 373:501 */       e.printStackTrace();
/* 374:    */     }
/* 375:    */     finally
/* 376:    */     {
/* 377:503 */       if (gzos != null) {
/* 378:    */         try
/* 379:    */         {
/* 380:504 */           gzos.close();
/* 381:    */         }
/* 382:    */         catch (IOException ignore) {}
/* 383:    */       }
/* 384:    */     }
/* 385:    */   }
/* 386:    */   
/* 387:    */   private boolean isMineshafterPresent()
/* 388:    */   {
/* 389:    */     try
/* 390:    */     {
/* 391:519 */       Class.forName("mineshafter.MineServer");
/* 392:520 */       return true;
/* 393:    */     }
/* 394:    */     catch (Exception e) {}
/* 395:522 */     return false;
/* 396:    */   }
/* 397:    */   
/* 398:    */   private static void appendJSONPair(StringBuilder json, String key, String value)
/* 399:    */     throws UnsupportedEncodingException
/* 400:    */   {
/* 401:535 */     boolean isValueNumeric = false;
/* 402:    */     try
/* 403:    */     {
/* 404:538 */       if ((value.equals("0")) || (!value.endsWith("0")))
/* 405:    */       {
/* 406:539 */         Double.parseDouble(value);
/* 407:540 */         isValueNumeric = true;
/* 408:    */       }
/* 409:    */     }
/* 410:    */     catch (NumberFormatException e)
/* 411:    */     {
/* 412:543 */       isValueNumeric = false;
/* 413:    */     }
/* 414:546 */     if (json.charAt(json.length() - 1) != '{') {
/* 415:547 */       json.append(',');
/* 416:    */     }
/* 417:550 */     json.append(escapeJSON(key));
/* 418:551 */     json.append(':');
/* 419:553 */     if (isValueNumeric) {
/* 420:554 */       json.append(value);
/* 421:    */     } else {
/* 422:556 */       json.append(escapeJSON(value));
/* 423:    */     }
/* 424:    */   }
/* 425:    */   
/* 426:    */   private static String escapeJSON(String text)
/* 427:    */   {
/* 428:567 */     StringBuilder builder = new StringBuilder();
/* 429:    */     
/* 430:569 */     builder.append('"');
/* 431:570 */     for (int index = 0; index < text.length(); index++)
/* 432:    */     {
/* 433:571 */       char chr = text.charAt(index);
/* 434:573 */       switch (chr)
/* 435:    */       {
/* 436:    */       case '"': 
/* 437:    */       case '\\': 
/* 438:576 */         builder.append('\\');
/* 439:577 */         builder.append(chr);
/* 440:578 */         break;
/* 441:    */       case '\b': 
/* 442:580 */         builder.append("\\b");
/* 443:581 */         break;
/* 444:    */       case '\t': 
/* 445:583 */         builder.append("\\t");
/* 446:584 */         break;
/* 447:    */       case '\n': 
/* 448:586 */         builder.append("\\n");
/* 449:587 */         break;
/* 450:    */       case '\r': 
/* 451:589 */         builder.append("\\r");
/* 452:590 */         break;
/* 453:    */       default: 
/* 454:592 */         if (chr < ' ')
/* 455:    */         {
/* 456:593 */           String t = "000" + Integer.toHexString(chr);
/* 457:594 */           builder.append("\\u" + t.substring(t.length() - 4));
/* 458:    */         }
/* 459:    */         else
/* 460:    */         {
/* 461:596 */           builder.append(chr);
/* 462:    */         }
/* 463:    */         break;
/* 464:    */       }
/* 465:    */     }
/* 466:601 */     builder.append('"');
/* 467:    */     
/* 468:603 */     return builder.toString();
/* 469:    */   }
/* 470:    */   
/* 471:    */   private static String urlEncode(String text)
/* 472:    */     throws UnsupportedEncodingException
/* 473:    */   {
/* 474:613 */     return URLEncoder.encode(text, "UTF-8");
/* 475:    */   }
/* 476:    */   
/* 477:    */   public static class Graph
/* 478:    */   {
/* 479:    */     private final String name;
/* 480:630 */     private final Set<Metrics.Plotter> plotters = new LinkedHashSet();
/* 481:    */     
/* 482:    */     private Graph(String name)
/* 483:    */     {
/* 484:633 */       this.name = name;
/* 485:    */     }
/* 486:    */     
/* 487:    */     public String getName()
/* 488:    */     {
/* 489:642 */       return this.name;
/* 490:    */     }
/* 491:    */     
/* 492:    */     public void addPlotter(Metrics.Plotter plotter)
/* 493:    */     {
/* 494:651 */       this.plotters.add(plotter);
/* 495:    */     }
/* 496:    */     
/* 497:    */     public void removePlotter(Metrics.Plotter plotter)
/* 498:    */     {
/* 499:660 */       this.plotters.remove(plotter);
/* 500:    */     }
/* 501:    */     
/* 502:    */     public Set<Metrics.Plotter> getPlotters()
/* 503:    */     {
/* 504:669 */       return Collections.unmodifiableSet(this.plotters);
/* 505:    */     }
/* 506:    */     
/* 507:    */     public int hashCode()
/* 508:    */     {
/* 509:674 */       return this.name.hashCode();
/* 510:    */     }
/* 511:    */     
/* 512:    */     public boolean equals(Object object)
/* 513:    */     {
/* 514:679 */       if (!(object instanceof Graph)) {
/* 515:680 */         return false;
/* 516:    */       }
/* 517:683 */       Graph graph = (Graph)object;
/* 518:684 */       return graph.name.equals(this.name);
/* 519:    */     }
/* 520:    */     
/* 521:    */     protected void onOptOut() {}
/* 522:    */   }
/* 523:    */   
/* 524:    */   public static abstract class Plotter
/* 525:    */   {
/* 526:    */     private final String name;
/* 527:    */     
/* 528:    */     public Plotter()
/* 529:    */     {
/* 530:708 */       this("Default");
/* 531:    */     }
/* 532:    */     
/* 533:    */     public Plotter(String name)
/* 534:    */     {
/* 535:717 */       this.name = name;
/* 536:    */     }
/* 537:    */     
/* 538:    */     public abstract int getValue();
/* 539:    */     
/* 540:    */     public String getColumnName()
/* 541:    */     {
/* 542:735 */       return this.name;
/* 543:    */     }
/* 544:    */     
/* 545:    */     public void reset() {}
/* 546:    */     
/* 547:    */     public int hashCode()
/* 548:    */     {
/* 549:746 */       return getColumnName().hashCode();
/* 550:    */     }
/* 551:    */     
/* 552:    */     public boolean equals(Object object)
/* 553:    */     {
/* 554:751 */       if (!(object instanceof Plotter)) {
/* 555:752 */         return false;
/* 556:    */       }
/* 557:755 */       Plotter plotter = (Plotter)object;
/* 558:756 */       return (plotter.name.equals(this.name)) && (plotter.getValue() == getValue());
/* 559:    */     }
/* 560:    */   }
/* 561:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.mcstats.Metrics
 * JD-Core Version:    0.7.0.1
 */