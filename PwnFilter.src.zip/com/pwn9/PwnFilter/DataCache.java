/*   1:    */ package com.pwn9.PwnFilter;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.HashMultimap;
/*   4:    */ import com.google.common.collect.Multimap;
/*   5:    */ import com.pwn9.PwnFilter.util.LogManager;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.HashSet;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.Set;
/*  13:    */ import java.util.logging.Logger;
/*  14:    */ import org.bukkit.Bukkit;
/*  15:    */ import org.bukkit.World;
/*  16:    */ import org.bukkit.entity.Player;
/*  17:    */ import org.bukkit.permissions.Permission;
/*  18:    */ import org.bukkit.plugin.Plugin;
/*  19:    */ import org.bukkit.scheduler.BukkitScheduler;
/*  20:    */ 
/*  21:    */ public class DataCache
/*  22:    */ {
/*  23:    */   public static final int runEveryTicks = 20;
/*  24:    */   public static final int playersPerRun = 50;
/*  25: 44 */   private static DataCache _instance = null;
/*  26: 47 */   protected Set<String> permSet = new HashSet();
/*  27:    */   private final Plugin plugin;
/*  28:    */   private int taskId;
/*  29: 52 */   private Multimap<Player, String> playerPermissions = HashMultimap.create();
/*  30: 53 */   private List<Player> queuedPlayerList = new ArrayList();
/*  31: 54 */   private Set<Player> onlinePlayers = new HashSet();
/*  32:    */   
/*  33:    */   private DataCache(Plugin plugin)
/*  34:    */   {
/*  35: 57 */     if (plugin == null) {
/*  36: 57 */       throw new IllegalStateException("Could not get PwnFilter instance!");
/*  37:    */     }
/*  38: 58 */     this.plugin = plugin;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static DataCache init(PwnFilter p)
/*  42:    */   {
/*  43: 62 */     if (_instance == null)
/*  44:    */     {
/*  45: 63 */       _instance = new DataCache(p);
/*  46: 64 */       return _instance;
/*  47:    */     }
/*  48: 66 */     return _instance;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static DataCache getInstance()
/*  52:    */     throws IllegalStateException
/*  53:    */   {
/*  54: 72 */     if (_instance == null) {
/*  55: 73 */       throw new IllegalStateException("DataCache not initialized.");
/*  56:    */     }
/*  57: 75 */     return _instance;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Player[] getOnlinePlayers()
/*  61:    */   {
/*  62: 79 */     return (Player[])this.onlinePlayers.toArray(new Player[this.onlinePlayers.size()]);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean hasPermission(Player p, String s)
/*  66:    */   {
/*  67: 83 */     return this.playerPermissions.get(p).contains(s);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean hasPermission(Player p, Permission perm)
/*  71:    */   {
/*  72: 87 */     return this.playerPermissions.get(p).contains(perm.getName());
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void start()
/*  76:    */   {
/*  77: 92 */     for (Player p : ) {
/*  78: 93 */       addPlayer(p);
/*  79:    */     }
/*  80: 96 */     this.taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable()
/*  81:    */     {
/*  82:    */       public void run()
/*  83:    */       {
/*  84: 99 */         DataCache.this.updateCache();
/*  85:    */       }
/*  86: 99 */     }, 0L, 20L);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public synchronized void stop()
/*  90:    */   {
/*  91:105 */     Bukkit.getScheduler().cancelTask(this.taskId);
/*  92:106 */     this.onlinePlayers.clear();
/*  93:107 */     this.playerPermissions.clear();
/*  94:108 */     this.taskId = 0;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void finalize()
/*  98:    */     throws Throwable
/*  99:    */   {
/* 100:112 */     if (this.taskId != 0) {
/* 101:113 */       stop();
/* 102:    */     }
/* 103:115 */     super.finalize();
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void dumpCache(Logger l)
/* 107:    */   {
/* 108:119 */     l.finest("PwnFilter Data Cache Contents:");
/* 109:120 */     l.finest("Task Id: " + this.taskId);
/* 110:121 */     l.finest("Online Players: " + getOnlinePlayers().length);
/* 111:122 */     l.finest("Total Names: " + this.onlinePlayers.size() + " Perms: " + this.playerPermissions.size());
/* 112:123 */     StringBuilder sb = new StringBuilder();
/* 113:124 */     for (Player p : this.queuedPlayerList)
/* 114:    */     {
/* 115:125 */       sb.append(p.toString());
/* 116:126 */       sb.append(" ");
/* 117:    */     }
/* 118:128 */     l.finest(sb.toString());
/* 119:129 */     l.finest("-----PlayerCache ------");
/* 120:130 */     for (Player p : this.onlinePlayers)
/* 121:    */     {
/* 122:131 */       l.finest("Player ID: " + p.getUniqueId() + " Name: " + p.getName() + " World: " + p.getWorld().getName());
/* 123:132 */       StringBuilder s = new StringBuilder();
/* 124:133 */       sb.append("PermissionsSet : ");
/* 125:134 */       Collection<String> perms = this.playerPermissions.get(p);
/* 126:135 */       for (String perm : perms)
/* 127:    */       {
/* 128:136 */         s.append(perm);
/* 129:137 */         s.append(" ");
/* 130:    */       }
/* 131:139 */       l.finest(s.toString());
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   public synchronized void addPlayer(Player p)
/* 136:    */   {
/* 137:149 */     this.onlinePlayers.add(p);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public synchronized void removePlayer(Player p)
/* 141:    */   {
/* 142:153 */     this.onlinePlayers.remove(p);
/* 143:154 */     this.playerPermissions.get(p).clear();
/* 144:    */   }
/* 145:    */   
/* 146:    */   private synchronized void updateCache()
/* 147:    */   {
/* 148:    */     Iterator<Player> it;
/* 149:163 */     if (this.queuedPlayerList.isEmpty())
/* 150:    */     {
/* 151:166 */       if (!this.onlinePlayers.containsAll(Arrays.asList(getOnlinePlayers()))) {
/* 152:167 */         LogManager.logger.warning("Cached Player List is not equal to actual online player list!");
/* 153:    */       }
/* 154:170 */       if (this.onlinePlayers.size() > 0) {
/* 155:171 */         this.queuedPlayerList.addAll(this.onlinePlayers);
/* 156:    */       }
/* 157:174 */       for (it = this.onlinePlayers.iterator(); it.hasNext();)
/* 158:    */       {
/* 159:175 */         Player p = (Player)it.next();
/* 160:176 */         if (!p.isOnline())
/* 161:    */         {
/* 162:177 */           LogManager.logger.warning("Removing cached, but offline player: " + p.getName());
/* 163:178 */           this.playerPermissions.get(p).clear();
/* 164:179 */           it.remove();
/* 165:    */         }
/* 166:    */       }
/* 167:    */     }
/* 168:184 */     for (int i = 0; i < 50; i++)
/* 169:    */     {
/* 170:185 */       if (this.queuedPlayerList.isEmpty()) {
/* 171:    */         break;
/* 172:    */       }
/* 173:186 */       Player player = (Player)this.queuedPlayerList.remove(0);
/* 174:187 */       cachePlayerPermissions(player);
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   public synchronized void addPermission(String permission)
/* 179:    */   {
/* 180:193 */     this.permSet.add(permission);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public synchronized void addPermissions(List<Permission> permissions)
/* 184:    */   {
/* 185:197 */     for (Permission p : permissions) {
/* 186:198 */       this.permSet.add(p.getName());
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   public synchronized void addPermissions(Set<String> permissions)
/* 191:    */   {
/* 192:203 */     this.permSet.addAll(permissions);
/* 193:    */   }
/* 194:    */   
/* 195:    */   private void cachePlayerPermissions(Player p)
/* 196:    */   {
/* 197:211 */     for (String perm : this.permSet) {
/* 198:212 */       if (p.hasPermission(perm)) {
/* 199:213 */         this.playerPermissions.put(p, perm);
/* 200:    */       }
/* 201:    */     }
/* 202:    */   }
/* 203:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.DataCache
 * JD-Core Version:    0.7.0.1
 */