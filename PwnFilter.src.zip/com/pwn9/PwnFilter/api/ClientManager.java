/*   1:    */ package com.pwn9.PwnFilter.api;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.concurrent.ConcurrentHashMap;
/*   8:    */ import org.bukkit.configuration.Configuration;
/*   9:    */ import org.bukkit.plugin.Plugin;
/*  10:    */ 
/*  11:    */ public class ClientManager
/*  12:    */ {
/*  13:    */   private static ClientManager _instance;
/*  14: 36 */   private ConcurrentHashMap<FilterClient, Plugin> registeredClients = new ConcurrentHashMap();
/*  15:    */   private final PwnFilter plugin;
/*  16:    */   
/*  17:    */   private ClientManager(PwnFilter plugin)
/*  18:    */   {
/*  19: 41 */     this.plugin = plugin;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static ClientManager getInstance()
/*  23:    */   {
/*  24: 45 */     if (_instance == null) {
/*  25: 46 */       _instance = new ClientManager(PwnFilter.getInstance());
/*  26:    */     }
/*  27: 48 */     return _instance;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public List<FilterClient> getActiveClients()
/*  31:    */   {
/*  32: 52 */     List<FilterClient> result = new ArrayList();
/*  33: 53 */     for (FilterClient f : this.registeredClients.keySet()) {
/*  34: 54 */       if (f.isActive()) {
/*  35: 54 */         result.add(f);
/*  36:    */       }
/*  37:    */     }
/*  38: 56 */     return result;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public Map<FilterClient, Plugin> getRegisteredClients()
/*  42:    */   {
/*  43: 60 */     return this.registeredClients;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void enableClients()
/*  47:    */   {
/*  48: 64 */     Configuration config = this.plugin.getConfig();
/*  49: 66 */     for (FilterClient f : this.registeredClients.keySet()) {
/*  50: 67 */       f.activate(config);
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void disableClients()
/*  55:    */   {
/*  56: 73 */     for (FilterClient f : getActiveClients()) {
/*  57: 74 */       f.shutdown();
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean registerClient(FilterClient f, Plugin p)
/*  62:    */   {
/*  63: 92 */     if (this.registeredClients.containsKey(f)) {
/*  64: 93 */       return false;
/*  65:    */     }
/*  66: 95 */     this.registeredClients.put(f, p);
/*  67: 96 */     this.plugin.updateMetrics();
/*  68: 97 */     return true;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public boolean unregisterClient(FilterClient f)
/*  72:    */   {
/*  73:112 */     if (this.registeredClients.containsKey(f))
/*  74:    */     {
/*  75:113 */       this.registeredClients.remove(f);
/*  76:114 */       this.plugin.updateMetrics();
/*  77:115 */       return true;
/*  78:    */     }
/*  79:117 */     return false;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void unregisterClients()
/*  83:    */   {
/*  84:122 */     for (FilterClient f : this.registeredClients.keySet())
/*  85:    */     {
/*  86:123 */       f.shutdown();
/*  87:124 */       this.registeredClients.remove(f);
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   protected void finalize()
/*  92:    */     throws Throwable
/*  93:    */   {
/*  94:130 */     super.finalize();
/*  95:131 */     disableClients();
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.api.ClientManager
 * JD-Core Version:    0.7.0.1
 */