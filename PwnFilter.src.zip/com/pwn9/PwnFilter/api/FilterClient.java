package com.pwn9.PwnFilter.api;

import com.pwn9.PwnFilter.rules.RuleChain;
import org.bukkit.configuration.Configuration;
import org.bukkit.event.Listener;

public abstract interface FilterClient
  extends Listener
{
  public abstract String getShortName();
  
  public abstract RuleChain getRuleChain();
  
  public abstract boolean isActive();
  
  public abstract void activate(Configuration paramConfiguration);
  
  public abstract void shutdown();
}


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.api.FilterClient
 * JD-Core Version:    0.7.0.1
 */