/*   1:    */ package com.pwn9.PwnFilter.command;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import org.bukkit.command.Command;
/*   9:    */ import org.bukkit.command.CommandSender;
/*  10:    */ import org.bukkit.command.TabExecutor;
/*  11:    */ 
/*  12:    */ public class BaseCommandExecutor
/*  13:    */   implements TabExecutor
/*  14:    */ {
/*  15:    */   protected final PwnFilter plugin;
/*  16:    */   private final Map<String, SubCommand> subCommands;
/*  17:    */   
/*  18:    */   public BaseCommandExecutor(PwnFilter instance)
/*  19:    */   {
/*  20: 37 */     this.plugin = instance;
/*  21: 38 */     this.subCommands = new HashMap();
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void addSubCommand(SubCommand subCommand)
/*  25:    */   {
/*  26: 43 */     if (subCommand == null) {
/*  27: 44 */       throw new IllegalArgumentException("SubCommand was null.");
/*  28:    */     }
/*  29: 46 */     this.subCommands.put(subCommand.getName(), subCommand);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public boolean onCommand(CommandSender sender, Command command, String alias, String[] args)
/*  33:    */   {
/*  34: 51 */     if (args.length < 1)
/*  35:    */     {
/*  36: 52 */       sendHelpMsg(sender, alias);
/*  37: 53 */       return true;
/*  38:    */     }
/*  39: 56 */     SubCommand subCommand = (SubCommand)this.subCommands.get(args[0].toLowerCase());
/*  40: 57 */     if (subCommand == null)
/*  41:    */     {
/*  42: 58 */       sendHelpMsg(sender, alias);
/*  43:    */     }
/*  44: 60 */     else if ((subCommand.getPermission() == null) || (sender.hasPermission(subCommand.getPermission())))
/*  45:    */     {
/*  46: 61 */       subCommand.execute(sender, alias, args);
/*  47:    */     }
/*  48:    */     else
/*  49:    */     {
/*  50: 63 */       sender.sendMessage("You don't have permission to do that.");
/*  51: 64 */       return true;
/*  52:    */     }
/*  53: 67 */     return true;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean sendHelpMsg(CommandSender sender, String alias)
/*  57:    */   {
/*  58: 72 */     ArrayList<SubCommand> availableCommands = new ArrayList();
/*  59: 74 */     for (SubCommand subCommand : this.subCommands.values()) {
/*  60: 75 */       if ((subCommand.getPermission() == null) || (sender.hasPermission(subCommand.getPermission()))) {
/*  61: 76 */         if (!subCommand.getHelpMessage().isEmpty()) {
/*  62: 77 */           availableCommands.add(subCommand);
/*  63:    */         }
/*  64:    */       }
/*  65:    */     }
/*  66: 81 */     if (availableCommands.size() != 0)
/*  67:    */     {
/*  68: 82 */       sender.sendMessage("Available commands for " + alias + ":");
/*  69: 84 */       for (SubCommand subCommand : availableCommands) {
/*  70: 85 */         sender.sendMessage("/" + alias + " " + subCommand.getHelpMessage());
/*  71:    */       }
/*  72:    */     }
/*  73: 90 */     return true;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args)
/*  77:    */   {
/*  78:104 */     List<String> completions = new ArrayList();
/*  79:106 */     if (args.length == 1)
/*  80:    */     {
/*  81:107 */       for (SubCommand subCommand : this.subCommands.values()) {
/*  82:108 */         if (subCommand.getName().startsWith(args[0])) {
/*  83:110 */           if ((subCommand.getPermission() == null) || (sender.hasPermission(subCommand.getPermission()))) {
/*  84:112 */             completions.add(subCommand.getName());
/*  85:    */           }
/*  86:    */         }
/*  87:    */       }
/*  88:    */     }
/*  89:115 */     else if (args.length > 1)
/*  90:    */     {
/*  91:116 */       SubCommand subCommand = (SubCommand)this.subCommands.get(args[0].toLowerCase());
/*  92:117 */       if (subCommand != null) {
/*  93:118 */         return subCommand.tabComplete(sender, alias, args);
/*  94:    */       }
/*  95:    */     }
/*  96:122 */     if (completions.isEmpty()) {
/*  97:122 */       return null;
/*  98:    */     }
/*  99:124 */     return completions;
/* 100:    */   }
/* 101:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.command.BaseCommandExecutor
 * JD-Core Version:    0.7.0.1
 */