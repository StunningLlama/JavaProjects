/*  1:   */ package com.pwn9.PwnFilter.command;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.DataCache;
/*  4:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  5:   */ import com.pwn9.PwnFilter.api.ClientManager;
/*  6:   */ import com.pwn9.PwnFilter.rules.RuleManager;
/*  7:   */ import com.pwn9.PwnFilter.util.LogManager;
/*  8:   */ import com.pwn9.PwnFilter.util.PointManager;
/*  9:   */ import java.util.logging.Logger;
/* 10:   */ import org.bukkit.ChatColor;
/* 11:   */ import org.bukkit.command.Command;
/* 12:   */ import org.bukkit.command.CommandExecutor;
/* 13:   */ import org.bukkit.command.CommandSender;
/* 14:   */ 
/* 15:   */ public class pfreload
/* 16:   */   implements CommandExecutor
/* 17:   */ {
/* 18:   */   private final PwnFilter plugin;
/* 19:   */   
/* 20:   */   public pfreload(PwnFilter plugin)
/* 21:   */   {
/* 22:35 */     this.plugin = plugin;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/* 26:   */   {
/* 27:40 */     sender.sendMessage(ChatColor.RED + "Reloading config.yml and rules/*.txt files.");
/* 28:   */     
/* 29:42 */     LogManager.logger.info("Disabling all listeners");
/* 30:43 */     ClientManager.getInstance().disableClients();
/* 31:   */     
/* 32:   */ 
/* 33:46 */     DataCache.getInstance().stop();
/* 34:   */     
/* 35:48 */     this.plugin.reloadConfig();
/* 36:49 */     this.plugin.configurePlugin();
/* 37:   */     
/* 38:51 */     LogManager.logger.config("Reloaded config.yml as requested by " + sender.getName());
/* 39:   */     
/* 40:53 */     PointManager.setup(this.plugin);
/* 41:   */     
/* 42:55 */     RuleManager.getInstance().reloadAllConfigs();
/* 43:56 */     LogManager.logger.config("All rules reloaded by " + sender.getName());
/* 44:   */     
/* 45:   */ 
/* 46:59 */     DataCache.getInstance().start();
/* 47:   */     
/* 48:   */ 
/* 49:62 */     ClientManager.getInstance().enableClients();
/* 50:63 */     LogManager.logger.info("All listeners re-enabled");
/* 51:   */     
/* 52:65 */     return true;
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.command.pfreload
 * JD-Core Version:    0.7.0.1
 */