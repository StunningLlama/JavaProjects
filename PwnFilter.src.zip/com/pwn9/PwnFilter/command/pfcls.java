/*  1:   */ package com.pwn9.PwnFilter.command;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  4:   */ import com.pwn9.PwnFilter.util.LogManager;
/*  5:   */ import java.util.logging.Logger;
/*  6:   */ import org.bukkit.ChatColor;
/*  7:   */ import org.bukkit.Server;
/*  8:   */ import org.bukkit.command.Command;
/*  9:   */ import org.bukkit.command.CommandExecutor;
/* 10:   */ import org.bukkit.command.CommandSender;
/* 11:   */ 
/* 12:   */ public class pfcls
/* 13:   */   implements CommandExecutor
/* 14:   */ {
/* 15:   */   private final PwnFilter plugin;
/* 16:   */   
/* 17:   */   public pfcls(PwnFilter plugin)
/* 18:   */   {
/* 19:31 */     this.plugin = plugin;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/* 23:   */   {
/* 24:36 */     sender.sendMessage(ChatColor.RED + "Clearing chat screen");
/* 25:37 */     LogManager.logger.info("chat screen cleared by " + sender.getName());
/* 26:38 */     int i = 0;
/* 27:39 */     while (i <= 120)
/* 28:   */     {
/* 29:40 */       this.plugin.getServer().broadcastMessage(" ");
/* 30:41 */       i++;
/* 31:   */     }
/* 32:43 */     return true;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.command.pfcls
 * JD-Core Version:    0.7.0.1
 */