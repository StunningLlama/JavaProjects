/*  1:   */ package com.pwn9.PwnFilter.command;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.DataCache;
/*  4:   */ import com.pwn9.PwnFilter.util.LogManager;
/*  5:   */ import java.util.logging.Logger;
/*  6:   */ import org.bukkit.ChatColor;
/*  7:   */ import org.bukkit.command.Command;
/*  8:   */ import org.bukkit.command.CommandExecutor;
/*  9:   */ import org.bukkit.command.CommandSender;
/* 10:   */ 
/* 11:   */ public class pfdumpcache
/* 12:   */   implements CommandExecutor
/* 13:   */ {
/* 14:   */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/* 15:   */   {
/* 16:33 */     DataCache.getInstance().dumpCache(LogManager.logger);
/* 17:34 */     sender.sendMessage(ChatColor.RED + "Dumped PwnFilter cache to log.");
/* 18:35 */     LogManager.logger.info("Dumped PwnFilter cache to log by " + sender.getName());
/* 19:36 */     return true;
/* 20:   */   }
/* 21:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.command.pfdumpcache
 * JD-Core Version:    0.7.0.1
 */