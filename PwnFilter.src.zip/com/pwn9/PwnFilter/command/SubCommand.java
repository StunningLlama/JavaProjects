/*  1:   */ package com.pwn9.PwnFilter.command;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  4:   */ import org.bukkit.command.Command;
/*  5:   */ 
/*  6:   */ public abstract class SubCommand
/*  7:   */   extends Command
/*  8:   */ {
/*  9:   */   protected final PwnFilter plugin;
/* 10:   */   
/* 11:   */   public SubCommand(PwnFilter plugin, String name)
/* 12:   */   {
/* 13:19 */     super(name);
/* 14:20 */     this.plugin = plugin;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public String getHelpMessage()
/* 18:   */   {
/* 19:24 */     String message = "";
/* 20:25 */     if (!getUsage().isEmpty()) {
/* 21:25 */       message = getUsage();
/* 22:   */     }
/* 23:26 */     if (!getDescription().isEmpty()) {
/* 24:27 */       if (!message.isEmpty()) {
/* 25:28 */         message = message + " -- " + getDescription();
/* 26:   */       } else {
/* 27:30 */         message = getDescription();
/* 28:   */       }
/* 29:   */     }
/* 30:33 */     return message;
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.command.SubCommand
 * JD-Core Version:    0.7.0.1
 */