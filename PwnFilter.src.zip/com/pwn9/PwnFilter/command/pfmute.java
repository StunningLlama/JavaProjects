/*  1:   */ package com.pwn9.PwnFilter.command;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  4:   */ import com.pwn9.PwnFilter.util.LogManager;
/*  5:   */ import java.util.logging.Logger;
/*  6:   */ import org.bukkit.ChatColor;
/*  7:   */ import org.bukkit.Server;
/*  8:   */ import org.bukkit.command.Command;
/*  9:   */ import org.bukkit.command.CommandExecutor;
/* 10:   */ import org.bukkit.command.CommandSender;
/* 11:   */ 
/* 12:   */ public class pfmute
/* 13:   */   implements CommandExecutor
/* 14:   */ {
/* 15:   */   private final PwnFilter plugin;
/* 16:   */   
/* 17:   */   public pfmute(PwnFilter plugin)
/* 18:   */   {
/* 19:31 */     this.plugin = plugin;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/* 23:   */   {
/* 24:36 */     if (PwnFilter.pwnMute)
/* 25:   */     {
/* 26:37 */       this.plugin.getServer().broadcastMessage(ChatColor.RED + "Global mute cancelled by " + sender.getName());
/* 27:38 */       LogManager.logger.info("global mute cancelled by " + sender.getName());
/* 28:39 */       PwnFilter.pwnMute = false;
/* 29:   */     }
/* 30:   */     else
/* 31:   */     {
/* 32:42 */       this.plugin.getServer().broadcastMessage(ChatColor.RED + "Global mute initiated by " + sender.getName());
/* 33:43 */       LogManager.logger.info("global mute initiated by " + sender.getName());
/* 34:44 */       PwnFilter.pwnMute = true;
/* 35:   */     }
/* 36:46 */     return true;
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.command.pfmute
 * JD-Core Version:    0.7.0.1
 */