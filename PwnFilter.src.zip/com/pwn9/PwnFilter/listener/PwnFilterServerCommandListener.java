/*   1:    */ package com.pwn9.PwnFilter.listener;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.FilterState;
/*   4:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   5:    */ import com.pwn9.PwnFilter.rules.RuleChain;
/*   6:    */ import com.pwn9.PwnFilter.rules.RuleManager;
/*   7:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*   8:    */ import com.pwn9.PwnFilter.util.LogManager;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.logging.Logger;
/*  11:    */ import org.bukkit.Bukkit;
/*  12:    */ import org.bukkit.configuration.Configuration;
/*  13:    */ import org.bukkit.configuration.file.FileConfiguration;
/*  14:    */ import org.bukkit.event.Event;
/*  15:    */ import org.bukkit.event.EventPriority;
/*  16:    */ import org.bukkit.event.Listener;
/*  17:    */ import org.bukkit.event.server.ServerCommandEvent;
/*  18:    */ import org.bukkit.plugin.EventExecutor;
/*  19:    */ import org.bukkit.plugin.PluginManager;
/*  20:    */ 
/*  21:    */ public class PwnFilterServerCommandListener
/*  22:    */   extends BaseListener
/*  23:    */ {
/*  24:    */   public List<String> cmdlist;
/*  25:    */   public List<String> cmdblist;
/*  26:    */   
/*  27:    */   public PwnFilterServerCommandListener(PwnFilter p)
/*  28:    */   {
/*  29: 38 */     super(p);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String getShortName()
/*  33:    */   {
/*  34: 43 */     return "CONSOLE";
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void onServerCommandEvent(ServerCommandEvent event)
/*  38:    */   {
/*  39: 48 */     String command = event.getCommand();
/*  40:    */     String cmdmessage;
/*  41:    */     try
/*  42:    */     {
/*  43: 53 */       cmdmessage = command.split(" ")[0];
/*  44:    */     }
/*  45:    */     catch (IndexOutOfBoundsException ex)
/*  46:    */     {
/*  47: 55 */       return;
/*  48:    */     }
/*  49: 58 */     if ((!this.cmdlist.isEmpty()) && (!this.cmdlist.contains(cmdmessage))) {
/*  50: 58 */       return;
/*  51:    */     }
/*  52: 59 */     if (this.cmdblist.contains(cmdmessage)) {
/*  53: 59 */       return;
/*  54:    */     }
/*  55: 61 */     FilterState state = new FilterState(this.plugin, command, null, this);
/*  56:    */     
/*  57:    */ 
/*  58:    */ 
/*  59: 65 */     this.ruleChain.execute(state);
/*  60: 68 */     if (state.messageChanged()) {
/*  61: 69 */       event.setCommand(state.getModifiedMessage().getColoredString());
/*  62:    */     }
/*  63: 72 */     if (state.cancel) {
/*  64: 72 */       event.setCommand("");
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void activate(Configuration config)
/*  69:    */   {
/*  70: 89 */     if (isActive()) {
/*  71: 89 */       return;
/*  72:    */     }
/*  73: 91 */     this.cmdlist = this.plugin.getConfig().getStringList("cmdlist");
/*  74: 92 */     this.cmdblist = this.plugin.getConfig().getStringList("cmdblist");
/*  75:    */     
/*  76: 94 */     setRuleChain(RuleManager.getInstance().getRuleChain("console.txt"));
/*  77: 96 */     if (config.getBoolean("consolefilter"))
/*  78:    */     {
/*  79: 98 */       PluginManager pm = Bukkit.getPluginManager();
/*  80: 99 */       EventPriority priority = EventPriority.valueOf(config.getString("cmdpriority", "LOWEST").toUpperCase());
/*  81:    */       
/*  82:101 */       pm.registerEvent(ServerCommandEvent.class, this, priority, new EventExecutor()
/*  83:    */       {
/*  84:    */         public void execute(Listener l, Event e)
/*  85:    */         {
/*  86:103 */           PwnFilterServerCommandListener.this.onServerCommandEvent((ServerCommandEvent)e);
/*  87:    */         }
/*  88:103 */       }, this.plugin);
/*  89:    */       
/*  90:    */ 
/*  91:106 */       LogManager.logger.info("Activated ServerCommandListener with Priority Setting: " + priority.toString() + " Rule Count: " + getRuleChain().ruleCount());
/*  92:    */       
/*  93:    */ 
/*  94:109 */       setActive();
/*  95:    */     }
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.listener.PwnFilterServerCommandListener
 * JD-Core Version:    0.7.0.1
 */