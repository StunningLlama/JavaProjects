/*  1:   */ package com.pwn9.PwnFilter.listener;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  4:   */ import java.util.concurrent.ConcurrentMap;
/*  5:   */ import org.bukkit.entity.Player;
/*  6:   */ import org.bukkit.event.EventHandler;
/*  7:   */ import org.bukkit.event.EventPriority;
/*  8:   */ import org.bukkit.event.Listener;
/*  9:   */ import org.bukkit.event.entity.EntityDeathEvent;
/* 10:   */ import org.bukkit.event.entity.PlayerDeathEvent;
/* 11:   */ 
/* 12:   */ public class PwnFilterEntityListener
/* 13:   */   implements Listener
/* 14:   */ {
/* 15:   */   @EventHandler(priority=EventPriority.LOWEST)
/* 16:   */   public void onEntityDeath(EntityDeathEvent event)
/* 17:   */   {
/* 18:30 */     if (!(event instanceof PlayerDeathEvent)) {
/* 19:30 */       return;
/* 20:   */     }
/* 21:32 */     PlayerDeathEvent e = (PlayerDeathEvent)event;
/* 22:   */     
/* 23:34 */     Player player = (Player)event.getEntity();
/* 24:36 */     if (PwnFilter.killedPlayers.containsKey(player)) {
/* 25:37 */       e.setDeathMessage((String)PwnFilter.killedPlayers.remove(player));
/* 26:   */     }
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.listener.PwnFilterEntityListener
 * JD-Core Version:    0.7.0.1
 */