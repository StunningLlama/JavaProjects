/*   1:    */ package com.pwn9.PwnFilter.listener;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.DataCache;
/*   4:    */ import com.pwn9.PwnFilter.FilterState;
/*   5:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   6:    */ import com.pwn9.PwnFilter.rules.RuleChain;
/*   7:    */ import com.pwn9.PwnFilter.rules.RuleManager;
/*   8:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*   9:    */ import com.pwn9.PwnFilter.util.LogManager;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.concurrent.ConcurrentMap;
/*  13:    */ import java.util.logging.Logger;
/*  14:    */ import org.bukkit.Bukkit;
/*  15:    */ import org.bukkit.configuration.Configuration;
/*  16:    */ import org.bukkit.configuration.file.FileConfiguration;
/*  17:    */ import org.bukkit.entity.Player;
/*  18:    */ import org.bukkit.event.Event;
/*  19:    */ import org.bukkit.event.EventPriority;
/*  20:    */ import org.bukkit.event.Listener;
/*  21:    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*  22:    */ import org.bukkit.plugin.EventExecutor;
/*  23:    */ import org.bukkit.plugin.PluginManager;
/*  24:    */ 
/*  25:    */ public class PwnFilterCommandListener
/*  26:    */   extends BaseListener
/*  27:    */ {
/*  28:    */   public List<String> cmdlist;
/*  29:    */   public List<String> cmdblist;
/*  30:    */   public List<String> cmdchat;
/*  31:    */   private RuleChain chatRuleChain;
/*  32:    */   
/*  33:    */   public String getShortName()
/*  34:    */   {
/*  35: 43 */     return "COMMAND";
/*  36:    */   }
/*  37:    */   
/*  38:    */   public PwnFilterCommandListener(PwnFilter p)
/*  39:    */   {
/*  40: 46 */     super(p);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void activate(Configuration config)
/*  44:    */   {
/*  45: 50 */     if (isActive()) {
/*  46: 50 */       return;
/*  47:    */     }
/*  48: 52 */     this.cmdlist = this.plugin.getConfig().getStringList("cmdlist");
/*  49: 53 */     this.cmdblist = this.plugin.getConfig().getStringList("cmdblist");
/*  50: 54 */     this.cmdchat = this.plugin.getConfig().getStringList("cmdchat");
/*  51:    */     
/*  52: 56 */     setRuleChain(RuleManager.getInstance().getRuleChain("command.txt"));
/*  53: 57 */     this.chatRuleChain = RuleManager.getInstance().getRuleChain("chat.txt");
/*  54:    */     
/*  55: 59 */     EventPriority priority = EventPriority.valueOf(config.getString("cmdpriority", "LOWEST").toUpperCase());
/*  56: 60 */     if (config.getBoolean("commandfilter"))
/*  57:    */     {
/*  58: 61 */       PluginManager pm = Bukkit.getPluginManager();
/*  59: 62 */       pm.registerEvent(PlayerCommandPreprocessEvent.class, this, priority, new EventExecutor()
/*  60:    */       {
/*  61:    */         public void execute(Listener l, Event e)
/*  62:    */         {
/*  63: 64 */           PwnFilterCommandListener.this.eventProcessor((PlayerCommandPreprocessEvent)e);
/*  64:    */         }
/*  65: 64 */       }, this.plugin);
/*  66:    */       
/*  67:    */ 
/*  68: 67 */       setActive();
/*  69: 68 */       LogManager.logger.info("Activated CommandListener with Priority Setting: " + priority.toString() + " Rule Count: " + getRuleChain().ruleCount());
/*  70:    */       
/*  71:    */ 
/*  72: 71 */       StringBuilder sb = new StringBuilder("Commands to filter: ");
/*  73:    */       String command;
/*  74: 72 */       for (Iterator i$ = this.cmdlist.iterator(); i$.hasNext(); sb.append(command).append(" ")) {
/*  75: 72 */         command = (String)i$.next();
/*  76:    */       }
/*  77: 73 */       LogManager.getInstance().debugLow(sb.toString().trim());
/*  78:    */       
/*  79: 75 */       sb = new StringBuilder("Commands to never filter: ");
/*  80:    */       String command;
/*  81: 76 */       for (Iterator i$ = this.cmdblist.iterator(); i$.hasNext(); sb.append(command).append(" ")) {
/*  82: 76 */         command = (String)i$.next();
/*  83:    */       }
/*  84: 77 */       LogManager.getInstance().debugLow(sb.toString().trim());
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void eventProcessor(PlayerCommandPreprocessEvent event)
/*  89:    */   {
/*  90: 84 */     if (event.isCancelled()) {
/*  91: 84 */       return;
/*  92:    */     }
/*  93: 86 */     Player player = event.getPlayer();
/*  94: 87 */     DataCache dCache = DataCache.getInstance();
/*  95: 89 */     if (dCache.hasPermission(player, "pwnfilter.bypass.commands")) {
/*  96: 89 */       return;
/*  97:    */     }
/*  98: 91 */     String message = event.getMessage();
/*  99:    */     
/* 100:    */ 
/* 101: 94 */     String cmdmessage = message.substring(1).split(" ")[0];
/* 102:    */     
/* 103: 96 */     FilterState state = new FilterState(this.plugin, message, player, this);
/* 104: 99 */     if (this.cmdchat.contains(cmdmessage))
/* 105:    */     {
/* 106:101 */       if ((PwnFilter.pwnMute) && (!dCache.hasPermission(player, "pwnfilter.bypass.mute")))
/* 107:    */       {
/* 108:102 */         event.setCancelled(true);
/* 109:103 */         return;
/* 110:    */       }
/* 111:107 */       if ((this.plugin.getConfig().getBoolean("commandspamfilter")) && (!player.hasPermission("pwnfilter.bypass.spam")))
/* 112:    */       {
/* 113:109 */         if ((PwnFilter.lastMessage.containsKey(player)) && (((String)PwnFilter.lastMessage.get(player)).equals(message)))
/* 114:    */         {
/* 115:110 */           event.setCancelled(true);
/* 116:111 */           return;
/* 117:    */         }
/* 118:113 */         PwnFilter.lastMessage.put(player, message);
/* 119:    */       }
/* 120:116 */       this.chatRuleChain.execute(state);
/* 121:    */     }
/* 122:    */     else
/* 123:    */     {
/* 124:120 */       if ((!this.cmdlist.isEmpty()) && (!this.cmdlist.contains(cmdmessage))) {
/* 125:120 */         return;
/* 126:    */       }
/* 127:121 */       if (this.cmdblist.contains(cmdmessage)) {
/* 128:121 */         return;
/* 129:    */       }
/* 130:125 */       this.ruleChain.execute(state);
/* 131:    */     }
/* 132:130 */     if (state.messageChanged())
/* 133:    */     {
/* 134:131 */       if (state.getModifiedMessage().getPlainString().isEmpty())
/* 135:    */       {
/* 136:132 */         event.setCancelled(true);
/* 137:133 */         return;
/* 138:    */       }
/* 139:135 */       event.setMessage(state.getModifiedMessage().getColoredString());
/* 140:    */     }
/* 141:138 */     if (state.cancel) {
/* 142:138 */       event.setCancelled(true);
/* 143:    */     }
/* 144:    */   }
/* 145:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.listener.PwnFilterCommandListener
 * JD-Core Version:    0.7.0.1
 */