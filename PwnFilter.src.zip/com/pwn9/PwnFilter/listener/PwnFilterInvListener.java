/*   1:    */ package com.pwn9.PwnFilter.listener;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.FilterState;
/*   4:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   5:    */ import com.pwn9.PwnFilter.rules.RuleChain;
/*   6:    */ import com.pwn9.PwnFilter.rules.RuleManager;
/*   7:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*   8:    */ import com.pwn9.PwnFilter.util.LogManager;
/*   9:    */ import java.util.logging.Logger;
/*  10:    */ import org.bukkit.Bukkit;
/*  11:    */ import org.bukkit.configuration.Configuration;
/*  12:    */ import org.bukkit.entity.EntityType;
/*  13:    */ import org.bukkit.entity.HumanEntity;
/*  14:    */ import org.bukkit.entity.Player;
/*  15:    */ import org.bukkit.event.Event;
/*  16:    */ import org.bukkit.event.EventPriority;
/*  17:    */ import org.bukkit.event.Listener;
/*  18:    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*  19:    */ import org.bukkit.event.inventory.InventoryType;
/*  20:    */ import org.bukkit.event.inventory.InventoryType.SlotType;
/*  21:    */ import org.bukkit.inventory.Inventory;
/*  22:    */ import org.bukkit.inventory.ItemStack;
/*  23:    */ import org.bukkit.inventory.meta.ItemMeta;
/*  24:    */ import org.bukkit.plugin.EventExecutor;
/*  25:    */ import org.bukkit.plugin.PluginManager;
/*  26:    */ 
/*  27:    */ public class PwnFilterInvListener
/*  28:    */   extends BaseListener
/*  29:    */ {
/*  30:    */   public PwnFilterInvListener(PwnFilter p)
/*  31:    */   {
/*  32: 40 */     super(p);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public String getShortName()
/*  36:    */   {
/*  37: 45 */     return "ITEM";
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void onInventoryEvent(InventoryClickEvent event)
/*  41:    */   {
/*  42: 53 */     if (event.isCancelled()) {
/*  43: 53 */       return;
/*  44:    */     }
/*  45: 57 */     if ((event.getSlotType() != InventoryType.SlotType.RESULT) || (event.getInventory().getType() != InventoryType.ANVIL)) {
/*  46:    */       return;
/*  47:    */     }
/*  48:    */     Player player;
/*  49: 61 */     if (event.getWhoClicked().getType() == EntityType.PLAYER) {
/*  50: 62 */       player = (Player)event.getWhoClicked();
/*  51:    */     } else {
/*  52:    */       return;
/*  53:    */     }
/*  54:    */     Player player;
/*  55: 67 */     ItemStack item = event.getCurrentItem();
/*  56: 68 */     ItemMeta itemMeta = item.getItemMeta();
/*  57: 70 */     if ((itemMeta != null) && (itemMeta.hasDisplayName()))
/*  58:    */     {
/*  59: 71 */       String message = itemMeta.getDisplayName();
/*  60:    */       
/*  61: 73 */       FilterState state = new FilterState(this.plugin, message, player, this);
/*  62:    */       
/*  63: 75 */       this.ruleChain.execute(state);
/*  64: 76 */       if (state.cancel) {
/*  65: 76 */         event.setCancelled(true);
/*  66:    */       }
/*  67: 79 */       if (state.messageChanged())
/*  68:    */       {
/*  69: 80 */         ItemStack newItem = new ItemStack(item);
/*  70: 81 */         ItemMeta newItemMeta = newItem.getItemMeta();
/*  71: 82 */         newItemMeta.setDisplayName(state.getModifiedMessage().getColoredString());
/*  72: 83 */         newItem.setItemMeta(newItemMeta);
/*  73: 84 */         event.setCurrentItem(newItem);
/*  74:    */       }
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void activate(Configuration config)
/*  79:    */   {
/*  80:107 */     if (isActive()) {
/*  81:107 */       return;
/*  82:    */     }
/*  83:109 */     setRuleChain(RuleManager.getInstance().getRuleChain("item.txt"));
/*  84:    */     
/*  85:111 */     PluginManager pm = Bukkit.getPluginManager();
/*  86:112 */     EventPriority priority = EventPriority.valueOf(config.getString("itempriority", "LOWEST").toUpperCase());
/*  87:114 */     if ((!this.active) && (config.getBoolean("itemfilter")))
/*  88:    */     {
/*  89:116 */       pm.registerEvent(InventoryClickEvent.class, this, priority, new EventExecutor()
/*  90:    */       {
/*  91:    */         public void execute(Listener l, Event e)
/*  92:    */         {
/*  93:118 */           PwnFilterInvListener.this.onInventoryEvent((InventoryClickEvent)e);
/*  94:    */         }
/*  95:118 */       }, this.plugin);
/*  96:    */       
/*  97:    */ 
/*  98:121 */       setActive();
/*  99:122 */       LogManager.logger.info("Activated ItemListener with Priority Setting: " + priority.toString() + " Rule Count: " + getRuleChain().ruleCount());
/* 100:    */     }
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.listener.PwnFilterInvListener
 * JD-Core Version:    0.7.0.1
 */