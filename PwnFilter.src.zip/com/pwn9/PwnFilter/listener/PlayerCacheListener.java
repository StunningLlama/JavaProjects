/*  1:   */ package com.pwn9.PwnFilter.listener;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.DataCache;
/*  4:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  5:   */ import java.util.concurrent.ConcurrentMap;
/*  6:   */ import org.bukkit.event.EventHandler;
/*  7:   */ import org.bukkit.event.EventPriority;
/*  8:   */ import org.bukkit.event.Listener;
/*  9:   */ import org.bukkit.event.player.PlayerJoinEvent;
/* 10:   */ import org.bukkit.event.player.PlayerQuitEvent;
/* 11:   */ 
/* 12:   */ public class PlayerCacheListener
/* 13:   */   implements Listener
/* 14:   */ {
/* 15:   */   @EventHandler(priority=EventPriority.LOWEST)
/* 16:   */   public void onPlayerQuit(PlayerQuitEvent event)
/* 17:   */   {
/* 18:23 */     if ((event.getPlayer() != null) && (PwnFilter.lastMessage.containsKey(event.getPlayer()))) {
/* 19:24 */       PwnFilter.lastMessage.remove(event.getPlayer());
/* 20:   */     }
/* 21:26 */     DataCache.getInstance().removePlayer(event.getPlayer());
/* 22:   */   }
/* 23:   */   
/* 24:   */   @EventHandler(priority=EventPriority.LOWEST)
/* 25:   */   public void onPlayerJoin(PlayerJoinEvent event)
/* 26:   */   {
/* 27:31 */     DataCache.getInstance().addPlayer(event.getPlayer());
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.listener.PlayerCacheListener
 * JD-Core Version:    0.7.0.1
 */