/*  1:   */ package com.pwn9.PwnFilter.listener;
/*  2:   */ 
/*  3:   */ import com.pwn9.PwnFilter.PwnFilter;
/*  4:   */ import com.pwn9.PwnFilter.api.FilterClient;
/*  5:   */ import com.pwn9.PwnFilter.rules.RuleChain;
/*  6:   */ import org.bukkit.event.HandlerList;
/*  7:   */ 
/*  8:   */ public abstract class BaseListener
/*  9:   */   implements FilterClient
/* 10:   */ {
/* 11:   */   protected final PwnFilter plugin;
/* 12:   */   protected boolean active;
/* 13:   */   protected RuleChain ruleChain;
/* 14:   */   
/* 15:   */   public BaseListener(PwnFilter p)
/* 16:   */   {
/* 17:30 */     this.plugin = p;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setRuleChain(RuleChain rc)
/* 21:   */   {
/* 22:35 */     this.ruleChain = rc;
/* 23:36 */     rc.loadConfigFile();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public RuleChain getRuleChain()
/* 27:   */   {
/* 28:44 */     return this.ruleChain;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public boolean isActive()
/* 32:   */   {
/* 33:52 */     return this.active;
/* 34:   */   }
/* 35:   */   
/* 36:   */   protected void setActive()
/* 37:   */   {
/* 38:56 */     this.active = true;
/* 39:   */   }
/* 40:   */   
/* 41:   */   protected void setInactive()
/* 42:   */   {
/* 43:60 */     this.active = false;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void shutdown()
/* 47:   */   {
/* 48:73 */     if (this.active)
/* 49:   */     {
/* 50:74 */       HandlerList.unregisterAll(this);
/* 51:75 */       setInactive();
/* 52:   */     }
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.listener.BaseListener
 * JD-Core Version:    0.7.0.1
 */