/*   1:    */ package com.pwn9.PwnFilter.listener;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.DataCache;
/*   4:    */ import com.pwn9.PwnFilter.FilterState;
/*   5:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   6:    */ import com.pwn9.PwnFilter.rules.RuleChain;
/*   7:    */ import com.pwn9.PwnFilter.rules.RuleManager;
/*   8:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*   9:    */ import com.pwn9.PwnFilter.util.LogManager;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.logging.Logger;
/*  14:    */ import org.bukkit.Bukkit;
/*  15:    */ import org.bukkit.configuration.Configuration;
/*  16:    */ import org.bukkit.entity.Player;
/*  17:    */ import org.bukkit.event.Event;
/*  18:    */ import org.bukkit.event.EventPriority;
/*  19:    */ import org.bukkit.event.Listener;
/*  20:    */ import org.bukkit.event.block.SignChangeEvent;
/*  21:    */ import org.bukkit.plugin.EventExecutor;
/*  22:    */ import org.bukkit.plugin.PluginManager;
/*  23:    */ 
/*  24:    */ public class PwnFilterSignListener
/*  25:    */   extends BaseListener
/*  26:    */ {
/*  27:    */   public PwnFilterSignListener(PwnFilter p)
/*  28:    */   {
/*  29: 39 */     super(p);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String getShortName()
/*  33:    */   {
/*  34: 44 */     return "SIGN";
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void onSignChange(SignChangeEvent event)
/*  38:    */   {
/*  39: 55 */     if (event.isCancelled()) {
/*  40: 55 */       return;
/*  41:    */     }
/*  42: 58 */     if (event.getPlayer().hasPermission("pwnfilter.bypass.signs")) {
/*  43: 59 */       return;
/*  44:    */     }
/*  45: 62 */     StringBuilder builder = new StringBuilder();
/*  46: 64 */     for (String l : event.getLines()) {
/*  47: 65 */       builder.append(l).append("\t");
/*  48:    */     }
/*  49: 67 */     String signLines = builder.toString().trim();
/*  50:    */     
/*  51: 69 */     FilterState state = new FilterState(this.plugin, signLines, event.getPlayer(), this);
/*  52:    */     
/*  53: 71 */     this.ruleChain.execute(state);
/*  54: 73 */     if (state.messageChanged())
/*  55:    */     {
/*  56: 76 */       List<String> newLines = new ArrayList();
/*  57: 79 */       if ((PwnFilter.decolor) && (!DataCache.getInstance().hasPermission(event.getPlayer(), "pwnfilter.color"))) {
/*  58: 80 */         Collections.addAll(newLines, state.getModifiedMessage().getPlainString().split("\t"));
/*  59:    */       } else {
/*  60: 82 */         Collections.addAll(newLines, state.getModifiedMessage().getColoredString().split("\t"));
/*  61:    */       }
/*  62: 85 */       String[] outputLines = new String[4];
/*  63: 89 */       for (int i = 0; (i < 4) && (i < newLines.size()); i++) {
/*  64: 90 */         if (((String)newLines.get(i)).length() > 15) {
/*  65: 91 */           outputLines[i] = ((String)newLines.get(i)).substring(0, 15);
/*  66:    */         } else {
/*  67: 93 */           outputLines[i] = ((String)newLines.get(i));
/*  68:    */         }
/*  69:    */       }
/*  70: 97 */       for (int i = 0; i < 4; i++) {
/*  71: 98 */         if (outputLines[i] != null) {
/*  72: 99 */           event.setLine(i, outputLines[i]);
/*  73:    */         } else {
/*  74:101 */           event.setLine(i, "");
/*  75:    */         }
/*  76:    */       }
/*  77:    */     }
/*  78:106 */     if (state.cancel)
/*  79:    */     {
/*  80:107 */       event.setCancelled(true);
/*  81:108 */       state.getPlayer().sendMessage("Your sign broke, there must be something wrong with it.");
/*  82:109 */       state.addLogMessage("SIGN " + state.playerName + " sign text: " + state.getOriginalMessage().getColoredString());
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void activate(Configuration config)
/*  87:    */   {
/*  88:128 */     if (isActive()) {
/*  89:128 */       return;
/*  90:    */     }
/*  91:129 */     setRuleChain(RuleManager.getInstance().getRuleChain("sign.txt"));
/*  92:    */     
/*  93:131 */     PluginManager pm = Bukkit.getPluginManager();
/*  94:132 */     EventPriority priority = EventPriority.valueOf(config.getString("signpriority", "LOWEST").toUpperCase());
/*  95:134 */     if (config.getBoolean("signfilter"))
/*  96:    */     {
/*  97:136 */       pm.registerEvent(SignChangeEvent.class, this, priority, new EventExecutor()
/*  98:    */       {
/*  99:    */         public void execute(Listener l, Event e)
/* 100:    */         {
/* 101:138 */           PwnFilterSignListener.this.onSignChange((SignChangeEvent)e);
/* 102:    */         }
/* 103:138 */       }, this.plugin);
/* 104:    */       
/* 105:    */ 
/* 106:    */ 
/* 107:142 */       LogManager.logger.info("Activated SignListener with Priority Setting: " + priority.toString() + " Rule Count: " + getRuleChain().ruleCount());
/* 108:    */       
/* 109:    */ 
/* 110:145 */       setActive();
/* 111:    */     }
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.listener.PwnFilterSignListener
 * JD-Core Version:    0.7.0.1
 */