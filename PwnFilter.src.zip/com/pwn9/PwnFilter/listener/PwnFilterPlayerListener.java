/*   1:    */ package com.pwn9.PwnFilter.listener;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.DataCache;
/*   4:    */ import com.pwn9.PwnFilter.FilterState;
/*   5:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   6:    */ import com.pwn9.PwnFilter.rules.RuleChain;
/*   7:    */ import com.pwn9.PwnFilter.rules.RuleManager;
/*   8:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*   9:    */ import com.pwn9.PwnFilter.util.LogManager;
/*  10:    */ import java.util.concurrent.ConcurrentMap;
/*  11:    */ import java.util.logging.Logger;
/*  12:    */ import org.bukkit.Bukkit;
/*  13:    */ import org.bukkit.Server;
/*  14:    */ import org.bukkit.configuration.Configuration;
/*  15:    */ import org.bukkit.configuration.file.FileConfiguration;
/*  16:    */ import org.bukkit.entity.Player;
/*  17:    */ import org.bukkit.event.Event;
/*  18:    */ import org.bukkit.event.EventPriority;
/*  19:    */ import org.bukkit.event.Listener;
/*  20:    */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*  21:    */ import org.bukkit.plugin.EventExecutor;
/*  22:    */ import org.bukkit.plugin.PluginManager;
/*  23:    */ 
/*  24:    */ public class PwnFilterPlayerListener
/*  25:    */   extends BaseListener
/*  26:    */ {
/*  27:    */   public String getShortName()
/*  28:    */   {
/*  29: 35 */     return "CHAT";
/*  30:    */   }
/*  31:    */   
/*  32:    */   public PwnFilterPlayerListener(PwnFilter p)
/*  33:    */   {
/*  34: 39 */     super(p);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void onPlayerChat(AsyncPlayerChatEvent event)
/*  38:    */   {
/*  39: 44 */     if (event.isCancelled()) {
/*  40: 44 */       return;
/*  41:    */     }
/*  42: 46 */     Player player = event.getPlayer();
/*  43: 47 */     DataCache dCache = DataCache.getInstance();
/*  44: 50 */     if (dCache.hasPermission(player, "pwnfilter.bypass.chat")) {
/*  45: 50 */       return;
/*  46:    */     }
/*  47: 52 */     String message = event.getMessage();
/*  48: 55 */     if ((PwnFilter.pwnMute) && (!dCache.hasPermission(player, "pwnfilter.bypass.mute")))
/*  49:    */     {
/*  50: 56 */       event.setCancelled(true);
/*  51: 57 */       return;
/*  52:    */     }
/*  53: 60 */     if ((this.plugin.getConfig().getBoolean("spamfilter")) && (!dCache.hasPermission(player, "pwnfilter.bypass.spam")))
/*  54:    */     {
/*  55: 62 */       if ((PwnFilter.lastMessage.containsKey(player)) && (((String)PwnFilter.lastMessage.get(player)).equals(message)))
/*  56:    */       {
/*  57: 63 */         event.setCancelled(true);
/*  58: 64 */         return;
/*  59:    */       }
/*  60: 66 */       PwnFilter.lastMessage.put(player, message);
/*  61:    */     }
/*  62: 70 */     FilterState state = new FilterState(this.plugin, message, event.getPlayer(), this);
/*  63: 73 */     if ((PwnFilter.decolor) && (!dCache.hasPermission(player, "pwnfilter.color"))) {
/*  64: 75 */       state.setModifiedMessage(state.getModifiedMessage().decolor());
/*  65:    */     }
/*  66: 79 */     LogManager.getInstance().debugHigh("Applying '" + this.ruleChain.getConfigName() + "' to message: " + state.getModifiedMessage());
/*  67: 80 */     this.ruleChain.execute(state);
/*  68: 83 */     if (state.messageChanged()) {
/*  69: 84 */       event.setMessage(state.getModifiedMessage().getColoredString());
/*  70:    */     }
/*  71: 86 */     if (state.cancel) {
/*  72: 86 */       event.setCancelled(true);
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void activate(Configuration config)
/*  77:    */   {
/*  78:103 */     if (isActive()) {
/*  79:103 */       return;
/*  80:    */     }
/*  81:105 */     setRuleChain(RuleManager.getInstance().getRuleChain("chat.txt"));
/*  82:    */     
/*  83:107 */     PluginManager pm = Bukkit.getServer().getPluginManager();
/*  84:108 */     EventPriority priority = EventPriority.valueOf(config.getString("chatpriority", "LOWEST").toUpperCase());
/*  85:    */     
/*  86:    */ 
/*  87:111 */     pm.registerEvent(AsyncPlayerChatEvent.class, this, priority, new EventExecutor()
/*  88:    */     {
/*  89:    */       public void execute(Listener l, Event e)
/*  90:    */       {
/*  91:113 */         PwnFilterPlayerListener.this.onPlayerChat((AsyncPlayerChatEvent)e);
/*  92:    */       }
/*  93:113 */     }, this.plugin);
/*  94:    */     
/*  95:    */ 
/*  96:    */ 
/*  97:117 */     LogManager.logger.info("Activated PlayerListener with Priority Setting: " + priority.toString() + " Rule Count: " + getRuleChain().ruleCount());
/*  98:    */     
/*  99:    */ 
/* 100:120 */     setActive();
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.listener.PwnFilterPlayerListener
 * JD-Core Version:    0.7.0.1
 */