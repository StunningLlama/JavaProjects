/*   1:    */ package com.pwn9.PwnFilter.listener;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.DataCache;
/*   4:    */ import com.pwn9.PwnFilter.FilterState;
/*   5:    */ import com.pwn9.PwnFilter.PwnFilter;
/*   6:    */ import com.pwn9.PwnFilter.rules.RuleChain;
/*   7:    */ import com.pwn9.PwnFilter.rules.RuleManager;
/*   8:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*   9:    */ import com.pwn9.PwnFilter.util.LogManager;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.logging.Logger;
/*  13:    */ import org.bukkit.Bukkit;
/*  14:    */ import org.bukkit.configuration.Configuration;
/*  15:    */ import org.bukkit.entity.Player;
/*  16:    */ import org.bukkit.event.Event;
/*  17:    */ import org.bukkit.event.EventPriority;
/*  18:    */ import org.bukkit.event.Listener;
/*  19:    */ import org.bukkit.event.player.PlayerEditBookEvent;
/*  20:    */ import org.bukkit.inventory.meta.BookMeta;
/*  21:    */ import org.bukkit.plugin.EventExecutor;
/*  22:    */ import org.bukkit.plugin.PluginManager;
/*  23:    */ 
/*  24:    */ public class PwnFilterBookListener
/*  25:    */   extends BaseListener
/*  26:    */ {
/*  27:    */   public PwnFilterBookListener(PwnFilter p)
/*  28:    */   {
/*  29: 41 */     super(p);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String getShortName()
/*  33:    */   {
/*  34: 46 */     return "BOOK";
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void onBookEdit(PlayerEditBookEvent event)
/*  38:    */   {
/*  39: 54 */     if (event.isCancelled()) {
/*  40: 54 */       return;
/*  41:    */     }
/*  42: 56 */     Player player = event.getPlayer();
/*  43: 58 */     if (DataCache.getInstance().hasPermission(player, "pwnfilter.bypass.book")) {
/*  44: 58 */       return;
/*  45:    */     }
/*  46: 60 */     BookMeta bookMeta = event.getNewBookMeta();
/*  47: 63 */     if (bookMeta.hasTitle())
/*  48:    */     {
/*  49: 65 */       String message = bookMeta.getTitle();
/*  50: 66 */       FilterState state = new FilterState(this.plugin, message, player, this);
/*  51: 67 */       this.ruleChain.execute(state);
/*  52: 68 */       if (state.cancel) {
/*  53: 68 */         event.setCancelled(true);
/*  54:    */       }
/*  55: 69 */       if (state.messageChanged())
/*  56:    */       {
/*  57: 70 */         bookMeta.setTitle(state.getModifiedMessage().getColoredString());
/*  58: 71 */         event.setNewBookMeta(bookMeta);
/*  59:    */       }
/*  60:    */     }
/*  61: 76 */     if (bookMeta.hasPages())
/*  62:    */     {
/*  63: 77 */       List<String> newPages = new ArrayList();
/*  64: 78 */       boolean modified = false;
/*  65: 79 */       for (String page : bookMeta.getPages())
/*  66:    */       {
/*  67: 80 */         FilterState state = new FilterState(this.plugin, page, player, this);
/*  68: 81 */         this.ruleChain.execute(state);
/*  69: 82 */         if (state.isCancelled()) {
/*  70: 83 */           event.setCancelled(true);
/*  71:    */         }
/*  72: 85 */         if (state.messageChanged())
/*  73:    */         {
/*  74: 86 */           page = state.getModifiedMessage().getColoredString();
/*  75: 87 */           modified = true;
/*  76:    */         }
/*  77: 89 */         newPages.add(page);
/*  78:    */       }
/*  79: 91 */       if (modified)
/*  80:    */       {
/*  81: 92 */         bookMeta.setPages(newPages);
/*  82: 93 */         event.setNewBookMeta(bookMeta);
/*  83:    */       }
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void activate(Configuration config)
/*  88:    */   {
/*  89:113 */     if (isActive()) {
/*  90:113 */       return;
/*  91:    */     }
/*  92:115 */     setRuleChain(RuleManager.getInstance().getRuleChain("book.txt"));
/*  93:    */     
/*  94:117 */     PluginManager pm = Bukkit.getPluginManager();
/*  95:118 */     EventPriority priority = EventPriority.valueOf(config.getString("bookpriority", "LOWEST").toUpperCase());
/*  96:120 */     if ((!this.active) && (config.getBoolean("bookfilter")))
/*  97:    */     {
/*  98:122 */       pm.registerEvent(PlayerEditBookEvent.class, this, priority, new EventExecutor()
/*  99:    */       {
/* 100:    */         public void execute(Listener l, Event e)
/* 101:    */         {
/* 102:124 */           PwnFilterBookListener.this.onBookEdit((PlayerEditBookEvent)e);
/* 103:    */         }
/* 104:124 */       }, this.plugin);
/* 105:    */       
/* 106:    */ 
/* 107:127 */       setActive();
/* 108:128 */       LogManager.logger.info("Activated BookListener with Priority Setting: " + priority.toString() + " Rule Count: " + getRuleChain().ruleCount());
/* 109:    */     }
/* 110:    */   }
/* 111:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.listener.PwnFilterBookListener
 * JD-Core Version:    0.7.0.1
 */