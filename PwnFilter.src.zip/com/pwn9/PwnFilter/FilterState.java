/*   1:    */ package com.pwn9.PwnFilter;
/*   2:    */ 
/*   3:    */ import com.pwn9.PwnFilter.api.FilterClient;
/*   4:    */ import com.pwn9.PwnFilter.rules.Rule;
/*   5:    */ import com.pwn9.PwnFilter.util.ColoredString;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.regex.Pattern;
/*   9:    */ import org.bukkit.Bukkit;
/*  10:    */ import org.bukkit.World;
/*  11:    */ import org.bukkit.entity.Player;
/*  12:    */ import org.bukkit.plugin.Plugin;
/*  13:    */ 
/*  14:    */ public class FilterState
/*  15:    */ {
/*  16:    */   private final ColoredString originalMessage;
/*  17:    */   private ColoredString modifiedMessage;
/*  18:    */   private ColoredString unfilteredMessage;
/*  19:    */   public final Plugin plugin;
/*  20:    */   private final Player player;
/*  21:    */   public final String playerName;
/*  22:    */   public final String playerWorldName;
/*  23:    */   public final FilterClient listener;
/*  24:    */   final int messageLen;
/*  25: 53 */   private List<String> logMessages = new ArrayList();
/*  26: 54 */   public boolean log = false;
/*  27: 55 */   public boolean stop = false;
/*  28: 56 */   public boolean cancel = false;
/*  29:    */   public Rule rule;
/*  30:    */   public Pattern pattern;
/*  31:    */   
/*  32:    */   public FilterState(Plugin pl, String m, Player p, FilterClient l)
/*  33:    */   {
/*  34: 71 */     this.originalMessage = new ColoredString(m);
/*  35: 72 */     this.modifiedMessage = new ColoredString(m);
/*  36: 73 */     this.messageLen = this.originalMessage.length();
/*  37: 74 */     this.player = p;
/*  38: 75 */     if (p != null) {
/*  39: 76 */       this.playerName = p.getName();
/*  40:    */     } else {
/*  41: 78 */       this.playerName = "*CONSOLE*";
/*  42:    */     }
/*  43: 80 */     if (p != null) {
/*  44: 81 */       this.playerWorldName = p.getWorld().getName();
/*  45:    */     } else {
/*  46: 83 */       this.playerWorldName = "";
/*  47:    */     }
/*  48: 85 */     this.plugin = pl;
/*  49: 86 */     this.listener = l;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public FilterState(Plugin pl, String m, String pName, World w, FilterClient l)
/*  53:    */   {
/*  54: 99 */     this.originalMessage = new ColoredString(m);
/*  55:100 */     this.modifiedMessage = new ColoredString(m);
/*  56:101 */     this.messageLen = this.originalMessage.length();
/*  57:102 */     this.playerName = pName;
/*  58:103 */     this.playerWorldName = (w == null ? "" : w.getName());
/*  59:104 */     this.plugin = pl;
/*  60:105 */     this.listener = l;
/*  61:106 */     this.player = Bukkit.getPlayerExact(pName);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void addLogMessage(String message)
/*  65:    */   {
/*  66:116 */     this.logMessages.add(message);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public List<String> getLogMessages()
/*  70:    */   {
/*  71:120 */     return this.logMessages;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean messageChanged()
/*  75:    */   {
/*  76:126 */     return !this.originalMessage.toString().equals(this.modifiedMessage.toString());
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean playerHasPermission(String perm)
/*  80:    */   {
/*  81:130 */     return (this.player != null) && (DataCache.getInstance().hasPermission(this.player, perm));
/*  82:    */   }
/*  83:    */   
/*  84:    */   public Player getPlayer()
/*  85:    */   {
/*  86:134 */     return this.player;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public boolean isCancelled()
/*  90:    */   {
/*  91:138 */     return this.cancel;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setCancelled(boolean cancel)
/*  95:    */   {
/*  96:142 */     this.cancel = cancel;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public String getListenerName()
/* 100:    */   {
/* 101:146 */     return this.listener.getShortName();
/* 102:    */   }
/* 103:    */   
/* 104:    */   public ColoredString getOriginalMessage()
/* 105:    */   {
/* 106:153 */     return new ColoredString(this.originalMessage);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public ColoredString getModifiedMessage()
/* 110:    */   {
/* 111:157 */     return new ColoredString(this.modifiedMessage);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setModifiedMessage(ColoredString newMessage)
/* 115:    */   {
/* 116:161 */     this.modifiedMessage = newMessage;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public ColoredString getUnfilteredMessage()
/* 120:    */   {
/* 121:165 */     return this.unfilteredMessage;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setUnfilteredMessage(ColoredString newMessage)
/* 125:    */   {
/* 126:169 */     this.unfilteredMessage = newMessage;
/* 127:    */   }
/* 128:    */ }


/* Location:           C:\Users\Brandon\Desktop\PwnFilter.jar
 * Qualified Name:     com.pwn9.PwnFilter.FilterState
 * JD-Core Version:    0.7.0.1
 */